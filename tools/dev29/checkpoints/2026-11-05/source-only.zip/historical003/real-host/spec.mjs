// Real Q014 Docker profiles. Pure argument builders and fail-closed inspect gates.
import path from 'node:path';import {fileURLToPath} from 'node:url';
import {RUN,PREFIX,PLAN,SOURCE,PGIMAGE,ORIGINAL,TMPFS,ensure,closed,sha,stable,canonical,hex} from '../guards.mjs';
export {RUN,PREFIX,PLAN,SOURCE,PGIMAGE,ORIGINAL,TMPFS,ensure,closed,sha,stable,canonical,hex};
export const HERE=path.dirname(fileURLToPath(import.meta.url)),ROOT=path.resolve(HERE,'../../..'),REAL=path.join(HERE,'../real');
export const PYIMAGE='sha256:09433387bce7dd726eb2f76918287c04c1fbd340eed1db2aaa3397fbd0474951';
export const PRIV=path.join(ROOT,'work/dev15-20261102/private/bound29-651e6a45-real');
export const NET=PREFIX+'-net',DB=PREFIX+'-db',UNITMARK='BOUND29-UNIT:'+RUN,MAINMARK='BOUND29-MAIN:'+RUN;
export const HBA_SHA='4c2aa75544a7b6ce52c4a9aa2d18836a607c8f4a148d334bef8df314778d891b';
const eq=(a,b)=>stable(a)===stable(b);
const ro=(source,target)=>({source,target});
const secret=(name,target=name)=>ro(path.join(PRIV,name),'/run/secrets/'+target);
export const TLSROOT=path.join(ROOT,'work/dev15-20261102/private');
export const DBBINDS=Object.freeze([
 ro(path.join(REAL,'bound-db-supervisor.sh'),'/tools/bound-db-supervisor.sh'),
 ...['bootstrap.hba','runtime.hba','bootstrap.sql'].map(x=>ro(path.join(REAL,x),'/config/'+x)),
 secret('bootstrap-password'),secret('migrator-password'),
 ro(path.join(TLSROOT,'database-ca'),'/run/secrets/database-ca'),
 ro(path.join(TLSROOT,'database-server-key'),'/run/secrets/database-server-key')]);
export function mountArgs(binds){return binds.flatMap(b=>['--mount','type=bind,source='+b.source+',target='+b.target+',readonly']);}
function caps(memory,pids,user){return ['--pull=never','--user',user,'--read-only','--cap-drop=ALL','--security-opt=no-new-privileges:true','--memory='+memory,'--memory-swap='+memory,'--cpus=0.5','--pids-limit='+pids,'--shm-size=16m','--log-driver=none','--restart=no','--ipc=private','--cgroupns=private','--label','bound29.run='+RUN,'--label','nestakada.scope=trust-test'];}
export function networkArgs(){return ['network','create','--internal','--driver','bridge','--label','bound29.run='+RUN,'--label','nestakada.scope=trust-test',NET];}
export function dbArgs(){return ['create','--name',DB,...caps(1073741824,128,'999:999'),'--label','bound29.kind=db','--network',NET,'--network-alias','trust-db',...Object.entries(TMPFS).flatMap(([p,v])=>['--tmpfs',p+':'+v]),...mountArgs(DBBINDS),'--entrypoint','/bin/sh',PGIMAGE,'/tools/bound-db-supervisor.sh'];}
export function originalArgs(phase){ensure(['before','after'].includes(phase),'HOST_ORIGINAL_PHASE');const binds=[ro(path.join(HERE,'../original-inspector.sh'),'/tools/original-inspector.sh')];return ['create','--name',PREFIX+'-original-'+phase,...caps(268435456,64,'999:999'),'--label','bound29.kind=original-'+phase,'--network=none','--tmpfs','/tmp:rw,nosuid,nodev,noexec,size=32m,uid=999,gid=999,mode=0700','--mount','type=volume,source='+ORIGINAL+',target=/var/lib/postgresql,readonly,volume-nocopy',...mountArgs(binds),'--entrypoint','/usr/bin/timeout',PGIMAGE,'--signal=KILL','60s','/bin/sh','/tools/original-inspector.sh'];}
export const SOURCE_DIR=path.join(ROOT,'work/dev29-publication-20261103/pg-check/residual/run/source');
export function helperSpec(kind){
 ensure(['preflight','main','unit','matrix','init','capacity','suite'].includes(kind),'HOST_HELPER_KIND');
 const audit=['main','unit'].includes(kind),worker=['init','capacity','suite'].includes(kind);
 const script=kind==='preflight'?'preflight.py':audit?'audit.py':kind==='matrix'?'matrix.py':kind==='init'?'unit_init.py':kind==='suite'?'suite-runner.py':'capacity.py';
 const seconds=kind==='capacity'?600:kind==='suite'?240:kind==='init'?90:60;
 const binds=[ro(SOURCE_DIR,'/trust'),ro(path.join(REAL,'unit_init.py'),'/tools/unit_init.py'),
 ro(path.join(TLSROOT,'database-ca'),'/run/secrets/database-ca')];
 if(script!=='unit_init.py')binds.push(ro(path.join(audit||kind==='matrix'||kind==='preflight'?HERE:REAL,script),'/tools/'+script));
 if(kind==='matrix')binds.push(ro(path.join(HERE,'audit.py'),'/tools/audit.py'));
 if(kind==='preflight'){binds.splice(1,2);}else if(kind==='matrix')binds.push(secret('bootstrap-password'),secret('migrator-password'));
 else binds.push(secret(kind==='main'?'bootstrap-password':'migrator-password','database-password'));
 const env={PYTHONDONTWRITEBYTECODE:'1',PSYCOPG_IMPL:'c',TRUST_DB_NAME:kind==='main'?'estakada_trust':'test_estakada_trust',TRUST_DB_HOST:'trust-db',TRUST_DB_USER:kind==='main'?'postgres':'trust_migrator',TRUST_DB_PASSWORD_FILE:'/run/secrets/database-password',TRUST_DB_CA:'/run/secrets/database-ca',DJANGO_SETTINGS_MODULE:'trust_service.settings',TRUST_WRITE_PROFILE:'disabled',TRUST_TEST_EXECUTION:'1',PGAPPNAME:'BOUND29-'+kind+'-'+RUN};
 if(worker){for(const [name,target]of [['django-secret','django-secret'],['credentials.json','credentials.json'],['identity-pin','identity-pin']])binds.push(secret(name,target));Object.assign(env,{TRUST_DJANGO_SECRET_FILE:'/run/secrets/django-secret',TRUST_CREDENTIALS_FILE:'/run/secrets/credentials.json',TRUST_IDENTITY_FILE:'/run/secrets/identity-pin',TRUST_RUNTIME_ID:RUN});}
 const argv=['--signal=KILL',seconds+'s','python','-I','-B','/tools/'+script];
 return {stdin:true,network:kind==='preflight'?'none':undefined,kind,name:PREFIX+'-'+kind,image:PYIMAGE,user:'10001:10001',seconds,binds,env,entrypoint:['/usr/bin/timeout'],cmd:argv,tmpfs:{'/tmp':'rw,nosuid,nodev,noexec,size=32m,uid=10001,gid=10001,mode=1777'},memory:268435456,pids:64};
}
export function helperArgs(kind){const s=helperSpec(kind);return ['create','--interactive','--name',s.name,...caps(s.memory,s.pids,s.user),'--label','bound29.kind='+kind,'--network',kind==='preflight'?'none':NET,...Object.entries(s.tmpfs).flatMap(([p,v])=>['--tmpfs',p+':'+v]),...Object.entries(s.env).flatMap(([k,v])=>['--env',k+'='+v]),...mountArgs(s.binds),'--entrypoint',s.entrypoint[0],s.image,...s.cmd];}
export function networkGate(v,id,allowedIds=[]){ensure(hex(id)&&v.Id===id&&v.Name===NET&&v.Internal===true&&v.Driver==='bridge'&&v.EnableIPv6===false&&v.Labels?.['bound29.run']===RUN&&v.Labels?.['nestakada.scope']==='trust-test','HOST_NETWORK');ensure(Object.keys(v.Containers||{}).every(x=>allowedIds.includes(x)),'HOST_FOREIGN_NETWORK');}
export function volumeGate(v){ensure(v.Name===ORIGINAL&&v.Driver==='local'&&v.Labels?.['nestakada.scope']==='trust-test'&&v.Labels?.['com.docker.compose.project']==='nestakada-trust-test'&&v.Labels?.['com.docker.compose.volume']==='dbdata'&&(!v.Options||!Object.keys(v.Options).length),'HOST_VOLUME');}
export function inspectGate(v,s,id,imageEnv,{running=null,exited=false}={}){
 ensure(hex(id)&&v.Id===id&&v.Image===s.image&&v.Name==='/'+s.name&&v.Config.Labels?.['bound29.run']===RUN&&v.Config.Labels?.['nestakada.scope']==='trust-test'&&v.Config.Labels?.['bound29.kind']===s.kind,'HOST_CONTAINER');
 const c=v.Config,h=v.HostConfig;
 ensure(c.User===s.user&&c.OpenStdin===Boolean(s.stdin)&&c.Tty===false&&c.StdinOnce===false&&eq(c.Entrypoint,s.entrypoint)&&eq(c.Cmd,s.cmd),'HOST_COMMAND');
 const expectedEnv=new Map(imageEnv.map(x=>[x.slice(0,x.indexOf('=')),x]));for(const [k,x]of Object.entries(s.env||{}))expectedEnv.set(k,k+'='+x);
 ensure(eq([...c.Env].sort(),[...expectedEnv.values()].sort()),'HOST_ENV');
 ensure(h.ReadonlyRootfs===true&&h.Privileged===false&&h.Memory===s.memory&&h.MemorySwap===s.memory&&h.NanoCpus===500000000&&h.PidsLimit===s.pids&&h.ShmSize===16777216&&eq(h.CapDrop,['ALL'])&&!(h.CapAdd||[]).length&&eq((h.SecurityOpt||[]).map(x=>x==='no-new-privileges'?'no-new-privileges:true':x),['no-new-privileges:true'])&&eq(h.LogConfig,{Type:'none',Config:{}})&&h.RestartPolicy?.Name==='no'&&h.AutoRemove===false&&!h.OomKillDisable&&(h.OomScoreAdj||0)===0,'HOST_CAPS');
 ensure(!h.PidMode&&!h.UTSMode&&!h.UsernsMode&&h.IpcMode==='private'&&h.CgroupnsMode==='private'&&!(h.Devices||[]).length&&!(h.DeviceRequests||[]).length&&!(h.Links||[]).length&&!(h.VolumesFrom||[]).length&&!Object.values(h.PortBindings||{}).some(x=>x?.length)&&!Object.values(v.NetworkSettings?.Ports||{}).some(x=>x?.length),'HOST_SHARING');
 ensure(eq(h.Tmpfs,s.tmpfs),'HOST_TMPFS');const mounts=v.Mounts||[],binds=mounts.filter(m=>m.Type==='bind'),vols=mounts.filter(m=>m.Type==='volume');
 ensure(binds.length===s.binds.length&&new Set(binds.map(m=>m.Destination)).size===binds.length&&binds.every(m=>m.RW===false&&s.binds.some(b=>b.target===m.Destination&&canonical(b.source)===canonical(m.Source))),'HOST_BINDS');
 if(s.volume){const vm=(h.Mounts||[]).filter(m=>m.Type==='volume');ensure(vm.length===1&&vm[0].Source===ORIGINAL&&vm[0].Target==='/var/lib/postgresql'&&vm[0].ReadOnly===true&&vm[0].VolumeOptions?.NoCopy===true&&!vm[0].VolumeOptions?.Subpath&&!vm[0].VolumeOptions?.DriverConfig&&!vm[0].VolumeOptions?.Labels&&!vm[0].BindOptions&&!vm[0].TmpfsOptions,'HOST_VOLUME_NOCOPY');}ensure(s.volume?vols.length===1&&vols[0].Name===ORIGINAL&&vols[0].Destination==='/var/lib/postgresql'&&vols[0].RW===false:vols.length===0,'HOST_VOLUMES');
 ensure(mounts.every(m=>m.Type==='bind'||m.Type==='volume'||m.Type==='tmpfs'&&Object.hasOwn(s.tmpfs,m.Destination)),'HOST_MOUNT_TYPE');
 const nets=v.NetworkSettings?.Networks||{};ensure(s.network==='none'?h.NetworkMode==='none'&&Object.keys(nets).every(x=>x==='none'):Object.keys(nets).length===1&&nets[NET]?.NetworkID===s.networkId&&[NET,s.networkId].includes(h.NetworkMode),'HOST_NETWORK_BIND');
 ensure(v.RestartCount===0&&v.State.OOMKilled===false&&v.State.Dead===false&&v.State.Error===''&&(running===null||v.State.Running===running)&&(exited?v.State.Status==='exited':['created','running'].includes(v.State.Status)),'HOST_STATE');if(s.startedAt)ensure(v.State.StartedAt===s.startedAt,'HOST_RESTART');return true;
}
export function dbSpec(networkId){return {kind:'db',name:DB,image:PGIMAGE,user:'999:999',memory:1073741824,pids:128,entrypoint:['/bin/sh'],cmd:['/tools/bound-db-supervisor.sh'],env:{},binds:DBBINDS,tmpfs:TMPFS,networkId,stdin:false};}
export function inspectorSpec(phase){return {kind:'original-'+phase,name:PREFIX+'-original-'+phase,image:PGIMAGE,user:'999:999',memory:268435456,pids:64,entrypoint:['/usr/bin/timeout'],cmd:['--signal=KILL','60s','/bin/sh','/tools/original-inspector.sh'],env:{},binds:[ro(path.join(HERE,'../original-inspector.sh'),'/tools/original-inspector.sh')],tmpfs:{'/tmp':'rw,nosuid,nodev,noexec,size=32m,uid=999,gid=999,mode=0700'},network:'none',volume:true,stdin:false};}

export const ENGINE_ID='18f3b425-a862-4cbe-ba14-438caef2aab2';
export function engineIdentityGate(info){ensure(info?.OSType==='linux'&&info.ID===ENGINE_ID,'HOST_ENGINE_DRIFT');return info.ID;}
