// BOUND29 pure capability gates. No process, secret, Docker or filesystem IO.
import {createHash,createHmac,timingSafeEqual} from 'node:crypto';
export const RUN='066dd89b-2727-4d6d-a16a-b17bdccd9f92';
export const PREFIX='nestakada-bound29-066dd89b';
export const PLAN='df2c00f148f581c6f4113ccfe2febf4c76d385bfd2e36ccca87b3c44be184311';
export const PGIMAGE='sha256:de3d5ee43e308309e10730caead7dd880539d53f0275d977cd2f8c3f62b6eef7';
export const SOURCE='1d25e6fc62f675d63de1226889e19eea3ac17df22f11b40a9f1a04450ea9940e';
export const ORIGINAL='nestakada-trust-test-dbdata';
export const stable=v=>JSON.stringify(v,(_,x)=>x&&typeof x==='object'&&!Array.isArray(x)?Object.fromEntries(Object.entries(x).sort(([a],[b])=>a<b?-1:a>b?1:0)):x);
export const sha=v=>createHash('sha256').update(v).digest('hex');
export function ensure(ok,code){if(!ok)throw Error(code);}
const eq=(a,b)=>stable(a)===stable(b);
const integer=x=>Number.isSafeInteger(x)&&x>=0;
export const hex=x=>typeof x==='string'&&/^[a-f0-9]{64}$/.test(x);
export function closed(v,keys){ensure(v&&Object.getPrototypeOf(v)===Object.prototype&&eq(Object.keys(v).sort(),[...keys].sort()),'BOUND_CLOSED');}
export const canonical=v=>{ensure(typeof v==='string','BOUND_BIND_TYPE');return v.replaceAll('\\','/').replace(/^\/run\/desktop\/mnt\/host\/([a-z])\//i,(_,d)=>d+':/').toLowerCase();};
export const TMPFS=Object.freeze({'/var/lib/postgresql':'rw,nosuid,nodev,noexec,size=512m,uid=999,gid=999,mode=0700','/var/run/postgresql':'rw,nosuid,nodev,noexec,size=16m,uid=999,gid=999,mode=0700','/tmp':'rw,nosuid,nodev,noexec,size=32m,uid=999,gid=999,mode=0700'});
export function resourceEnvelope(oldBytes,newBytes){
  ensure(integer(oldBytes)&&integer(newBytes)&&newBytes<=33554432,'BOUND_HOST_BYTES');
  const persistent=oldBytes+newBytes+16777216;
  const conservative=oldBytes+1073741824+268435456+33554432+16777216;
  ensure(persistent<2147483648&&conservative<2147483648,'BOUND_ENVELOPE');
  return {persistent,conservative,limit:2147483648,tmpfsBytes:654311424};
}
export function admission(envelope,key,refs,now){
  ensure(Buffer.isBuffer(key)&&key.length===32,'BOUND_KEY');
  closed(envelope,['payload','signature']);ensure(hex(envelope.signature),'BOUND_SIGNATURE');
  const want=createHmac('sha256',key).update(stable(envelope.payload)).digest();
  ensure(timingSafeEqual(want,Buffer.from(envelope.signature,'hex')),'BOUND_SIGNATURE');
  const p=envelope.payload;
  closed(p,['scope','run','plan','source','packageSha','ownerSha','codeReviewSha','payloadReviewSha','previousSha','containerId','networkId','issuedMs','expiresMs']);
  const minimum={'BOUND29-INIT':110000,'BOUND29-CAPACITY':730000,'BOUND29-SUITE':370000}[p.scope];
  ensure(minimum&&p.run===RUN&&p.plan===PLAN&&p.source===SOURCE,'BOUND_ADMISSION_SCOPE');
  for(const k of ['packageSha','ownerSha','codeReviewSha','payloadReviewSha','previousSha','containerId','networkId'])ensure(hex(p[k])&&p[k]===refs[k],'BOUND_ADMISSION_BINDING');
  ensure(p.scope===refs.scope&&integer(now)&&integer(p.issuedMs)&&integer(p.expiresMs)&&p.issuedMs<=now&&p.expiresMs-p.issuedMs<=900000&&p.expiresMs-p.issuedMs>=minimum&&p.expiresMs-now>=minimum,'BOUND_EXPIRY');
  return p;
}
export function networkGate(v,id){
  ensure(hex(id)&&v.Id===id&&v.Name===PREFIX+'-net'&&v.Driver==='bridge'&&v.Internal===true&&v.EnableIPv6===false&&v.Labels?.['bound29.run']===RUN&&v.Labels?.['nestakada.scope']==='trust-test','BOUND_NETWORK');
}
function base(v,expected,user,memory,pids){
  ensure(hex(expected.id)&&v.Id===expected.id&&v.Image===PGIMAGE&&v.Name==='/'+PREFIX+expected.suffix&&v.Config?.Labels?.['bound29.run']===RUN&&v.Config.Labels['nestakada.scope']==='trust-test','BOUND_CONTAINER_ID');
  const h=v.HostConfig;
  ensure(h&&v.Config.User===user&&h.ReadonlyRootfs===true&&h.Privileged===false&&h.Memory===memory&&h.MemorySwap===memory&&h.NanoCpus===500000000&&h.PidsLimit===pids&&eq(h.CapDrop,['ALL'])&&!(h.CapAdd||[]).length&&eq(h.SecurityOpt,['no-new-privileges:true'])&&eq(h.LogConfig,{Type:'none',Config:{}})&&h.RestartPolicy?.Name==='no'&&h.ShmSize===16777216&&!h.OomKillDisable&&(h.OomScoreAdj||0)===0,'BOUND_CAPS');
  ensure(!(h.Devices||[]).length&&!(h.DeviceRequests||[]).length&&!(h.VolumesFrom||[]).length&&!(h.Links||[]).length&&!h.PidMode&&h.IpcMode==='private'&&!h.UTSMode&&!h.UsernsMode&&h.CgroupnsMode==='private'&&h.AutoRemove===false,'BOUND_HOST_SHARING');
  ensure(!Object.values(h.PortBindings||{}).some(x=>x?.length)&&!Object.values(v.NetworkSettings?.Ports||{}).some(x=>x?.length),'BOUND_PORTS');
  ensure(eq(v.Config.Entrypoint,expected.entrypoint)&&eq(v.Config.Cmd,expected.cmd)&&eq([...(v.Config.Env||[])].sort(),[...expected.env].sort()),'BOUND_COMMAND_ENV');
  ensure(v.Config.OpenStdin===false&&v.Config.Tty===false&&v.Config.StdinOnce===false,'BOUND_STDIN');
  const mounts=v.Mounts||[];
  ensure(mounts.every(m=>m.Type==='bind'||m.Type==='tmpfs'),'BOUND_VOLUME');
  const binds=mounts.filter(m=>m.Type==='bind');
  ensure(binds.length===expected.binds.length&&new Set(binds.map(m=>m.Destination)).size===binds.length&&binds.every(m=>m.RW===false&&expected.binds.some(b=>b.target===m.Destination&&canonical(b.source)===canonical(m.Source))),'BOUND_BINDS');
  ensure(v.RestartCount===0&&v.State?.OOMKilled===false&&['created','running'].includes(v.State.Status),'BOUND_CONTAINER_STATE');
}
export function dbGate(v,net,expected){
  base(v,{...expected,suffix:'-db',entrypoint:['/bin/sh','/tools/bound-db-supervisor.sh'],cmd:[]},'999:999',1073741824,128);
  ensure(eq(v.HostConfig.Tmpfs,TMPFS),'BOUND_TMPFS');
  for(const m of v.Mounts.filter(m=>m.Type==='tmpfs'))ensure(Object.hasOwn(TMPFS,m.Destination),'BOUND_TMPFS');
  networkGate(net,expected.networkId);
  const networks=v.NetworkSettings.Networks||{};
  ensure(Object.keys(networks).length===1&&networks[PREFIX+'-net']?.NetworkID===expected.networkId&&[expected.networkId,PREFIX+'-net'].includes(v.HostConfig.NetworkMode),'BOUND_DB_NETWORK');
  if(v.State.Running)ensure(typeof v.State.StartedAt==='string'&&v.State.StartedAt===expected.startedAt,'BOUND_STARTED_AT');
  return true;
}
export function inspectTarget(value,expected){
  closed(value,['run','source','systemIdentifier','database','oid','marker','owner','role','sessionRole','tls','schema']);
  ensure(value.run===RUN&&value.source===SOURCE&&typeof value.systemIdentifier==='string'&&/^[0-9]{10,20}$/.test(value.systemIdentifier)&&value.systemIdentifier===expected.systemIdentifier&&value.database==='test_estakada_trust'&&integer(value.oid)&&value.oid>0&&value.oid===expected.oid&&value.marker===expected.marker&&value.owner==='postgres'&&value.role==='trust_migrator'&&value.sessionRole==='trust_migrator'&&value.tls===true&&value.schema===expected.schema,'BOUND_UNIT_TARGET');
  return true;
}
// Controller may only advance after an independently verified successful predecessor.
export function phaseOrder(phase,previous){
  const required={INIT:'PRESERVATION_BEFORE',C:'INIT_ACCEPTED',T:'CAPACITY_ACCEPTED'}[phase];
  ensure(required&&previous?.scope===required&&previous.status==='PASS'&&previous.run===RUN&&hex(previous.resultSha)&&hex(previous.reviewSha),'BOUND_PHASE_ORDER');
}
