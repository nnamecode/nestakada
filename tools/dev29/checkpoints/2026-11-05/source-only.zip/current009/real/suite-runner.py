"""Standard Django suite with a guarded existing-new-UNIT setup hook.

Never creates/drops a database or changes test bodies, order, assertions/results.
"""
import ast
import contextlib
import json
import re
import sys
import types
from pathlib import Path

if __name__ == '__main__':
    sys.path[:0] = ['/tools', '/trust']
    # Trusted sibling under /tools in production; enables the same isolated CLI
    # ARG rejection smoke on the Windows host without importing any Django/DB.
    import importlib.util
    _spec = importlib.util.spec_from_file_location('unit_init', Path(__file__).resolve().with_name('unit_init.py'))
    _unit = importlib.util.module_from_spec(_spec)
    sys.modules['unit_init'] = _unit
    _spec.loader.exec_module(_unit)

from unit_init import RUN, UNIT, Rejected, canonical, digest, ensure, source_state, target_gate, validate_arg, parse_arg, SQL_IDENTITY, register_driver, arm_deadline


def expected_test_ids(root=Path('/trust/journal')):
    result = []
    for path in sorted(root.glob('test*.py')):
        tree = ast.parse(path.read_bytes(), filename=str(path))
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef):
                for method in node.body:
                    if isinstance(method, (ast.FunctionDef, ast.AsyncFunctionDef)) and method.name.startswith('test_'):
                        result.append('journal.' + path.stem + '.' + node.name + '.' + method.name)
    ensure(len(result) == 139 and len(set(result)) == 139, 'SOURCE_TEST_MANIFEST')
    return sorted(result)


def flatten_ids(suite):
    result = []
    for value in suite:
        if hasattr(value, 'id'):
            result.append(value.id())
        else:
            result.extend(flatten_ids(value))
    return result


def install_existing_guard(creation, arg, gate):
    """Patch only backend creation hooks, never the suite or test lifecycle."""
    old_create, old_destroy = creation._create_test_db, creation._destroy_test_db

    def existing(self, verbosity, autoclobber=False, keepdb=False):
        validate_arg(arg, 'BOUND29-SUITE')
        ensure(keepdb is True and self._get_test_db_name() == UNIT and
               self.connection.settings_dict['NAME'] == UNIT and
               self.connection.settings_dict['USER'] == 'trust_migrator', 'CREATE_TARGET')
        self.connection.close()
        gate(arg, stage='ready')  # Before base create_test_db's migration/setup.
        return UNIT             # No super(), _nodb_cursor or CREATE DATABASE.

    def never_drop(self, *args, **kwargs):
        raise Rejected('DROP_DATABASE_FORBIDDEN')

    creation._create_test_db = types.MethodType(existing, creation)
    creation._destroy_test_db = types.MethodType(never_drop, creation)

    def restore():
        creation._create_test_db, creation._destroy_test_db = old_create, old_destroy
    return restore


def run_guarded(arg, io):
    validate_arg(arg, 'BOUND29-SUITE')
    before = io.target_gate(arg, stage='ready')
    io.setup()                  # Production Django setup follows first target gate.
    runner = io.make_runner()   # Standard DiscoverRunner in production.
    wanted = io.expected_ids()
    ensure(len(wanted) == 139 and len(set(wanted)) == 139, 'EXPECTED_TEST_IDS')
    restore_creation = install_existing_guard(io.creation, arg, io.target_gate)
    old_build, old_run_suite = runner.build_suite, runner.run_suite
    observed = {'ids': None, 'outcome': None}

    def checked_build(*args, **kwargs):
        suite = old_build(*args, **kwargs)
        ids = flatten_ids(suite)
        ensure(len(ids) == 139 and len(set(ids)) == 139 and sorted(ids) == sorted(wanted), 'ACTUAL_DISCOVERY_139')
        observed['ids'] = ids
        return suite

    def observed_run_suite(*args, **kwargs):
        result = old_run_suite(*args, **kwargs)
        observed['outcome'] = {'testsRun': result.testsRun, 'failures': len(result.failures),
            'errors': len(result.errors), 'skipped': len(result.skipped),
            'expectedFailures': len(result.expectedFailures), 'unexpectedSuccesses': len(result.unexpectedSuccesses)}
        return result         # No result/assertion/count rewriting.

    runner.build_suite, runner.run_suite = checked_build, observed_run_suite
    restore_connections = lambda: None
    try:
        restore_connections = io.guard_connections()
        failures = runner.run_tests(['journal'])
    finally:
        runner.build_suite, runner.run_suite = old_build, old_run_suite
        restore_creation()
        restore_connections()
        io.close_connections()
    ensure(observed['ids'] is not None and observed['outcome'] is not None, 'SUITE_RESULT_MISSING')
    stats = observed['outcome']
    okay = failures == 0 and stats == {'testsRun': 139, 'failures': 0, 'errors': 0, 'skipped': 0,
                                       'expectedFailures': 0, 'unexpectedSuccesses': 0}
    if not okay:
        return {'status': 'FAIL', 'code': 'SUITE_OUTCOME', 'scope': 'BOUND29-standard-Django-suite',
                'runId': RUN, 'counts': stats, 'testIdsSha256': digest(observed['ids']), 'actual139Passed': False}
    after = io.target_gate(arg, stage='ready')
    ensure(io.source_fingerprint() == arg['sourceFingerprint'], 'FINAL_SOURCE')
    return {'status': 'PASS', 'scope': 'BOUND29-standard-Django-suite', 'runId': RUN,
            'counts': stats, 'testIdsSha256': digest(observed['ids']), 'actual139Passed': True,
            'before': before, 'after': after, 'originalClusterTouched': False}


class ProductionIO:
    target_gate = staticmethod(target_gate)
    source_fingerprint = staticmethod(source_state)
    expected_ids = staticmethod(expected_test_ids)

    def setup(self):
        import django
        ensure(django.get_version() == '5.2.18', 'DJANGO_PIN')
        django.setup()
        from django.conf import settings
        from django.db import connection
        ensure(set(settings.DATABASES) == {'default'} and connection.settings_dict['NAME'] == UNIT and
               connection.settings_dict['TEST']['NAME'] == UNIT and connection.settings_dict['USER'] == 'trust_migrator', 'DJANGO_DATABASES')
        self.creation = connection.creation

    def make_runner(self):
        from django.test.runner import DiscoverRunner
        return DiscoverRunner(verbosity=1, interactive=False, keepdb=True, parallel=0, failfast=False)

    def guard_connections(self):
        from django.db.backends.signals import connection_created
        uid = 'BOUND29-fresh-unit-identity-' + RUN

        def check(sender, connection, **kwargs):
            # This real, same-connection identity SELECT precedes test SQL. It is
            # backend initialization, not a test assertion/result monkeypatch.
            raw = connection.connection
            register_driver(raw)
            try:
                validate_arg(self.arg, 'BOUND29-SUITE')
                ensure(connection.settings_dict['NAME'] == UNIT and connection.settings_dict['USER'] == 'trust_migrator'
                       and connection.settings_dict['HOST'] == 'trust-db', 'THREAD_CONNECTION_TARGET')
                with raw.cursor() as cursor:
                    cursor.execute(SQL_IDENTITY)
                    expected = self.arg['expected']
                    ensure(cursor.fetchone() == (UNIT, 'trust_migrator', 'trust_migrator', expected['oid'],
                        'postgres', expected['marker'], True, expected['systemIdentifier']), 'THREAD_ACTUAL_IDENTITY')
            except BaseException:
                connection.close()
                raise

        connection_created.connect(check, dispatch_uid=uid, weak=False)
        return lambda: connection_created.disconnect(dispatch_uid=uid)

    def close_connections(self):
        from django.db import connections
        connections.close_all()


def execute(arg, io=None):
    try:
        if io is None:
            io = ProductionIO()
            io.arg = arg
        return run_guarded(arg, io)
    except Rejected:
        raise
    except BaseException:
        raise Rejected('SUITE_EXECUTION_FAILED') from None


def main():
    raw = sys.stdin.buffer.read(16385)
    ensure(len(raw) <= 16384, 'INPUT_BOUND')
    arg = parse_arg(raw)
    validate_arg(arg, 'BOUND29-SUITE')
    disarm = arm_deadline(240)
    try:
        # Preserve standard test output in host-protected stderr; stdout remains
        # a single bounded machine result frame, never mixed with raw suite logs.
        with contextlib.redirect_stdout(sys.stderr):
            value = execute(arg)
    finally:
        disarm()
    output = canonical(value)
    ensure(len(output) <= 1048576, 'OUTPUT_BOUND')
    sys.stdout.buffer.write(output + b'\n')
    return 0 if value['status'] == 'PASS' else 1


if __name__ == '__main__':
    try:
        exit_code = main()
    except BaseException as error:
        code = error.args[0] if isinstance(error, Rejected) and error.args else 'SUITE_EXECUTION_FAILED'
        if type(code) is not str or not re.fullmatch('[A-Z][A-Z0-9_]{0,79}', code): code = 'SUITE_REJECTED'
        sys.stdout.buffer.write(canonical({'status': 'FAIL', 'code': code}) + b'\n')
        exit_code = 1
    raise SystemExit(exit_code)
