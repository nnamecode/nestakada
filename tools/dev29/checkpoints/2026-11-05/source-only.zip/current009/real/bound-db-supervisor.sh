#!/bin/sh
# BOUND29 fixed PID1; no command/stdin control plane. NOT_RUNTIME_QUALIFIED.
# Requires reviewed mount/resource/source guards before container start.
set -eu
umask 077
LC_ALL=C
export LC_ALL
PGDATA=/var/lib/postgresql/18/docker
export PGDATA
unset PGPASSWORD PGSERVICE PGSERVICEFILE PGOPTIONS PGHOST PGPORT PGUSER PGDATABASE POSTGRES_INITDB_WALDIR
RUN=066dd89b-2727-4d6d-a16a-b17bdccd9f92
STATE=NOT_STARTED
SEQ=0
CHILD=
AUX=
FINISHED=0
FINALIZING=0
RECORDS=/var/run/postgresql/supervisor-records.jsonl
NONCE=
SYSTEM_ID=
MOUNT_FACTS=
CONTENT_DIGEST=
MOUNT_DIGEST=
FRAME_COUNT=0
FRAME_BYTES=0

emit_frame() {
    # This is the owned attach stream, never unfiltered child/stdout or SQL.
    frame=$1
    size=${#frame}
    [ "$size" -lt 4096 ] || return 1
    FRAME_COUNT=$((FRAME_COUNT + 1))
    FRAME_BYTES=$((FRAME_BYTES + size + 1))
    [ "$FRAME_COUNT" -le 16 ] && [ "$FRAME_BYTES" -le 1048576 ] || return 1
    printf '%s\n' "$frame" || return 1
    # Optional live metadata cache; not the durable source of final-stop proof.
    printf '%s\n' "$frame" >> "$RECORDS" 2>/dev/null || :
}

emit_status() {
    SEQ=$((SEQ + 1))
    # All interpolated values below originate from closed numeric/hex validators.
    frame=$(printf '{"runId":"%s","sequence":%s,"state":"%s","status":"%s","pid1":%s,"childPid":%s,"nonce":"%s","systemIdentifier":"%s","mountDigest":"%s","contentDigest":"%s","code":"%s"}' \
        "$RUN" "$SEQ" "$STATE" "$1" "$$" "${CHILD:-0}" "$NONCE" "$SYSTEM_ID" "$MOUNT_DIGEST" "$CONTENT_DIGEST" "$2")
    emit_frame "$frame"
}

record() {
    emit_status "$1" ''
}

die() {
    # Error codes are fixed literals; never include SQL/output/secret values.
    emit_status FAIL "$1" || :
    exit 1
}

child_parent() {
    [ -r "/proc/$1/stat" ] || return 1
    /usr/bin/awk '{ p=index($0,") "); a=substr($0,p+2); split(a,f," "); print f[2] }' "/proc/$1/stat"
}

child_state() {
    [ -r "/proc/$1/stat" ] || return 1
    /usr/bin/awk '{ p=index($0,") "); print substr($0,p+2,1) }' "/proc/$1/stat"
}

owned_signal() {
    p=$1
    if [ -r "/proc/$p/stat" ]; then
        [ "$(child_parent "$p")" = "$$" ] || return 1
        kill -s "$2" "$p"
    fi
}

reap_bounded() {
    p=$1
    ticks=0
    while [ -r "/proc/$p/stat" ] && [ "$(child_state "$p")" != Z ]; do
        [ "$(child_parent "$p")" = "$$" ] || return 1
        if [ "$ticks" -ge 10 ]; then
            owned_signal "$p" KILL || return 1
            wait "$p" 2>/dev/null || :
            return 1
        fi
        /usr/bin/sleep 1
        ticks=$((ticks + 1))
    done
    if wait "$p" 2>/dev/null; then return 0; else return 1; fi
}

exit_cleanup() {
    # Cleanup never launches SQL or another postmaster and never claims success.
    if [ -n "$AUX" ]; then
        owned_signal "$AUX" INT || :
        reap_bounded "$AUX" || :
        AUX=
    fi
    if [ -n "$CHILD" ]; then
        owned_signal "$CHILD" INT || :
        reap_bounded "$CHILD" || :
        CHILD=
    fi
    if [ "$FINISHED" != 1 ]; then
        emit_status FAIL SUPERVISOR_INCOMPLETE || :
    fi
}

mount_facts() {
    [ ! -L /var/lib/postgresql ] && [ ! -L /var/lib/postgresql/18 ] && [ ! -L "$PGDATA" ] || return 1
    [ "$(/usr/bin/stat -f -c '%T' /var/lib/postgresql)" = tmpfs ] || return 1
    block=$(/usr/bin/stat -f -c '%S' /var/lib/postgresql)
    blocks=$(/usr/bin/stat -f -c '%b' /var/lib/postgresql)
    [ $((block * blocks)) -eq 536870912 ] || return 1
    /usr/bin/awk '$5=="/var/lib/postgresql" { for(i=1;i<=NF;i++) if($i=="-") { if($(i+1)!="tmpfs") exit 1; print $1 ":" $2 ":" $5 ":" $(i+1) ":" $(i+3); found++ } } END { if(found!=1) exit 1 }' /proc/self/mountinfo
}

control_identity() {
    control=$(/usr/bin/timeout --signal=INT --kill-after=1s 2s /usr/local/pgsql/bin/pg_controldata "$PGDATA") || return 1
    printf '%s\n' "$control" | \
        /usr/bin/awk -F: '$1=="Database system identifier" {gsub(/^ +| +$/,"",$2);print $2}'
}

clean_control() {
    control=$(/usr/bin/timeout --signal=INT --kill-after=1s 2s /usr/local/pgsql/bin/pg_controldata "$PGDATA") || return 1
    printf '%s\n' "$control" | \
        /usr/bin/awk -F: '$1=="Database cluster state" {gsub(/^ +| +$/,"",$2);print $2}' | \
        /usr/bin/grep -qx 'shut down'
}

content_digest() {
    # No sockets/devices/symlinks or out-of-envelope WAL/tablespace links.
    [ -d "$PGDATA/pg_wal" ] && [ ! -L "$PGDATA/pg_wal" ] || return 1
    [ -d "$PGDATA/pg_tblspc" ] || return 1
    bad=$(/usr/bin/find "$PGDATA/pg_tblspc" -mindepth 1 -print -quit) || return 1
    [ -z "$bad" ] || return 1
    bad=$(/usr/bin/find "$PGDATA" ! -type d ! -type f -print -quit) || return 1
    [ -z "$bad" ] || return 1
    /usr/bin/find "$PGDATA" -type f -print0 > /var/run/postgresql/content-files || return 1
    /usr/bin/sort -z /var/run/postgresql/content-files -o /var/run/postgresql/content-files || return 1
    /usr/bin/xargs -0 /usr/bin/sha256sum -- < /var/run/postgresql/content-files > /var/run/postgresql/content-hashes || return 1
    summed=$(/usr/bin/sha256sum /var/run/postgresql/content-hashes) || return 1
    printf '%s\n' "${summed%% *}"
}

config_identity() {
    actual=$(/usr/bin/sha256sum /config/bootstrap.hba) || return 1
    [ "${actual%% *}" = 528cf35647c7df33b8366f51b1f49eaa07c6cdefc66ad179ea49bf13b437d0ed ] || return 1
    actual=$(/usr/bin/sha256sum /config/runtime.hba) || return 1
    [ "${actual%% *}" = 4c2aa75544a7b6ce52c4a9aa2d18836a607c8f4a148d334bef8df314778d891b ] || return 1
    actual=$(/usr/bin/sha256sum /config/bootstrap.sql) || return 1
    [ "${actual%% *}" = a72b7931b62441772ca7a9a47a254708ac60997bc146e2cbbb20f128cdabe12d ]
}

continuity() {
    config_identity || return 1
    [ "$(mount_facts)" = "$MOUNT_FACTS" ] || return 1
    [ "$(/usr/bin/readlink -f "$PGDATA")" = "$PGDATA" ] || return 1
    [ "$(/usr/bin/cat /var/run/postgresql/init-nonce)" = "$NONCE" ] || return 1
    [ "$(/usr/bin/cat "$PGDATA/.bound29-nonce")" = "$NONCE" ] || return 1
    [ "$(control_identity)" = "$SYSTEM_ID" ] || return 1
}

stop_child_clean() {
    [ -n "$CHILD" ] || return 1
    [ -r "/proc/$CHILD/stat" ] && [ "$(child_state "$CHILD")" != Z ] || return 1
    [ "$(child_parent "$CHILD")" = "$$" ] || return 1
    record STOP_REQUESTED
    owned_signal "$CHILD" INT || return 1
    p=$CHILD
    if reap_bounded "$p"; then CHILD=; else CHILD=; return 1; fi
    clean_control && continuity || return 1
    CONTENT_DIGEST=$(content_digest) || return 1
    printf '%s' "$CONTENT_DIGEST" | /usr/bin/grep -Eq '^[0-9a-f]{64}$'
}

final_stop() {
    [ "$FINALIZING" = 0 ] || exit 1
    FINALIZING=1
    trap '' TERM INT HUP
    if [ -n "$AUX" ]; then die SIGNAL_DURING_INIT_OR_SQL; fi
    if [ -n "$CHILD" ]; then stop_child_clean || die FINAL_CHILD_STOP_UNPROVED
    else clean_control && continuity || die FINAL_CONTROL_UNPROVED
        CONTENT_DIGEST=$(content_digest) || die FINAL_DIGEST_UNPROVED
    fi
    STATE=FINAL_CLEAN_STOP
    record STOPPED
    FINISHED=1
    exit 0
}

transition() {
    case "$STATE:$1" in
        NOT_STARTED:INITDB|INITDB:BOOTSTRAP_SOCKET_ONLY|BOOTSTRAP_SOCKET_ONLY:CLEAN_CHILD_STOP|CLEAN_CHILD_STOP:RUNTIME_TLS) ;;
        *) die INVALID_TRANSITION ;;
    esac
    STATE=$1
    record ENTERED
}

ready() {
    ticks=0
    while ! /usr/local/pgsql/bin/pg_isready -q -h /var/run/postgresql -p 5432; do
        [ -n "$CHILD" ] && [ -r "/proc/$CHILD/stat" ] && [ "$(child_state "$CHILD")" != Z ] || return 1
        [ "$ticks" -lt 5 ] || return 1
        /usr/bin/sleep 1
        ticks=$((ticks + 1))
    done
    [ "$(child_parent "$CHILD")" = "$$" ]
}

[ "$#" -eq 0 ] || exit 1
[ "$$" -eq 1 ] || exit 1
[ "$(/usr/bin/id -u)" = 999 ] && [ "$(/usr/bin/id -g)" = 999 ] || exit 1
[ ! -e "$RECORDS" ] && [ ! -e /var/run/postgresql/init-nonce ] && [ ! -e "$PGDATA" ] || exit 1
trap exit_cleanup 0
trap final_stop TERM INT HUP
MOUNT_FACTS=$(mount_facts) || die MOUNT_GATE
mount_sum=$(printf '%s' "$MOUNT_FACTS" | /usr/bin/sha256sum)
MOUNT_DIGEST=${mount_sum%% *}
NONCE=$(/usr/bin/od -An -N16 -tx1 /dev/urandom | /usr/bin/tr -d ' \n')
printf '%s' "$NONCE" | /usr/bin/grep -Eq '^[0-9a-f]{32}$' || die NONCE_FORMAT
printf '%s\n' "$NONCE" > /var/run/postgresql/init-nonce
for config in /config/bootstrap.hba /config/runtime.hba /config/bootstrap.sql; do
    [ -f "$config" ] && [ ! -L "$config" ] || die CONFIG_TYPE
done
config_identity || die CONFIG_DIGEST
for secret in /run/secrets/bootstrap-password /run/secrets/migrator-password; do
    [ -f "$secret" ] && [ ! -L "$secret" ] || die SECRET_TYPE
    count=$(/usr/bin/wc -c < "$secret")
    [ "$count" -eq 96 ] || [ "$count" -eq 97 ] || die SECRET_SIZE
    /usr/bin/grep -Eq '^[0-9a-f]{96}$' "$secret" || die SECRET_FORMAT
done
/usr/bin/cp /run/secrets/database-server-key /var/run/postgresql/server.key
/usr/bin/chmod 600 /var/run/postgresql/server.key
transition INITDB
/usr/bin/timeout --signal=INT --kill-after=2s 30s /usr/local/pgsql/bin/initdb \
    --pgdata="$PGDATA" --username=postgres --auth-local=peer --auth-host=reject \
    --encoding=UTF8 --locale=en_US.utf8 > /dev/null 2>&1 &
AUX=$!
if wait "$AUX"; then AUX=; else AUX=; die INITDB_FAILED; fi
printf '%s\n' "$NONCE" > "$PGDATA/.bound29-nonce"
SYSTEM_ID=$(control_identity)
printf '%s' "$SYSTEM_ID" | /usr/bin/grep -Eq '^[0-9]{10,20}$' || die SYSTEM_IDENTIFIER
continuity || die INIT_CONTINUITY
/usr/local/pgsql/bin/postgres -D "$PGDATA" -c data_directory="$PGDATA" \
    -c hba_file=/config/bootstrap.hba -c listen_addresses= -c unix_socket_directories=/var/run/postgresql \
    -c port=5432 -c ssl=off -c password_encryption=scram-sha-256 -c log_statement=none -c log_min_error_statement=panic \
    -c log_error_verbosity=terse -c logging_collector=off -c max_connections=16 -c shared_buffers=64MB \
    -c max_wal_size=128MB -c min_wal_size=32MB -c fsync=on -c synchronous_commit=on -c full_page_writes=on \
    > /dev/null 2>&1 &
CHILD=$!
transition BOOTSTRAP_SOCKET_ONLY
ready || die BOOTSTRAP_NOT_READY
/usr/bin/timeout --signal=INT --kill-after=2s 15s /usr/local/pgsql/bin/psql --no-psqlrc --no-password \
    --quiet --host=/var/run/postgresql --port=5432 --username=postgres --dbname=postgres \
    --set=ON_ERROR_STOP=1 --set=VERBOSITY=terse --file=/config/bootstrap.sql > /dev/null 2>&1 &
AUX=$!
if wait "$AUX"; then AUX=; else AUX=; die BOOTSTRAP_SQL_FAILED; fi
stop_child_clean || die BOOTSTRAP_CHILD_STOP_UNPROVED
transition CLEAN_CHILD_STOP
clean_control && continuity || die PRE_RUNTIME_CONTROL
[ "$(content_digest)" = "$CONTENT_DIGEST" ] || die PRE_RUNTIME_CONTENT_DRIFT
/usr/local/pgsql/bin/postgres -D "$PGDATA" -c data_directory="$PGDATA" \
    -c hba_file=/config/runtime.hba -c listen_addresses='*' -c unix_socket_directories=/var/run/postgresql \
    -c port=5432 -c ssl=on -c ssl_cert_file=/run/secrets/database-ca -c ssl_key_file=/var/run/postgresql/server.key \
    -c ssl_min_protocol_version=TLSv1.2 -c password_encryption=scram-sha-256 \
    -c log_statement=none -c log_min_error_statement=panic -c log_error_verbosity=terse -c logging_collector=off \
    -c max_connections=16 -c shared_buffers=64MB -c max_wal_size=128MB -c min_wal_size=32MB \
    -c archive_mode=off -c archive_command= -c restore_command= -c max_replication_slots=0 \
    -c temp_tablespaces= -c default_tablespace= -c fsync=on -c synchronous_commit=on -c full_page_writes=on \
    > /dev/null 2>&1 &
CHILD=$!
transition RUNTIME_TLS
ready || die RUNTIME_NOT_READY
continuity || die RUNTIME_CONTINUITY
record READY
while :; do
    if [ ! -r "/proc/$CHILD/stat" ] || [ "$(child_state "$CHILD")" = Z ]; then
        wait "$CHILD" 2>/dev/null || :
        CHILD=
        die UNEXPECTED_RUNTIME_CHILD_EXIT
    fi
    [ "$(child_parent "$CHILD")" = "$$" ] || die RUNTIME_CHILD_NOT_DIRECT
    /usr/bin/sleep 1
done
