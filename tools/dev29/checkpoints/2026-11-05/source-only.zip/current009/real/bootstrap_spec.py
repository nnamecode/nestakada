"""Offline cross-package qualification of the only permitted bootstrap delta."""
import hashlib
import re
from unit_init import RUN, Rejected, ensure

BASE_SQL_SHA = 'e51dc9ae885548056d2e74bf2dd6cfe9fb2d9ad14b8920bed0720a14130bc0c3'


def qualify(sql, supervisor, base_sql, base_supervisor):
    ensure(hashlib.sha256(base_sql).hexdigest() == BASE_SQL_SHA, 'BOOT_BASE_BINDING')
    ensure(sql.startswith(base_sql), 'BOOT_BASE_DDL_CHANGED')
    delta = sql[len(base_sql):].decode('ascii')
    # Only two fixed database comments are allowed in addition to reviewed DDL.
    lines = [line.strip() for line in delta.splitlines() if line.strip() and not line.lstrip().startswith('--')]
    expected = ["COMMENT ON DATABASE estakada_trust IS 'BOUND29-MAIN:" + RUN + "';",
                "COMMENT ON DATABASE test_estakada_trust IS 'BOUND29-UNIT:" + RUN + "';"]
    ensure(lines == expected, 'BOOT_MARKER_CONTRACT')
    digest = hashlib.sha256(sql).hexdigest()
    old = base_supervisor.decode('ascii')
    ensure(old.count(BASE_SQL_SHA) == 1, 'BOOT_OLD_PIN')
    ensure(supervisor.decode('ascii') == old.replace(BASE_SQL_SHA, digest).replace('1e23c654-5baf-4b5e-a7b4-6235b1289c0a', RUN), 'BOOT_SUPERVISOR_EQUIVALENCE')
    # The unchanged process automaton waits for successful bootstrap SQL before
    # child clean stop and starting the runtime HBA. This is source qualification,
    # not execution/SQL syntax proof; real INIT will measure the actual comment.
    psql = old.index('--file=/config/bootstrap.sql')
    wait = old.index('if wait "$AUX"', psql)
    stop = old.index('stop_child_clean || die BOOTSTRAP_CHILD_STOP_UNPROVED', wait)
    runtime = old.index('-c hba_file=/config/runtime.hba', stop)
    ensure(psql < wait < stop < runtime, 'BOOT_TRANSITION_ORDER')
    return {'scope': 'BOUND29-bootstrap-source-equivalence', 'status': 'PASS',
            'bootstrapSqlSha256': digest, 'marker': 'BOUND29-UNIT:' + RUN,
            'controlFlowChanged': False, 'realSqlExecuted': False,
            'qualification': 'NOT_RUNTIME_QUALIFIED'}
