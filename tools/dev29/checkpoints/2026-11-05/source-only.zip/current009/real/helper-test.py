"""Offline injected contracts only: no Django/psycopg import or SQL execution."""
import copy
import datetime
import importlib.util
import os
import subprocess
import sys
import types
import unittest
from contextlib import nullcontext
from pathlib import Path
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
def load(name, file):
    spec = importlib.util.spec_from_file_location(name, HERE / file)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module
U = load('unit_init', 'unit_init.py')
S = load('bound_suite_runner', 'suite-runner.py')
ENV = {'TRUST_DB_NAME': U.UNIT, 'TRUST_DB_HOST': 'trust-db', 'TRUST_DB_USER': 'trust_migrator',
       'TRUST_DB_PASSWORD_FILE': '/run/secrets/database-password', 'TRUST_DB_CA': '/run/secrets/database-ca',
       'DJANGO_SETTINGS_MODULE': 'trust_service.settings', 'TRUST_WRITE_PROFILE': 'disabled', 'TRUST_TEST_EXECUTION': '1'}

def argument(scope='BOUND29-SUITE'):
    return {'scope': scope, 'runId': U.RUN, 'planSha256': 'a' * 64, 'packageSha256': 'b' * 64,
        'admissionSha256': 'c' * 64, 'provenanceSha256': 'd' * 64, 'sourceFingerprint': 'e' * 64,
        'expiresUtc': (datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(seconds=800)).isoformat().replace('+00:00', 'Z'),
        'expected': {'database': U.UNIT, 'oid': 24577, 'owner': 'postgres', 'role': 'trust_migrator',
            'marker': 'BOUND29-UNIT:' + U.RUN, 'systemIdentifier': '1234567890123456789',
            'schemaFingerprint': None if scope == 'BOUND29-INIT' else 'f' * 64,
            'migrations': [] if scope == 'BOUND29-INIT' else U.MIGRATIONS[:]}}

class FakeCursor:
    def __init__(self, rows): self.rows = rows
    def fetchone(self): return self.rows[0]
    def fetchall(self): return self.rows

class FakeConnection:
    def __init__(self, arg, empty=False, damage=None):
        self.arg, self.empty, self.damage = arg, empty, damage
        self.calls = []; self.connects = 0; self.password_reads = 0; self.closed = False
    def __enter__(self): return self
    def __exit__(self, *args): self.closed = True
    def transaction(self): return nullcontext()
    def connect(self, **kwargs):
        self.connects += 1
        assert kwargs['dbname'] == U.UNIT and kwargs['host'] == 'trust-db' and kwargs['user'] == 'trust_migrator'
        assert kwargs['sslmode'] == 'verify-full' and kwargs['sslrootcert'] == '/run/secrets/database-ca'
        return self
    def password(self): self.password_reads += 1; return '0' * 96
    def execute(self, sql, params=None):
        self.calls.append(sql)
        assert sql.lstrip().startswith(('SELECT', 'SET TRANSACTION')), 'DDL entered read-only gate'
        e = self.arg['expected']
        if sql == U.SQL_IDENTITY:
            row = [U.UNIT, 'trust_migrator', 'trust_migrator', e['oid'], 'postgres', e['marker'], True, e['systemIdentifier']]
            if isinstance(self.damage, tuple): row[self.damage[0]] = self.damage[1]
            return FakeCursor([tuple(row)])
        if 'transaction_read_only' in sql: return FakeCursor([('on',)])
        if 'pg_stat_activity' in sql: return FakeCursor([(1 if self.damage == 'session' else 0,)])
        if 'pg_get_userbyid(nspowner)' in sql: return FakeCursor([('other' if self.damage == 'schema-owner' else 'trust_migrator',)])
        if 'FROM pg_tables' in sql:
            rows = [] if self.empty else [(name, 'trust_migrator') for name in sorted([*U.TABLES, 'django_migrations'])]
            if self.damage == 'nonempty-init': rows = [('journal_head', 'trust_migrator')]
            return FakeCursor(rows)
        if 'format_type(a.atttypid' in sql: return FakeCursor([(name, 'trust', 1, 'id', 'uuid', True, None) for name in U.TABLES])
        if any(k in sql for k in ('pg_constraint', 'pg_index', 'pg_trigger')): return FakeCursor([])
        if 'SELECT app,name' in sql: return FakeCursor([('journal', name) for name in U.MIGRATIONS])
        if 'SELECT count(*) FROM trust.' in sql: return FakeCursor([(1 if self.damage == 'nonempty-ready' else 0,)])
        return FakeCursor([])

class HelperTests(unittest.TestCase):
    def gate(self, arg, *, empty=False, damage=None):
        fake = FakeConnection(arg, empty=empty, damage=damage)
        if not empty: arg['expected']['schemaFingerprint'] = U.schema_fingerprint(fake)
        fake.calls.clear()
        with patch.dict(os.environ, ENV, clear=True):
            value = U.target_gate(arg, stage='empty' if empty else 'ready', connect=fake.connect,
                                  source_reader=lambda: arg['sourceFingerprint'], password_reader=fake.password)
        return value, fake
    def test_closed_metadata_before_any_connection_or_password(self):
        for mutate in (lambda a:a.update(extra=True), lambda a:a.update(scope='old'),lambda a:a.update(runId='old'),
            lambda a:a['expected'].update(database='estakada_trust'),lambda a:a['expected'].update(role='postgres'),
            lambda a:a['expected'].update(oid=True),lambda a:a['expected'].update(marker='ESTAKADA-DEV15-CAPACITY:old'),
            lambda a:a.update(expiresUtc='bad'),lambda a:a.update(sourceFingerprint='X' * 64)):
            arg = argument(); mutate(arg); fake = FakeConnection(arg)
            with self.subTest(arg=arg), patch.dict(os.environ, ENV, clear=True), self.assertRaises(U.Rejected):
                U.target_gate(arg, connect=fake.connect, source_reader=lambda:'e' * 64, password_reader=fake.password)
            self.assertEqual((fake.connects, fake.password_reads), (0, 0))
    def test_env_and_source_rejection_before_password(self):
        for source, changes in [('0'*64, {}), ('e'*64, {'TRUST_DB_NAME':'estakada_trust'}), ('e'*64, {'TRUST_DB_HOST':'foreign'})]:
            arg = argument(); fake = FakeConnection(arg)
            with patch.dict(os.environ, {**ENV, **changes}, clear=True), self.assertRaises(U.Rejected):
                U.target_gate(arg, connect=fake.connect, source_reader=lambda:source, password_reader=fake.password)
            self.assertEqual((fake.connects,fake.password_reads),(0,0))
    def test_actual_identity_and_empty_schema_readonly_gates(self):
        good, fake = self.gate(argument('BOUND29-INIT'), empty=True)
        self.assertEqual(good['migrations'], []); self.assertTrue(fake.closed)
        good, fake = self.gate(argument()); self.assertEqual(good['migrations'], U.MIGRATIONS)
        for damage in [(0,'estakada_trust'),(1,'postgres'),(2,'postgres'),(3,999),(4,'other'),(5,'other'),(6,False),(7,'9999999999999999999'),
                       'session','schema-owner','nonempty-ready']:
            with self.subTest(damage=damage), self.assertRaises(U.Rejected): self.gate(argument(), damage=damage)
        with self.assertRaises(U.Rejected): self.gate(argument('BOUND29-INIT'), empty=True, damage='nonempty-init')
    def test_parser_duplicate_and_invalid_constant(self):
        for raw in (b'{"scope":1,"scope":2}', b'{"x":NaN}', b' ' * 16385):
            with self.assertRaises(U.Rejected): U.parse_arg(raw)
    def test_expiry_and_ready_ledger_are_not_normalized(self):
        for seconds in (-1, 901):
            arg=argument();arg['expiresUtc']=(datetime.datetime.now(datetime.timezone.utc)+datetime.timedelta(seconds=seconds)).isoformat().replace('+00:00','Z')
            with self.assertRaises(U.Rejected): U.validate_arg(arg)
        for change in ({'migrations':[]},{'schemaFingerprint':None},{'systemIdentifier':'old-system-id'},{'owner':'other'}):
            arg=argument();arg['expected'].update(change)
            with self.assertRaises(U.Rejected): U.validate_arg(arg)
    def test_initializer_lifecycle_gate_before_setup_and_migrate(self):
        events=[]
        io=types.SimpleNamespace(target_gate=lambda arg,stage:events.append('gate:'+stage) or {'status':'PASS'},
            setup=lambda:events.append('setup'),migrate=lambda:events.append('migrate'),after_init=lambda:events.append('after') or {'status':'PASS'})
        U.execute(argument('BOUND29-INIT'),io); self.assertEqual(events,['gate:empty','setup','migrate','after'])
        events.clear()
        def reject(*args,**kwargs): events.append('gate-rejected');raise U.Rejected('DENY')
        io.target_gate=reject
        with self.assertRaises(U.Rejected): U.execute(argument('BOUND29-INIT'),io)
        self.assertEqual(events,['gate-rejected'])
    def test_deadline_profiles_close_registered_drivers_before_exit(self):
        for seconds in (90,240,600):
            events=[]
            class FakeSignal:
                SIGALRM=14
                def signal(self, number, handler):
                    events.append(('handler',number));self.handler=handler;return None
                def alarm(self, value): events.append(('alarm',value))
            fake=FakeSignal()
            U.ACTIVE_DRIVERS.clear()
            U.register_driver(types.SimpleNamespace(close=lambda:events.append(('close',))))
            def stop(code):
                events.append(('exit',code));raise SystemExit(code)
            disarm=U.arm_deadline(seconds,signal_api=fake,exit_process=stop)
            with self.assertRaises(SystemExit) as caught: fake.handler(14,None)
            self.assertEqual(caught.exception.code,124)
            self.assertLess(events.index(('close',)),events.index(('exit',124)))
            self.assertIn(('alarm',seconds),events)
            disarm();self.assertIn(('alarm',0),events)
    def test_isolated_cli_rejects_empty_arg_before_dependencies_or_sql(self):
        for file in ('unit_init.py','suite-runner.py'):
            process=subprocess.run([sys.executable,'-I','-B',str(HERE/file)],input=b'{}',capture_output=True,timeout=10)
            self.assertEqual(process.returncode,1,file)
            self.assertEqual(process.stderr,b'',file)
            self.assertEqual(U.parse_arg(process.stdout),{'status':'FAIL','code':'ARG_SCHEMA'})

class FakeCreation:
    def __init__(self, events):
        self.events=events
        self.connection=types.SimpleNamespace(settings_dict={'NAME':U.UNIT,'USER':'trust_migrator'},close=lambda:events.append('close-before-hook'))
    def _get_test_db_name(self): return U.UNIT
    def _create_test_db(self,*args,**kwargs): raise AssertionError('CREATE/nodb forbidden')
    def _destroy_test_db(self,*args,**kwargs): raise AssertionError('DROP forbidden')

class FakeRunner:
    def __init__(self, creation, events, count=139, failure=False): self.creation=creation;self.events=events;self.count=count;self.failure=failure
    def build_suite(self,*args,**kwargs): return [types.SimpleNamespace(id=lambda i=i:'journal.Exact.test_'+str(i)) for i in range(self.count)]
    def run_suite(self,suite,**kwargs):
        self.events.append('real-suite-placeholder')
        return types.SimpleNamespace(testsRun=self.count,failures=[1] if self.failure else [],errors=[],skipped=[],expectedFailures=[],unexpectedSuccesses=[])
    def run_tests(self,labels):
        self.events.append('build'); suite=self.build_suite(labels)
        self.events.append('base-create-test-db-before-super-migrate')
        self.creation._create_test_db(0,False,keepdb=True)
        self.events.append('base-migrate-only-after-reuse-guard')
        result=self.run_suite(suite);self.events.append('base-teardown-keepdb-no-drop')
        return len(result.failures)

class SuiteTests(unittest.TestCase):
    def io(self,count=139,failure=False):
        events=[];creation=FakeCreation(events);runner=FakeRunner(creation,events,count,failure)
        io=types.SimpleNamespace(creation=creation,make_runner=lambda:runner,setup=lambda:events.append('setup'),
            expected_ids=lambda:['journal.Exact.test_'+str(i) for i in range(139)],
            target_gate=lambda arg,stage:events.append('gate:'+stage) or {'status':'PASS'},
            source_fingerprint=lambda:'e'*64,guard_connections=lambda:lambda:events.append('disconnect-signal'),
            close_connections=lambda:events.append('close-all'))
        return io,events
    def test_fake_standard_lifecycle_and_target_guard_order(self):
        io,events=self.io();result=S.execute(argument(),io)
        self.assertEqual(result['status'],'PASS');self.assertEqual(events[:2],['gate:ready','setup'])
        before=events.index('base-create-test-db-before-super-migrate');after=events.index('base-migrate-only-after-reuse-guard')
        self.assertIn('gate:ready',events[before:after]);self.assertIn('close-before-hook',events[before:after])
        self.assertEqual(events[-1],'gate:ready')
    def test_discovery_mismatch_is_before_create_or_fixture(self):
        io,events=self.io(count=138)
        with self.assertRaises(U.Rejected): S.execute(argument(),io)
        self.assertNotIn('base-create-test-db-before-super-migrate',events)
    def test_failed_outcome_never_passes(self):
        io,events=self.io(failure=True);result=S.execute(argument(),io)
        self.assertEqual(result['status'],'FAIL');self.assertFalse(result['actual139Passed'])
    def test_creation_hook_refuses_keepdb_false_wrong_target_and_drop(self):
        arg=argument();events=[];creation=FakeCreation(events);restore=S.install_existing_guard(creation,arg,lambda *a,**k:None)
        try:
            with self.assertRaises(U.Rejected): creation._create_test_db(0,False,keepdb=False)
            creation.connection.settings_dict['NAME']='postgres'
            with self.assertRaises(U.Rejected): creation._create_test_db(0,False,keepdb=True)
            with self.assertRaises(U.Rejected): creation._destroy_test_db(U.UNIT,0)
        finally: restore()
    def test_signal_guard_setup_failure_restores_creation_and_closes(self):
        io,events=self.io();original=io.creation._create_test_db
        def fail(): raise RuntimeError('synthetic private detail must not escape')
        io.guard_connections=fail
        with self.assertRaises(U.Rejected) as caught: S.execute(argument(),io)
        self.assertEqual(str(caught.exception),'SUITE_EXECUTION_FAILED')
        self.assertEqual(io.creation._create_test_db,original)
        self.assertEqual(events[-1],'close-all')

if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=1).run(unittest.defaultTestLoader.loadTestsFromModule(sys.modules[__name__]))
    print(U.canonical({'status':'PASS' if result.wasSuccessful() else 'FAIL','scope':'BOUND29-helper-offline-injected-IO',
        'tests':result.testsRun,'isolatedCliArgSmokeProcesses':2,'actualDjango139Run':False,'actualSQLCalls':0,'actualConnections':0,'actualSecretReads':0}).decode())
    raise SystemExit(not result.wasSuccessful())
