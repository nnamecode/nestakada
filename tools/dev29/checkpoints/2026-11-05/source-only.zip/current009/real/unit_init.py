"""New tmpfs UNIT initializer and shared, pre-Django, read-only target gate.

Import is inert. This module has no signing key, Docker control or alternate DB.
"""
import ast
import contextlib
import datetime
import hashlib
import json
import os
import re
import signal
import stat
import sys
from pathlib import Path

if __name__ == '__main__':
    sys.path[:0] = ['/tools', '/trust']

RUN = '066dd89b-2727-4d6d-a16a-b17bdccd9f92'
UNIT = 'test_estakada_trust'
MIGRATIONS = ['0001_initial', '0002_local_test_recovery', '0003_admission_policy']
TABLES = ('journal_head', 'journal_credential', 'journal_operation', 'journal_routepolicy',
          'journal_requesttombstone', 'journal_recoveryreceipt', 'journal_admissionpolicy')
SQL_IDENTITY = """SELECT current_database(),current_user,session_user,d.oid,
pg_get_userbyid(d.datdba),shobj_description(d.oid,'pg_database'),
(SELECT ssl FROM pg_stat_ssl WHERE pid=pg_backend_pid()),
(SELECT system_identifier::text FROM pg_catalog.pg_control_system())
FROM pg_database d WHERE d.datname=current_database()"""
ACTIVE_DRIVERS = []


class Rejected(Exception):
    def __init__(self, code):
        self.code = code
        super().__init__(code)


def ensure(value, code):
    if not value:
        raise Rejected(code)


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(',', ':'), allow_nan=False).encode('utf-8')


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def register_driver(conn):
    if conn is not None and all(existing is not conn for existing in ACTIVE_DRIVERS):
        ACTIVE_DRIVERS.append(conn)


def close_drivers():
    # Includes the actual drivers registered by Django's thread connection guard.
    for conn in tuple(ACTIVE_DRIVERS):
        try:
            conn.close()
        except BaseException:
            pass
    ACTIVE_DRIVERS.clear()


def arm_deadline(seconds, signal_api=None, exit_process=None):
    signal_api = signal_api or signal
    exit_process = exit_process or os._exit
    ensure(seconds in (90, 240, 600) and hasattr(signal_api, 'SIGALRM'), 'DEADLINE_PLATFORM')
    def hard_stop(*args):
        try:
            close_drivers()
        finally:
            # unittest catches most Exception subclasses. Exit stops every test
            # thread and PID1 namespace child instead of continuing after timeout.
            exit_process(124)
    previous = signal_api.signal(signal_api.SIGALRM, hard_stop)
    signal_api.alarm(seconds)
    def disarm():
        signal_api.alarm(0)
        signal_api.signal(signal_api.SIGALRM, previous)
        close_drivers()
    return disarm


def parse_arg(raw):
    ensure(type(raw) is bytes and len(raw) <= 16384, 'INPUT_BOUND')
    def pairs(items):
        result = {}
        for name, value in items:
            ensure(name not in result, 'INPUT_DUPLICATE')
            result[name] = value
        return result
    def bad_constant(value):
        raise Rejected('INPUT_CONSTANT')
    return json.loads(raw.decode('utf-8'), object_pairs_hook=pairs, parse_constant=bad_constant)


def validate_arg(arg, allowed_scope=None, now=None):
    ensure(type(arg) is dict and set(arg) == {'scope', 'runId', 'planSha256', 'packageSha256',
        'admissionSha256', 'provenanceSha256', 'expiresUtc', 'sourceFingerprint', 'expected'}, 'ARG_SCHEMA')
    ensure(arg['scope'] in ('BOUND29-INIT', 'BOUND29-CAPACITY', 'BOUND29-SUITE') and
           (allowed_scope is None or arg['scope'] == allowed_scope) and arg['runId'] == RUN, 'ARG_SCOPE')
    for key in ('planSha256', 'packageSha256', 'admissionSha256', 'provenanceSha256', 'sourceFingerprint'):
        ensure(type(arg[key]) is str and re.fullmatch('[0-9a-f]{64}', arg[key]), 'ARG_HASH')
    ensure(type(arg['expiresUtc']) is str and arg['expiresUtc'].endswith('Z'), 'ARG_EXPIRY')
    try:
        expiry = datetime.datetime.fromisoformat(arg['expiresUtc'].replace('Z', '+00:00'))
        current = now or datetime.datetime.now(datetime.timezone.utc)
        remaining = (expiry - current).total_seconds()
        ensure(0 < remaining <= 900, 'ARG_EXPIRY')
    except (TypeError, ValueError, OverflowError):
        raise Rejected('ARG_EXPIRY') from None
    expected = arg['expected']
    ensure(type(expected) is dict and set(expected) == {'database', 'oid', 'marker', 'systemIdentifier',
        'owner', 'role', 'schemaFingerprint', 'migrations'}, 'EXPECTED_SCHEMA')
    ensure(expected['database'] == UNIT and expected['owner'] == 'postgres' and
           expected['role'] == 'trust_migrator' and type(expected['oid']) is int and expected['oid'] > 0,
           'EXPECTED_TARGET')
    ensure(expected['marker'] == 'BOUND29-UNIT:' + RUN and type(expected['systemIdentifier']) is str and
           re.fullmatch('[0-9]{10,20}', expected['systemIdentifier']), 'EXPECTED_IDENTITY')
    if arg['scope'] == 'BOUND29-INIT':
        ensure(expected['schemaFingerprint'] is None and expected['migrations'] == [], 'EXPECTED_EMPTY')
    else:
        ensure(type(expected['schemaFingerprint']) is str and
               re.fullmatch('[0-9a-f]{64}', expected['schemaFingerprint']) and
               expected['migrations'] == MIGRATIONS, 'EXPECTED_READY')
    return arg


def source_state():
    root = Path('/trust')
    ensure(root.is_dir() and not root.is_symlink(), 'SOURCE_ROOT')
    rows = []
    for path in sorted(root.rglob('*.py')):
        ensure(not path.is_symlink() and path.is_file() and
               all(not parent.is_symlink() for parent in path.parents if parent != root.parent), 'SOURCE_LINK')
        rows.append({'path': path.relative_to(root).as_posix(), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
    ensure(len(rows) == 31, 'SOURCE_COUNT')
    return digest(sorted(rows, key=lambda row: row['path']))


def password_bytes():
    path = Path('/run/secrets/database-password')
    mode = path.lstat()
    ensure(stat.S_ISREG(mode.st_mode) and not path.is_symlink() and mode.st_size in (96, 97), 'PASSWORD_FILE')
    raw = path.read_bytes()
    ensure(re.fullmatch(b'[0-9a-f]{96}\n?', raw), 'PASSWORD_FORMAT')
    return raw.rstrip(b'\n').decode('ascii')


def schema_fingerprint(conn):
    # Exact catalog framing of journal.profile.schema_fingerprint, without Django.
    tables = [list(TABLES)]
    columns = conn.execute('''SELECT c.relname,n.nspname,a.attnum,a.attname,
        format_type(a.atttypid,a.atttypmod),a.attnotnull,pg_get_expr(d.adbin,d.adrelid)
        FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
        JOIN pg_attribute a ON a.attrelid=c.oid AND a.attnum>0 AND NOT a.attisdropped
        LEFT JOIN pg_attrdef d ON d.adrelid=c.oid AND d.adnum=a.attnum
        WHERE c.oid=ANY(ARRAY(SELECT x::regclass FROM unnest(%s::text[]) x))
        ORDER BY c.relname,a.attnum''', tables).fetchall()
    constraints = conn.execute('''SELECT c.relname,k.conname,pg_get_constraintdef(k.oid,true)
        FROM pg_constraint k JOIN pg_class c ON c.oid=k.conrelid
        WHERE c.oid=ANY(ARRAY(SELECT x::regclass FROM unnest(%s::text[]) x))
        ORDER BY c.relname,k.conname''', tables).fetchall()
    indexes = conn.execute('''SELECT c.relname,i.relname,pg_get_indexdef(i.oid)
        FROM pg_index x JOIN pg_class c ON c.oid=x.indrelid JOIN pg_class i ON i.oid=x.indexrelid
        WHERE c.oid=ANY(ARRAY(SELECT x::regclass FROM unnest(%s::text[]) x))
        ORDER BY c.relname,i.relname''', tables).fetchall()
    triggers = conn.execute('''SELECT c.relname,t.tgname,pg_get_triggerdef(t.oid,true),pg_get_functiondef(t.tgfoid)
        FROM pg_trigger t JOIN pg_class c ON c.oid=t.tgrelid
        WHERE NOT t.tgisinternal AND c.oid=ANY(ARRAY(SELECT x::regclass FROM unnest(%s::text[]) x))
        ORDER BY c.relname,t.tgname''', tables).fetchall()
    migrations = conn.execute('SELECT app,name FROM django_migrations ORDER BY app,name').fetchall()
    ensure({row[0] for row in columns} == set(TABLES) and
           migrations == [('journal', name) for name in MIGRATIONS], 'SCHEMA_CATALOG')
    return digest({'columns': columns, 'constraints': constraints, 'indexes': indexes,
                   'triggers': triggers, 'migrations': migrations})


def target_gate(arg, stage='ready', connect=None, source_reader=None, password_reader=None):
    validate_arg(arg)
    ensure(stage in ('empty', 'initialized', 'ready') and
           (arg['scope'] == 'BOUND29-INIT' and stage in ('empty', 'initialized') or
            arg['scope'] != 'BOUND29-INIT' and stage == 'ready'), 'GATE_STAGE')
    ensure((source_reader or source_state)() == arg['sourceFingerprint'], 'SOURCE_FINGERPRINT')
    # Only fixed literal target/capabilities; ARG never selects host, SQL or file.
    ensure(os.environ.get('TRUST_DB_NAME') == UNIT and os.environ.get('TRUST_DB_HOST') == 'trust-db' and
           os.environ.get('TRUST_DB_USER') == 'trust_migrator' and
           os.environ.get('TRUST_DB_PASSWORD_FILE') == '/run/secrets/database-password' and
           os.environ.get('TRUST_DB_CA') == '/run/secrets/database-ca' and
           os.environ.get('DJANGO_SETTINGS_MODULE') == 'trust_service.settings' and
           os.environ.get('TRUST_WRITE_PROFILE') == 'disabled' and
           os.environ.get('TRUST_TEST_EXECUTION') == '1', 'ENV_TARGET')
    secret = (password_reader or password_bytes)()
    if connect is None:
        import psycopg
        connect = psycopg.connect
    expected = arg['expected']
    connection = connect(host='trust-db', port=5432, dbname=UNIT, user='trust_migrator', password=secret,
                 sslmode='verify-full', sslrootcert='/run/secrets/database-ca', connect_timeout=3,
                 autocommit=True, options='-c search_path=trust,pg_catalog -c default_transaction_read_only=on '
                 '-c statement_timeout=5000 -c lock_timeout=1000')
    register_driver(connection)
    with connection as conn:
        secret = None
        with conn.transaction():
            conn.execute('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ, READ ONLY')
            identity = conn.execute(SQL_IDENTITY).fetchone()
            ensure(identity == (UNIT, 'trust_migrator', 'trust_migrator', expected['oid'], 'postgres',
                   expected['marker'], True, expected['systemIdentifier']), 'ACTUAL_IDENTITY')
            ensure(conn.execute("SELECT current_setting('transaction_read_only')").fetchone() == ('on',), 'GATE_READONLY')
            ensure(conn.execute('SELECT count(*) FROM pg_stat_activity WHERE datid=%s AND pid<>pg_backend_pid()',
                                [expected['oid']]).fetchone() == (0,), 'FOREIGN_SESSION')
            ensure(conn.execute("SELECT pg_get_userbyid(nspowner) FROM pg_namespace WHERE nspname='trust'").fetchone()
                   == ('trust_migrator',), 'SCHEMA_OWNER')
            table_rows = conn.execute("SELECT tablename,tableowner FROM pg_tables WHERE schemaname='trust' ORDER BY tablename").fetchall()
            if stage == 'empty':
                ensure(table_rows == [], 'INIT_NOT_EMPTY')
                actual_schema = None
                ledger = []
            else:
                ensure(table_rows == [(name, 'trust_migrator') for name in sorted([*TABLES, 'django_migrations'])], 'READY_TABLES')
                ledger = conn.execute('SELECT app,name FROM trust.django_migrations ORDER BY app,name').fetchall()
                ensure(ledger == [('journal', name) for name in MIGRATIONS], 'MIGRATION_LEDGER')
                for table in TABLES:
                    ensure(conn.execute('SELECT count(*) FROM trust."' + table + '"').fetchone() == (0,), 'READY_NONEMPTY')
                actual_schema = schema_fingerprint(conn)
                if stage == 'ready':
                    ensure(actual_schema == expected['schemaFingerprint'], 'SCHEMA_FINGERPRINT')
    return {'status': 'PASS', 'scope': 'BOUND29-TARGET-GATE', 'runId': RUN, 'stage': stage,
            'oid': expected['oid'], 'marker': expected['marker'], 'systemIdentifier': expected['systemIdentifier'],
            'schemaFingerprint': actual_schema, 'migrations': [row[1] for row in ledger]}


def initialize(arg, io=None):
    validate_arg(arg, 'BOUND29-INIT')
    gate = (io.target_gate if io else target_gate)(arg, stage='empty')
    if io:
        io.setup()
        io.migrate()
        result = io.after_init()
    else:
        import django
        ensure(django.get_version() == '5.2.18', 'DJANGO_PIN')
        django.setup()
        from django.conf import settings
        from django.db import connection
        from django.db.backends.signals import connection_created
        from django.core.management import call_command
        ensure(settings.DATABASES['default']['NAME'] == UNIT and
               connection.settings_dict['USER'] == 'trust_migrator', 'DJANGO_TARGET')
        validate_arg(arg, 'BOUND29-INIT')
        def register(sender, connection, **kwargs):
            register_driver(connection.connection)
        uid = 'BOUND29-init-driver-' + RUN
        connection_created.connect(register, dispatch_uid=uid, weak=False)
        try:
            call_command('migrate', 'journal', '0003_admission_policy', verbosity=0, interactive=False, database='default')
        finally:
            connection_created.disconnect(dispatch_uid=uid)
            connection.close()
        # Measure source-compatible catalog only after migrations under the same
        # INIT authority; this does not invent a new SUITE admission.
        result = target_gate(arg, stage='initialized')
    return {'status': 'PASS', 'scope': 'BOUND29-UNIT-INITIALIZED', 'runId': RUN,
            'before': gate, 'after': result, 'originalClusterTouched': False}


def execute(arg, io=None):
    try:
        return initialize(arg, io)
    except Rejected:
        raise
    except BaseException:
        raise Rejected('UNIT_INIT_EXECUTION_FAILED') from None


def main():
    raw = sys.stdin.buffer.read(16385)
    ensure(len(raw) <= 16384, 'INPUT_BOUND')
    arg = parse_arg(raw)
    validate_arg(arg, 'BOUND29-INIT')
    disarm = arm_deadline(90)
    try:
        with contextlib.redirect_stdout(sys.stderr):
            value = execute(arg)
    finally:
        disarm()
    output = canonical(value)
    ensure(len(output) <= 1048576, 'OUTPUT_BOUND')
    sys.stdout.buffer.write(output + b'\n')


if __name__ == '__main__':
    try:
        main()
    except BaseException as error:
        code = error.args[0] if isinstance(error, Rejected) else 'UNIT_INIT_FAILED'
        if type(code) is not str or not re.fullmatch('[A-Z][A-Z0-9_]{0,79}', code): code = 'UNIT_INIT_FAILED'
        sys.stdout.buffer.write(canonical({'status': 'FAIL', 'code': code}) + b'\n')
        raise SystemExit(1) from None
