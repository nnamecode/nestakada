import pathlib
import sys
import unittest
HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from bootstrap_spec import qualify, BASE_SQL_SHA
from unit_init import Rejected, RUN
BASE = HERE.parent / 'qa-resume-001'


class BootstrapContract(unittest.TestCase):
    def setUp(self):
        self.sql = (HERE / 'bootstrap.sql').read_bytes()
        self.supervisor = (HERE / 'bound-db-supervisor.sh').read_bytes()
        self.old_sql = (BASE / 'bootstrap.sql').read_bytes()
        self.old_supervisor = (BASE / 'bound-db-supervisor.sh').read_bytes()
    def test_valid_metadata_only_delta_matches_helper_marker(self):
        result = qualify(self.sql, self.supervisor, self.old_sql, self.old_supervisor)
        self.assertEqual(result['status'], 'PASS')
        self.assertEqual(result['marker'], 'BOUND29-UNIT:' + RUN)
        self.assertFalse(result['controlFlowChanged'])
        self.assertFalse(result['realSqlExecuted'])
    def test_missing_wrong_or_extra_metadata_cannot_qualify(self):
        for sql in [self.old_sql, self.sql.replace(b'BOUND29-UNIT:', b'WRONG-UNIT:'),
                    self.sql + b'CREATE DATABASE other;\n',
                    self.sql.replace(RUN.encode(), b'00000000-0000-0000-0000-000000000000')]:
            with self.subTest(case=sql[-80:]), self.assertRaises(Rejected):
                qualify(sql, self.supervisor, self.old_sql, self.old_supervisor)
    def test_changed_bootstrap_privileges_rejected(self):
        sql = self.sql.replace(b'NOSUPERUSER', b'SUPERUSER')
        with self.assertRaisesRegex(Rejected, '^BOOT_BASE_DDL_CHANGED$'):
            qualify(sql, self.supervisor, self.old_sql, self.old_supervisor)
    def test_wrong_pin_or_control_flow_changes_rejected(self):
        for source in [self.old_supervisor, self.supervisor + b'\nexit 0\n',
                       self.supervisor.replace(b'local-bounded-writer', b'changed') if b'local-bounded-writer' in self.supervisor else self.supervisor.replace(b'RUNTIME_TLS', b'UNSAFE_RUNTIME')]:
            with self.subTest(case=source[-80:]), self.assertRaises(Rejected):
                qualify(self.sql, source, self.old_sql, self.old_supervisor)
    def test_both_hba_files_remain_byte_exact(self):
        for name in ('bootstrap.hba', 'runtime.hba'):
            self.assertEqual((HERE / name).read_bytes(), (BASE / name).read_bytes())


if __name__ == '__main__':
    unittest.main(verbosity=1)
