"""BOUND29 real 1000/1001 service boundary, outer rollback only.

No runner/flush/migrate/DDL, count injection, bulk seed or lowered caps.
The fixture supplies service-only policy/lease/resource facts, not native proof.
"""
import copy
import datetime
import hashlib
import json
import re
import signal
import sys
from pathlib import Path
from unittest.mock import patch

if __name__ == '__main__':
    sys.path[:0] = ['/tools', '/trust', str(Path(__file__).resolve().parent)]

from unit_init import RUN, TABLES, Rejected, canonical, digest, ensure, parse_arg, target_gate, validate_arg, arm_deadline, register_driver

CAPS = {'logicalBytes': 67108864, 'completionBytes': 16777216, 'maxOperations': 1000,
        'maxHistoricalReferences': 4096, 'maxTombstones': 1024, 'maxRecoveryActions': 4,
        'maxCredentials': 20, 'maxPolicyRows': 16, 'maxPolicyRowBytes': 32768,
        'maxMessageBytes': 1048576, 'maxTargets': 256, 'maxTargetBytes': 2048}
KEYS = {'django_migrations': 'id', 'journal_head': 'id', 'journal_credential': 'id',
        'journal_operation': 'id', 'journal_routepolicy': 'key',
        'journal_requesttombstone': 'request_id', 'journal_recoveryreceipt': 'id',
        'journal_admissionpolicy': 'id'}


def frame(hasher, value):
    data = canonical(value)
    hasher.update(len(data).to_bytes(8, 'big'))
    hasher.update(data)


def check_sql(sql):
    ensure(type(sql) is str and len(sql) <= 65536, 'CAP_SQL_SHAPE')
    text = ' '.join(sql.strip().split()).upper()
    ensure(';' not in text and '--' not in text and '/*' not in text, 'CAP_SQL_MULTI')
    ensure(not re.search(r'\b(SETVAL|NEXTVAL|PG_TERMINATE_BACKEND|PG_CANCEL_BACKEND)\s*\(', text), 'CAP_SQL_FUNCTION')
    ensure(re.match(r'^(SELECT\b|INSERT\b|UPDATE\b|DELETE\b|SAVEPOINT\b|RELEASE SAVEPOINT\b|ROLLBACK TO SAVEPOINT\b)', text), 'CAP_SQL_LIFECYCLE')


def exercise(api):
    """Same finite loop drives real service adapter and injected rule tests."""
    pending = []
    receipts = hashlib.sha256(b'BOUND29-CAPACITY-RECEIPTS-v1\x00')
    for index in range(1000):
        policy = 'HIDDEN' if index % 2 == 0 else 'LIVE_NO_SET'
        item = api.prepare(index, policy)
        ensure(item['prepared']['replay'] is False and item['policy'] == policy, 'CAP_PREPARE')
        frame(receipts, item['prepared']['phaseReceipt'])
        if index < 2:
            pending.append(item)
        else:
            report = api.complete(item)
            ensure(report['replay'] is False, 'CAP_COMPLETION')
            frame(receipts, report['phaseReceipt'])
    before = api.snapshot()
    ensure(before['operations'] == 1000 and before['references'] == 1000 and
           before['routes'] == 1000 and before['objects'] == 1000 and before['tombstones'] == 0 and
           before['terminal'] == 998 and before['pending'] == 2 and
           before['policyCounts'] == {'HIDDEN': 500, 'LIVE_NO_SET': 500} and
           before['logicalBytes'] + before['reservedBytes'] < CAPS['logicalBytes'] and
           before['reservedBytes'] < CAPS['completionBytes'], 'CAP_INDEPENDENT_CEILINGS')
    ensure(api.denied_1001() == 'COUNT_CAP_REACHED', 'CAP_1001_CODE')
    ensure(api.snapshot() == before, 'CAP_1001_CHANGED_STATE')
    replay_receipts = []
    for item in pending:
        saved = api.snapshot()
        replay = api.replay_prepare(item)
        ensure(replay['replay'] is True and replay['phaseReceipt'] == item['prepared']['phaseReceipt'], 'CAP_PREPARE_REPLAY')
        ensure(api.snapshot() == saved, 'CAP_PREPARE_REPLAY_CHANGED')
        complete = api.complete(item)
        ensure(complete['replay'] is False, 'CAP_PENDING_COMPLETION')
        saved = api.snapshot()
        replay = api.replay_report(item)
        ensure(replay['replay'] is True and replay['phaseReceipt'] == complete['phaseReceipt'], 'CAP_TERMINAL_REPLAY')
        ensure(api.snapshot() == saved, 'CAP_TERMINAL_REPLAY_CHANGED')
        frame(receipts, complete['phaseReceipt'])
        replay_receipts.append(digest({'prepare': item['prepared']['phaseReceipt'], 'report': complete['phaseReceipt']}))
    final = api.snapshot()
    ensure(final['operations'] == 1000 and final['routes'] == 1000 and final['references'] == 1000 and
           final['objects'] == 1000 and final['terminal'] == 1000 and final['pending'] == 0 and
           final['reservedBytes'] == 0 and final['policyCounts'] == {'HIDDEN': 500, 'LIVE_NO_SET': 500}, 'CAP_FINAL_COUNTS')
    return {'prepared': 1000, 'completed': 1000, 'countCapDenied': True,
            'beforeDenial': before, 'final': final, 'receiptsSha256': receipts.hexdigest(),
            'pendingReplayReceiptSha256': replay_receipts}


def execute(arg):
    validate_arg(arg, 'BOUND29-CAPACITY')
    ensure((datetime.datetime.fromisoformat(arg['expiresUtc'].replace('Z', '+00:00')) -
            datetime.datetime.now(datetime.timezone.utc)).total_seconds() >= 610, 'CAP_REMAINING')
    target_gate(arg, stage='ready')
    import django
    ensure(django.get_version() == '5.2.18', 'DJANGO_PIN')
    django.setup()
    from django.conf import settings
    from django.db import connection, transaction
    from journal import bounded as B, profile as P, services as S, state_v2 as V
    from journal.models import Head
    from journal.protocol import Fault
    from journal.test_bounded import BoundedFixture
    ensure(connection.vendor == 'postgresql' and not connection.in_atomic_block and
           connection.settings_dict['NAME'] == 'test_estakada_trust' and
           connection.settings_dict['USER'] == 'trust_migrator' and settings.TRUST_WRITE_PROFILE == 'disabled', 'CAP_DJANGO_TARGET')
    ensure(P.source_fingerprint() == arg['sourceFingerprint'] and B.CAPS == CAPS, 'CAP_SOURCE_CAPS')

    def identity():
        connection.ensure_connection()
        register_driver(connection.connection)
        with connection.cursor() as c:
            c.execute("SELECT current_database(),current_user,session_user,d.oid,pg_get_userbyid(d.datdba),shobj_description(d.oid,'pg_database'),(SELECT ssl FROM pg_stat_ssl WHERE pid=pg_backend_pid()),(SELECT system_identifier::text FROM pg_control_system()) FROM pg_database d WHERE datname=current_database()")
            ensure(c.fetchone() == ('test_estakada_trust', 'trust_migrator', 'trust_migrator',
                   arg['expected']['oid'], 'postgres', arg['expected']['marker'], True,
                   arg['expected']['systemIdentifier']), 'CAP_ACTUAL_TARGET')
        ensure(P.schema_fingerprint() == arg['expected']['schemaFingerprint'], 'CAP_SCHEMA')

    def raw_state():
        identity()
        h = hashlib.sha256(b'BOUND29-RAW-UNIT-v1\x00')
        counts = {}
        for table, key in sorted(KEYS.items()):
            frame(h, {'table': table})
            count = 0
            with connection.cursor() as c:
                c.execute('SELECT row_to_json(t) FROM trust."' + table + '" t ORDER BY "' + key + '"')
                for (row,) in c:
                    frame(h, json.loads(row) if type(row) is str else row)
                    count += 1
            frame(h, {'count': count})
            counts[table] = count
        with connection.cursor() as c:
            c.execute('SELECT last_value,is_called FROM trust.django_migrations_id_seq')
            sequence = list(c.fetchone())
        return {'rowsSha256': h.hexdigest(), 'counts': counts, 'sequence': sequence,
                'schemaFingerprint': arg['expected']['schemaFingerprint']}

    def empty(value):
        ensure(value['counts']['django_migrations'] == 3 and
               all(n == 0 for t, n in value['counts'].items() if t != 'django_migrations'), 'CAP_UNIT_NOT_EMPTY')

    fixture = None
    before = None
    result = None
    error = None
    sql_counts = {}
    try:
        with connection.cursor() as c:
            c.execute("SET statement_timeout='5s'")
            c.execute("SET lock_timeout='1s'")
            c.execute("SET idle_in_transaction_session_timeout='30s'")
        before = raw_state()
        empty(before)
        with transaction.atomic():
            try:
                with connection.cursor() as c:
                    c.execute('SELECT pg_try_advisory_xact_lock(374029)')
                    ensure(c.fetchone() == (True,), 'CAP_EXCLUSION_LOCK')
                    c.execute('LOCK TABLE ' + ','.join('trust."' + t + '"' for t in sorted(KEYS)) + ' IN ACCESS EXCLUSIVE MODE')
                empty(raw_state())
                def sql_guard(executor, sql, params, many, context):
                    check_sql(sql)
                    verb = sql.lstrip().split(None, 1)[0].upper()
                    sql_counts[verb] = sql_counts.get(verb, 0) + 1
                    return executor(sql, params, many, context)
                with connection.execute_wrapper(sql_guard), patch.object(connection, 'commit', side_effect=Rejected('CAP_COMMIT_FORBIDDEN')):
                    fixture = BoundedFixture(methodName='runTest')
                    fixture.setUp()
                    fixture.start()
                    ensure(B.CAPS == CAPS and S._test_mode.get() is False, 'CAP_NATIVE_SERVICE_GATE')
                    class Adapter:
                        @staticmethod
                        def body(index, policy):
                            value = fixture.prepare_body('/bound29/capacity/' + RUN + '/' + str(index))
                            value['kind'] = 'route_publication'
                            value['objectId'] = value['policies'][0]['objectId']
                            value['policies'][0].update(policy=policy, redirectTarget=None)
                            ensure(len(canonical(value)) <= 4096, 'CAP_BODY_BOUND')
                            return value
                        def send(self, body, phase):
                            ensure(B.CAPS == CAPS and S._test_mode.get() is False, 'CAP_GATE_DRIFT')
                            value = S.mutate(fixture.writer, body, phase)
                            ensure(len(canonical(value)) <= 65536, 'CAP_RECEIPT_BOUND')
                            return value
                        def prepare(self, index, policy):
                            body = self.body(index, policy)
                            return {'body': body, 'policy': policy, 'prepared': self.send(body, 'prepare')}
                        def complete(self, item):
                            item['report'] = fixture.report_body(item['body'])
                            return self.send(item['report'], 'report')
                        def replay_prepare(self, item):
                            return self.send(item['body'], 'prepare')
                        def replay_report(self, item):
                            return self.send(item['report'], 'report')
                        def denied_1001(self):
                            try:
                                self.send(self.body(1000, 'HIDDEN'), 'prepare')
                            except Fault as failure:
                                return failure.code
                            raise Rejected('CAP_1001_ACCEPTED')
                        def snapshot(self):
                            head = Head.objects.select_for_update().get(pk=1)
                            value = {'head': V.persistent_values(head), 'stateDigestV2': V.state_digest(head),
                                     'logicalBytes': head.logical_bytes, 'reservedBytes': head.reserved_bytes}
                            phases = hashlib.sha256(b'BOUND29-PHASES-v1\x00')
                            with connection.cursor() as c:
                                c.execute("SELECT count(*),count(DISTINCT object_id),count(*) FILTER(WHERE terminal_fingerprint IS NOT NULL),count(*) FILTER(WHERE stage='PENDING_DENY'),COALESCE(sum(jsonb_array_length(payload->'policies')),0) FROM trust.journal_operation")
                                n, objects, terminal, pending, refs = c.fetchone()
                                value.update(operations=n, objects=objects, terminal=terminal, pending=pending, references=int(refs))
                                c.execute('SELECT count(*) FROM trust.journal_routepolicy')
                                value['routes'] = c.fetchone()[0]
                                c.execute('SELECT count(*) FROM trust.journal_requesttombstone')
                                value['tombstones'] = c.fetchone()[0]
                                c.execute("SELECT payload->'policies'->0->>'policy',count(*) FROM trust.journal_operation GROUP BY 1")
                                value['policyCounts'] = dict(c.fetchall())
                                c.execute('SELECT id::text,phases FROM trust.journal_operation ORDER BY id')
                                for row in c:
                                    frame(phases, list(row))
                            value['phaseReceiptsSha256'] = phases.hexdigest()
                            return value
                    result = exercise(Adapter())
                    ensure(B.CAPS == CAPS and P.source_fingerprint() == arg['sourceFingerprint'], 'CAP_FINAL_SOURCE')
            finally:
                transaction.set_rollback(True)
        ensure(not connection.in_atomic_block, 'CAP_ATOMIC_OPEN')
    except BaseException as failure:
        error = failure
    finally:
        try:
            if fixture is not None:
                ensure(fixture.doCleanups(), 'CAP_FIXTURE_CLEANUP')
        except BaseException as failure:
            error = failure
        connection.close()
    try:
        target_gate(arg, stage='ready')
        after = raw_state()
        ensure(before is not None and after == before, 'CAP_ROLLBACK_PRESERVATION')
        empty(after)
    finally:
        connection.close()
    if error is not None:
        raise error
    return {'status': 'PASS', 'scope': 'BOUND29-real-capacity-rollback', 'runId': RUN,
            'sourceFingerprint': arg['sourceFingerprint'], 'proof': result,
            'before': before, 'after': after, 'sqlCounts': sql_counts,
            'rollbackVerified': True, 'flushPerformed': False, 'ddlPerformed': False,
            'real1000CapacityProved': True, 'countMocked': False, 'bulkSeed': False,
            'fixtureResourceFacts': True, 'nativeLeaseProved': False,
            'durabilityProved': False, 'fullRegression': False}


def main():
    raw = sys.stdin.buffer.read(16385)
    ensure(len(raw) <= 16384, 'CAP_INPUT_BOUND')
    arg = parse_arg(raw)
    validate_arg(arg, 'BOUND29-CAPACITY')
    disarm = arm_deadline(600)
    try:
        value = execute(arg)
        output = canonical(value)
        ensure(len(output) <= 1048576, 'CAP_OUTPUT_BOUND')
        sys.stdout.buffer.write(output + b'\n')
    finally:
        disarm()


if __name__ == '__main__':
    try:
        main()
    except BaseException as failure:
        code = failure.args[0] if isinstance(failure, Rejected) else 'CAPACITY_FAILED'
        if type(code) is not str or not re.fullmatch('[A-Z][A-Z0-9_]{0,79}', code):
            code = 'CAPACITY_FAILED'
        print(json.dumps({'status': 'FAIL', 'scope': 'BOUND29-real-capacity-rollback', 'code': code}))
        raise SystemExit(1) from None
