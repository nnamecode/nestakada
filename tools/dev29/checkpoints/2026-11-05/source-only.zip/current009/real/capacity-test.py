"""Offline rule/negative tests. Never imports Django, opens SQL or reads secrets."""
import copy
import importlib.util
import pathlib
import sys
import unittest

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import capacity as C


class FakeService:
    def __init__(self, bad=None):
        self.items = []
        self.revision = 0
        self.denials = 0
        self.calls = 0
        self.bad = bad
    def prepare(self, index, policy):
        self.calls += 1
        item = {'policy': policy, 'index': index, 'terminal': False,
                'prepared': {'replay': False, 'phaseReceipt': {'index': index, 'phase': 'prepare'}}}
        self.items.append(item)
        self.revision += 1
        return item
    def complete(self, item):
        self.calls += 1
        item['terminal'] = True
        self.revision += 1
        return {'replay': False, 'phaseReceipt': {'index': item['index'], 'phase': 'committed'}}
    def denied_1001(self):
        self.denials += 1
        if self.bad == 'denial-mutates':
            self.revision += 1
        return 'BUDGET_EXHAUSTED' if self.bad == 'wrong-ceiling' else 'COUNT_CAP_REACHED'
    def replay_prepare(self, item):
        receipt = copy.deepcopy(item['prepared']['phaseReceipt'])
        if self.bad == 'receipt-changed':
            receipt['index'] = 9999
        return {'replay': True, 'phaseReceipt': receipt}
    def replay_report(self, item):
        if self.bad == 'replay-mutates':
            self.revision += 1
        return {'replay': True, 'phaseReceipt': {'index': item['index'], 'phase': 'committed'}}
    def snapshot(self):
        n = len(self.items)
        terminal = sum(1 for x in self.items if x['terminal'])
        return {'operations': n - 1 if self.bad == 'underfilled' else n,
                'references': n, 'routes': n, 'objects': n, 'tombstones': 0,
                'terminal': terminal, 'pending': n - terminal,
                'policyCounts': {'HIDDEN': sum(x['policy'] == 'HIDDEN' for x in self.items),
                                 'LIVE_NO_SET': sum(x['policy'] == 'LIVE_NO_SET' for x in self.items)},
                'logicalBytes': C.CAPS['logicalBytes'] if self.bad == 'byte-cap' else n * 16384,
                'reservedBytes': (n - terminal) * 8192,
                'stateDigestV2': C.digest({'revision': self.revision})}


class CapacityRules(unittest.TestCase):
    def test_exact_count_boundary_and_two_pending_policies(self):
        service = FakeService()
        result = C.exercise(service)
        self.assertEqual(len(service.items), 1000)
        self.assertEqual(service.denials, 1)
        self.assertEqual(service.calls, 2000)
        self.assertEqual(result['beforeDenial']['pending'], 2)
        self.assertEqual(result['final']['terminal'], 1000)
        self.assertEqual(result['final']['policyCounts'], {'HIDDEN': 500, 'LIVE_NO_SET': 500})
        self.assertEqual(len(result['pendingReplayReceiptSha256']), 2)
    def test_1001_cannot_pass_using_a_different_ceiling(self):
        with self.assertRaisesRegex(C.Rejected, '^CAP_1001_CODE$'):
            C.exercise(FakeService('wrong-ceiling'))
    def test_count_must_be_full_before_denied_call(self):
        service = FakeService('underfilled')
        with self.assertRaisesRegex(C.Rejected, '^CAP_INDEPENDENT_CEILINGS$'):
            C.exercise(service)
        self.assertEqual(service.denials, 0)
    def test_byte_budget_cannot_be_mislabelled_as_count_proof(self):
        with self.assertRaisesRegex(C.Rejected, '^CAP_INDEPENDENT_CEILINGS$'):
            C.exercise(FakeService('byte-cap'))
    def test_denial_and_replay_are_observably_immutable(self):
        for bad, code in [('denial-mutates', 'CAP_1001_CHANGED_STATE'),
                          ('receipt-changed', 'CAP_PREPARE_REPLAY'),
                          ('replay-mutates', 'CAP_TERMINAL_REPLAY_CHANGED')]:
            with self.subTest(bad=bad), self.assertRaisesRegex(C.Rejected, '^' + code + '$'):
                C.exercise(FakeService(bad))
    def test_only_bounded_dml_and_savepoint_sql_is_allowed(self):
        for sql in ['SELECT 1', 'INSERT INTO trust.journal_head VALUES (%s)',
                    'UPDATE trust.journal_head SET generation=%s', 'DELETE FROM trust.journal_head',
                    'SAVEPOINT "safe"', 'ROLLBACK TO SAVEPOINT "safe"', 'RELEASE SAVEPOINT "safe"']:
            C.check_sql(sql)
        for sql in ['CREATE DATABASE other', 'DROP TABLE journal_head', 'COMMIT', 'ROLLBACK',
                    'SELECT 1; SELECT 2', 'SELECT nextval(%s)', 'SELECT setval(%s,%s)',
                    'SELECT pg_terminate_backend(%s)', 'SELECT pg_cancel_backend(%s)', 'SELECT 1 -- comment']:
            with self.subTest(sql=sql), self.assertRaises(C.Rejected):
                C.check_sql(sql)


if __name__ == '__main__':
    unittest.main(verbosity=1)
