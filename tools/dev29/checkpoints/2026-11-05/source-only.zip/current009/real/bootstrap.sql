-- Only the new empty tmpfs cluster. No original-role/DB/rows or migrations.
\set ON_ERROR_STOP on
\set ECHO none
\set VERBOSITY terse
-- cat's stdout is captured by psql's backtick substitution, not emitted.
-- Secrets are not shell variables, environment entries or process arguments.
\set bootstrap_password `/usr/bin/cat /run/secrets/bootstrap-password`
\set migrator_password `/usr/bin/cat /run/secrets/migrator-password`
ALTER ROLE postgres PASSWORD :'bootstrap_password';
CREATE ROLE trust_migrator LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION NOBYPASSRLS PASSWORD :'migrator_password';
\unset bootstrap_password
\unset migrator_password
ALTER ROLE trust_migrator CONNECTION LIMIT 4;
ALTER ROLE trust_migrator SET search_path = trust, pg_catalog;
ALTER ROLE trust_migrator SET statement_timeout = '2s';
ALTER ROLE trust_migrator SET lock_timeout = '500ms';
ALTER ROLE trust_migrator SET idle_in_transaction_session_timeout = '3s';
CREATE DATABASE estakada_trust OWNER postgres;
CREATE DATABASE test_estakada_trust OWNER postgres;
REVOKE ALL ON DATABASE postgres FROM PUBLIC;
REVOKE ALL ON DATABASE template1 FROM PUBLIC;
REVOKE ALL ON DATABASE estakada_trust FROM PUBLIC;
REVOKE ALL ON DATABASE test_estakada_trust FROM PUBLIC;
GRANT CONNECT ON DATABASE test_estakada_trust TO trust_migrator;
\connect estakada_trust postgres /var/run/postgresql 5432
REVOKE ALL ON SCHEMA public FROM PUBLIC;
CREATE SCHEMA trust AUTHORIZATION postgres;
\connect test_estakada_trust postgres /var/run/postgresql 5432
REVOKE ALL ON SCHEMA public FROM PUBLIC;
CREATE SCHEMA trust AUTHORIZATION trust_migrator;

-- New synthetic identities only; never original corpus markers.
COMMENT ON DATABASE estakada_trust IS 'BOUND29-MAIN:066dd89b-2727-4d6d-a16a-b17bdccd9f92';
COMMENT ON DATABASE test_estakada_trust IS 'BOUND29-UNIT:066dd89b-2727-4d6d-a16a-b17bdccd9f92';
