import {ensure,sha,stable} from './guards.mjs';
const nat=s=>{ensure(/^(0|[1-9][0-9]*)$/.test(s),'BOUND_RO_NUMBER');const n=Number(s);ensure(Number.isSafeInteger(n),'BOUND_RO_NUMBER');return n;};
export function parseOriginal(raw){
 ensure(typeof raw==='string'&&Buffer.byteLength(raw)<=1048576&&!raw.includes('\r')&&raw.endsWith('\n'),'BOUND_RO_FRAMING');
 const lines=raw.split('\n');ensure(lines.pop()===''&&lines.shift()==='BOUND29_RO_V1'&&lines.pop()==='END','BOUND_RO_FRAMING');
 const system=lines.shift(),state=lines.shift(),allocated=lines.shift(),count=lines.shift();
 ensure(/^SYSTEM [0-9]{10,20}$/.test(system)&&state==='STATE shut_down'&&/^ALLOC_KIB [0-9]+$/.test(allocated)&&/^COUNT [0-9]+$/.test(count),'BOUND_RO_HEADER');
 const bytes=nat(allocated.slice(10))*1024,expected=nat(count.slice(6));
 ensure(bytes>0&&Number.isSafeInteger(bytes)&&bytes<2147483648&&expected>0&&expected<=12000&&lines.length===expected,'BOUND_RO_COUNT');
 const rows=[],seen=new Set();let last=null;
 for(const line of lines){
  const cols=line.split('\t');ensure(cols.length===8,'BOUND_RO_ROW');
  const [kind,mode,uid,gid,size,blocks,digest,name]=cols;
  ensure(['f','d'].includes(kind)&&/^[0-7]{3,4}$/.test(mode)&&(kind==='f'?/^[a-f0-9]{64}$/.test(digest):digest==='-'),'BOUND_RO_KIND');
  ensure(name==='.'||(/^[A-Za-z0-9_./-]+$/.test(name)&&!name.startsWith('/')&&name.split('/').every(x=>x&&x!=='.'&&x!=='..')),'BOUND_RO_PATH');
  ensure(!seen.has(name)&&(last===null||last<name),'BOUND_RO_ORDER');seen.add(name);last=name;
  rows.push({kind,mode,uid:nat(uid),gid:nat(gid),size:nat(size),blocks:nat(blocks),sha256:digest,path:name});
 }
 ensure(rows[0]?.path==='.'&&rows[0].kind==='d'&&seen.has('18/docker/PG_VERSION')&&seen.has('18/docker/global/pg_control'),'BOUND_RO_STRUCTURE');
 return {scope:'BOUND29-ORIGINAL-FILE-PROOF',systemIdentifier:system.slice(7),state:'shut down',allocatedBytes:bytes,count:expected,manifestSha256:sha(stable(rows)),rawSha256:sha(raw)};
}
export function compareOriginal(before,after){
 ensure(before.scope==='BOUND29-ORIGINAL-FILE-PROOF'&&stable(before)===stable(after),'BOUND_RO_PRESERVATION');return true;
}
