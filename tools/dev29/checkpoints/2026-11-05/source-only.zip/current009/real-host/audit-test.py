"""Synthetic injected IO only; no backend, secrets or production Django."""
import copy
import datetime
import importlib.util
import json
from pathlib import Path
import unittest

spec=importlib.util.spec_from_file_location('bound_audit',Path(__file__).with_name('audit.py'))
A=importlib.util.module_from_spec(spec); spec.loader.exec_module(A)

def argument(mode='MAIN'):
    return dict(scope='BOUND29-READONLY-AUDIT',runId=A.RUN,sourceFingerprint='a'*64,
        packageSha256='b'*64,admissionSha256='c'*64,mode=mode,
        expiresUtc=(datetime.datetime.now(datetime.timezone.utc)+datetime.timedelta(minutes=5)).isoformat().replace('+00:00','Z'),
        expected=dict(systemIdentifier='1234567890123456789',mainMarker='BOUND29-MAIN:'+A.RUN,
                      unitMarker='BOUND29-UNIT:'+A.RUN,mainOid=None if mode=='MAIN' else 101,unitOid=None if mode=='MAIN' else 102))

class Cursor:
    def __init__(self,rows): self.rows=rows
    def fetchall(self): return self.rows
    def fetchone(self): return self.rows[0] if self.rows else None
    def __iter__(self): return iter(self.rows)

class Stream:
    def __init__(self,io): self.io=io
    def __enter__(self): return self
    def __exit__(self,*args): return False
    def execute(self,sql): self.rows=self.io.execute(sql).fetchall()
    def __iter__(self): return iter(self.rows)

class IO:
    def __init__(self,mode='MAIN'):
        self.connections=0; self.closed=0; self.rolled=0; self.queries=[]; self.source_calls=0
        name,role,oid=(A.MAIN,'postgres',101) if mode=='MAIN' else (A.UNIT,'trust_migrator',102)
        hba=[(1,'local',['all'],['all'],None,None,'reject',None)]
        for kind,db,user,auth in [('hostnossl','all','all','reject'),('hostssl',A.UNIT,'trust_migrator','scram-sha-256'),('hostssl',A.MAIN,'postgres','scram-sha-256'),('hostssl','all','all','reject')]:
            for addr,mask in [('0.0.0.0','0.0.0.0'),('::','::')]:
                hba.append((len(hba)+1,kind,[db],[user],addr,mask,auth,None))
        settings={'max_connections':'16','shared_buffers':'8192','max_wal_size':'128','min_wal_size':'32',
                  'ssl':'on','fsync':'on','full_page_writes':'on','synchronous_commit':'on',
                  'data_directory':'/var/lib/postgresql/18/docker','hba_file':'/config/runtime.hba',
                  'ssl_key_file':'/var/run/postgresql/server.key','ssl_cert_file':'/run/secrets/database-ca',
                  'unix_socket_directories':'/var/run/postgresql'}
        self.rows={A.IDENTITY:[(name,role,role,oid,'postgres','BOUND29-'+mode+':'+A.RUN,True,'1234567890123456789')],
            'SHOW transaction_read_only':[('on',)],'SHOW search_path':[('trust, pg_catalog',)],A.CLIENTS:[],
            A.CATALOGUE:[(A.MAIN,101,'postgres','BOUND29-MAIN:'+A.RUN,None),(A.UNIT,102,'postgres','BOUND29-UNIT:'+A.RUN,None)],
            A.NAMESPACE:[('postgres' if mode=='MAIN' else 'trust_migrator',)],A.MAIN_OBJECTS:[(0,0,0)],
            A.SCHEMA:[] if mode=='MAIN' else [(t,'trust_migrator') for t in A.TABLES],
            A.ROLES:[('postgres',True,True,True,True,True,True),('trust_migrator',False,False,False,True,False,False)],
            A.HBA:hba,A.SETTINGS:[(k,v,None) for k,v in settings.items()],A.SEQUENCES:[('trust','journal_head_id_seq','trust_migrator',1,1,999,1,False,1,456)]}
        self.rows[A.MIGRATION_SEQUENCE]=[(3,True)]
        for table,sql in A.ROWS.items():
            self.rows[sql]=[(json.dumps({'id':i+1,'app':'journal','name':name,'applied':'2026-11-03T00:00:00+00:00'}),) for i,name in enumerate(A.MIGRATIONS)] if table=='django_migrations' else []
    def source(self): self.source_calls+=1; return 'a'*64
    def connect(self,mode): self.connections+=1; return self
    def execute(self,sql): self.queries.append(sql); return Cursor(self.rows[sql])
    def cursor(self,name): return Stream(self)
    def fingerprint(self,raw): return 'd'*64
    def rollback(self): self.rolled+=1
    def close(self): self.closed+=1

class Tests(unittest.TestCase):
    def reject(self,arg,io,code=None):
        with self.assertRaises(A.Rejected) as cm: A.execute(arg,io)
        if code: self.assertEqual(cm.exception.code,code)
    def test_main_observation_and_cleanup(self):
        io=IO(); r=A.execute(argument(),io)
        self.assertEqual(r['status'],'PASS'); self.assertEqual(r['proof']['catalogue'][1][1],102)
        self.assertEqual(io.queries[0],A.IDENTITY); self.assertEqual((io.closed,io.rolled),(1,1))
        self.assertNotIn('password',json.dumps(r))
    def test_unit_all_eight_tables_and_sequence_observed(self):
        io=IO('UNIT'); r=A.execute(argument('UNIT'),io)
        self.assertEqual(set(r['proof']['tables']),set(A.TABLES)); self.assertEqual(r['proof']['sequences'][0][-1],456)
        self.assertNotIn(A.HBA,io.queries); self.assertIn(A.ROLES,io.queries)
        self.assertEqual((io.closed,io.rolled),(1,1))
    def test_closed_arg_before_connect(self):
        for key,value in [('scope','old'),('runId','old'),('sourceFingerprint','bad'),('expiresUtc','2000-01-01T00:00:00Z'),('mode','postgres')]:
            a=argument(); a[key]=value; io=IO(); self.reject(a,io); self.assertEqual(io.connections,0)
        for key,value in [('mainOid',True),('unitOid',None),('mainMarker','old'),('systemIdentifier','bad')]:
            a=argument('UNIT'); a['expected'][key]=value; io=IO(); self.reject(a,io); self.assertEqual(io.connections,0)
        a=argument(); a['sql']='SELECT 1'; io=IO(); self.reject(a,io); self.assertEqual(io.connections,0)
    def test_source_before_connect(self):
        io=IO(); io.source=lambda:'bad'; self.reject(argument(),io,'SOURCE_FINGERPRINT'); self.assertEqual(io.connections,0)
    def test_identity_before_subject_rows(self):
        for position,value in [(0,A.UNIT),(1,'trust_migrator'),(2,'other'),(3,999),(4,'other'),(5,'old'),(6,False),(7,'wrong')]:
            io=IO(); row=list(io.rows[A.IDENTITY][0]); row[position]=value; io.rows[A.IDENTITY]=[tuple(row)]
            a=argument(); a['expected'].update(mainOid=101,unitOid=102)
            self.reject(a,io,'TARGET_IDENTITY'); self.assertEqual(io.queries,[A.IDENTITY]); self.assertEqual(io.closed,1)
    def test_readonly_and_foreign_clients(self):
        for sql,rows in [('SHOW transaction_read_only',[('off',)]),(A.CLIENTS,[(A.MAIN,'postgres','client backend','idle',1)])]:
            io=IO(); io.rows[sql]=rows; self.reject(argument(),io); self.assertEqual(io.closed,1)
    def test_privileged_settings_and_hba_fail_closed(self):
        for sql in (A.SETTINGS,A.HBA,A.ROLES,A.MAIN_OBJECTS):
            io=IO(); io.rows[sql]=[]; self.reject(argument(),io); self.assertEqual(io.closed,1)
        io=IO(); r=list(io.rows[A.HBA][3]); r[6]='trust'; io.rows[A.HBA][3]=tuple(r); self.reject(argument(),io,'HBA_RULES')
        io=IO(); io.rows[A.SETTINGS]=[(n,'/outside' if n=='hba_file' else v,u) for n,v,u in io.rows[A.SETTINGS]]; self.reject(argument(),io,'SERVER_PATHS')
    def test_unit_nonempty_or_bad_migrations(self):
        for table in (A.TABLES[0],'django_migrations'):
            io=IO('UNIT'); io.rows[A.ROWS[table]]=[('{"app":"evil","name":"bad"}',)]
            self.reject(argument('UNIT'),io); self.assertEqual(io.closed,1)
    def test_no_arbitrary_or_multiquery(self):
        io=IO(); c=A.ClosedConnection(io)
        for sql in ('SELECT 1','SELECT 1; DELETE FROM x','COPY x TO PROGRAM \'x\'',A.IDENTITY+';'):
            with self.assertRaises(A.Rejected): c.execute(sql)
        self.assertEqual(io.queries,[])
    def test_migration_sequence_raw_c_baseline_and_t_observed(self):
        before=A.execute(argument('UNIT'),IO('UNIT'))['proof']
        after=A.execute(argument('UNIT'),IO('UNIT'))['proof']
        self.assertEqual(before['migrationSequence'],[3,True])
        self.assertEqual(before['migrationSequence'],after['migrationSequence'])
        changed=IO('UNIT'); changed.rows[A.MIGRATION_SEQUENCE]=[(9,False)]
        observed=A.execute(argument('UNIT'),changed)['proof']
        self.assertEqual(observed['migrationSequence'],[9,False])
        self.assertEqual(before['tables'],observed['tables'])
        self.assertEqual(before['schemaFingerprint'],observed['schemaFingerprint'])
        for bad in ([],[(True,True)],[(3,1)],[(3,True),(4,False)],[(0,False)]):
            io=IO('UNIT'); io.rows[A.MIGRATION_SEQUENCE]=bad
            self.reject(argument('UNIT'),io,'MIGRATION_SEQUENCE')
            self.assertEqual(io.closed,1)
        for sql in ('SELECT nextval(\'trust.django_migrations_id_seq\')',"SELECT setval('trust.django_migrations_id_seq',1)"):
            with self.assertRaises(A.Rejected): A.ClosedConnection(IO('UNIT')).execute(sql)
    def test_drift_and_driver_exception_sanitized(self):
        io=IO(); io.source=lambda:'a'*64 if io.source_calls==0 else 'bad'
        # Explicit monotonic reader to exercise final comparison.
        values=iter(['a'*64,'bad']); io.source=lambda:next(values)
        self.reject(argument(),io,'SOURCE_DRIFT'); self.assertEqual(io.closed,1)
        io=IO(); io.execute=lambda _:(_ for _ in ()).throw(RuntimeError('SECRET_CANARY'))
        self.reject(argument(),io,'AUDIT_FAILED'); self.assertEqual(io.closed,1)
    def test_parser_duplicates_nonfinite_and_size(self):
        for raw in (b'{"mode":1,"mode":2}',b'{"x":NaN}',b'x'*16385):
            with self.assertRaises(A.Rejected): A.parse_arg(raw)

if __name__=='__main__':
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(Tests)
    result=unittest.TextTestRunner().run(suite)
    print(json.dumps({'status':'PASS' if result.wasSuccessful() else 'FAIL','tests':result.testsRun,'actualConnections':0,'actualSQL':0,'actualSecretReads':0,'runtimeQualified':False}))
    raise SystemExit(not result.wasSuccessful())
