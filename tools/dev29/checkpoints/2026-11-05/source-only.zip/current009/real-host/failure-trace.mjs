// Pure projection only: no fs/process/spawn/key access and no raw-output storage.
import {createHash} from 'node:crypto';
import {RUN,SOURCE,PLAN,PREFIX,ORIGINAL,PGIMAGE,PYIMAGE,ENGINE_ID} from './spec.mjs';

export const ENDPOINT='npipe:////./pipe/dockerDesktopLinuxEngine';
const HEX=/^[0-9a-f]{64}$/;
const OPS={INFO:'ENGINE',CONTAINER_LIST:'CONTAINER',CONTAINER_INSPECT:'CONTAINER',IMAGE_INSPECT:'IMAGE',VOLUME_INSPECT:'VOLUME',NETWORK_LIST:'NETWORK',NETWORK_INSPECT:'NETWORK',CONTAINER_CREATE:'CONTAINER',START_ATTACH:'CONTAINER',STOP:'CONTAINER',KILL:'CONTAINER',REMOVE:'CONTAINER',NETWORK_CREATE:'NETWORK',NETWORK_REMOVE:'NETWORK'};
const STAGES=new Set(['PREFLIGHT','ORIGINAL_BEFORE','INIT','C','T','STOP','ORIGINAL_AFTER','TERMINAL']);
const ERRORS=new Set(['ENOENT','EACCES','EPERM','ETIMEDOUT','ENOBUFS','OTHER']);
const SIGNALS=new Set(['SIGTERM','SIGKILL','SIGINT','SIGABRT','SIGSEGV','SIGPIPE','SIGALRM']);
const SUMMARIES=new Set(['DAEMON_UNAVAILABLE','TIMEOUT','NOT_FOUND','PERMISSION','INVALID_ARGUMENT','OUTPUT_LIMIT','OTHER','EMPTY']);
const ownName=x=>typeof x==='string'&&new RegExp('^'+PREFIX+'-[a-z][a-z0-9-]{0,63}$').test(x);
const check=(ok,code)=>{if(!ok)throw Error(code);};
const object=(v,keys,code)=>check(v!==null&&typeof v==='object'&&!Array.isArray(v)&&Object.getPrototypeOf(v)===Object.prototype&&Object.keys(v).length===keys.length&&keys.every(k=>Object.hasOwn(v,k)),code);
const integer=n=>Number.isSafeInteger(n)&&n>=0;
const digest=b=>createHash('sha256').update(b).digest('hex');
const equal=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
const label=x=>x==='bound29.run='+RUN||x==='nestakada.scope=trust-test'||typeof x==='string'&&(/^bound29\.create=[0-9a-f]{64}$/.test(x)||/^bound29\.kind=(db|preflight|main|unit|matrix|init|capacity|suite|original-before|original-after)$/.test(x));

function safe(v){
 object(v,['operation','targetKind','target','profileSha256'],'TRACE_ARGV_SCHEMA');
 check(Object.hasOwn(OPS,v.operation)&&v.targetKind===OPS[v.operation],'TRACE_OPERATION');
 const nullTarget=['INFO','CONTAINER_LIST','NETWORK_LIST'].includes(v.operation);
 check(nullTarget?v.target===null:typeof v.target==='string','TRACE_TARGET');
 if(!nullTarget){
  if(v.targetKind==='IMAGE')check([PGIMAGE,PYIMAGE].includes(v.target),'TRACE_IMAGE');
  else if(v.targetKind==='VOLUME')check(v.target===ORIGINAL,'TRACE_VOLUME');
  else check(HEX.test(v.target)||ownName(v.target),'TRACE_TARGET');
 }
 const create=['CONTAINER_CREATE','NETWORK_CREATE'].includes(v.operation);
 check(create?typeof v.profileSha256==='string'&&HEX.test(v.profileSha256):v.profileSha256===null,'TRACE_PROFILE');
 return Object.freeze({...v});
}

export function projectArgv(args,bindings){
 object(bindings,['names','images','originalVolume','profileSha256'],'TRACE_BINDINGS');
 const {names,images,originalVolume,profileSha256}=bindings;
 check(Array.isArray(names)&&names.length>0&&new Set(names).size===names.length&&names.every(ownName),'TRACE_NAMES');
 check(Array.isArray(images)&&images.length===2&&new Set(images).size===2&&images.every(x=>[PGIMAGE,PYIMAGE].includes(x)),'TRACE_IMAGES');
 check(originalVolume===ORIGINAL&&(profileSha256===null||typeof profileSha256==='string'&&HEX.test(profileSha256)),'TRACE_BINDING');
 check(Array.isArray(args)&&args.length>0&&args.length<=256&&args.every(x=>typeof x==='string'&&x.length<=8192&&!x.includes('\0')),'TRACE_ARGS');
 const target=x=>{check(typeof x==='string'&&(HEX.test(x)||names.includes(x)),'TRACE_TARGET_BINDING');return x;};
 const profile=()=>{check(typeof profileSha256==='string'&&HEX.test(profileSha256),'TRACE_PROFILE');return profileSha256;};
 const result=(operation,t=null,p=null)=>safe({operation,targetKind:OPS[operation],target:t,profileSha256:p});
 if(equal(args,['info','--format','{{json .}}']))return result('INFO');
 if(args[0]==='ps'){
  let at=2;check(args[1]==='-aq','TRACE_LIST');if(args[at]==='--no-trunc')at++;
  check(args.length===at||args.length===at+2&&args[at]==='--filter'&&(args[at+1]==='label=bound29.run='+RUN||args[at+1].startsWith('id=')&&HEX.test(args[at+1].slice(3))),'TRACE_LIST');
  return result('CONTAINER_LIST');
 }
 if(args[0]==='inspect'&&args.length===2)return result('CONTAINER_INSPECT',target(args[1]));
 if(args[0]==='image'&&args[1]==='inspect'&&args.length===3){check(images.includes(args[2]),'TRACE_IMAGE_BINDING');return result('IMAGE_INSPECT',args[2]);}
 if(args[0]==='volume'&&args[1]==='inspect'&&args.length===3){check(args[2]===originalVolume,'TRACE_VOLUME_BINDING');return result('VOLUME_INSPECT',args[2]);}
 if(args[0]==='network'){
  if(args[1]==='ls'){
   let at=2;check(args[at++]==='-q','TRACE_NETWORK_LIST');if(args[at]==='--no-trunc')at++;
   check(args.length===at+2&&args[at]==='--filter'&&(args[at+1]==='label=bound29.run='+RUN||args[at+1].startsWith('id=')&&HEX.test(args[at+1].slice(3))),'TRACE_NETWORK_LIST');
   return result('NETWORK_LIST');
  }
  if(args.length===3&&['inspect','rm'].includes(args[1]))return result(args[1]==='inspect'?'NETWORK_INSPECT':'NETWORK_REMOVE',target(args[2]));
  if(args[1]==='create'){
   check(args.length>=7&&args[2]==='--internal'&&args[3]==='--driver'&&args[4]==='bridge'&&names.includes(args.at(-1)),'TRACE_NETWORK_CREATE');
   for(let i=5;i<args.length-1;i+=2)check(args[i]==='--label'&&label(args[i+1]),'TRACE_NETWORK_CREATE');
   return result('NETWORK_CREATE',args.at(-1),profile());
  }
 }
 if(args[0]==='create'){
  const nameAt=args.indexOf('--name');check(nameAt>=1&&args.lastIndexOf('--name')===nameAt&&names.includes(args[nameAt+1]),'TRACE_CREATE_NAME');
  const entry=args.indexOf('--entrypoint');check(entry>nameAt&&images.includes(args[entry+2]),'TRACE_CREATE_IMAGE');
  const pairs=new Set(['--name','--user','--label','--network','--network-alias','--mount','--env','--tmpfs']);
  for(let i=1;i<entry;i++){
   const x=args[i];if(pairs.has(x)){check(i+1<entry&&(x!=='--label'||label(args[i+1])),'TRACE_CREATE_PROFILE');i++;continue;}
   check(x==='--interactive'||x==='--read-only'||x==='--cap-drop=ALL'||x==='--security-opt=no-new-privileges:true'||/^--(pull|memory|memory-swap|cpus|pids-limit|shm-size|log-driver|restart|ipc|cgroupns|network)=/.test(x),'TRACE_CREATE_PROFILE');
  }
  return result('CONTAINER_CREATE',args[nameAt+1],profile());
 }
 if(args[0]==='start'&&args[1]==='--attach'&&(args.length===3||args.length===4&&args[2]==='--interactive'))return result('START_ATTACH',target(args.at(-1)));
 if(args.length===4&&args[0]==='stop'&&args[1]==='--time'&&args[2]==='15')return result('STOP',target(args[3]));
 if(args.length===4&&args[0]==='kill'&&args[1]==='--signal'&&args[2]==='KILL')return result('KILL',target(args[3]));
 if(args.length===2&&args[0]==='rm')return result('REMOVE',target(args[1]));
 throw Error('TRACE_UNKNOWN_OPERATION');
}

export function outputStats(buffer,complete){
 check(Buffer.isBuffer(buffer)&&typeof complete==='boolean','TRACE_STATS_INPUT');
 return Object.freeze({bytes:buffer.length,sha256:digest(buffer),complete});
}

export function stderrSummary(input){
 check(Buffer.isBuffer(input)||typeof input==='string','TRACE_SUMMARY_INPUT');
 const text=(Buffer.isBuffer(input)?input.subarray(0,8192).toString('utf8'):input.slice(0,8192)).toLowerCase();
 if(!text.length)return 'EMPTY';
 if(/maxbuffer|enobufs|output.{0,12}(limit|cap)/.test(text))return 'OUTPUT_LIMIT';
 if(/timed?\s*out|etimedout|deadline exceeded/.test(text))return 'TIMEOUT';
 if(/permission denied|access is denied|eacces|eperm/.test(text))return 'PERMISSION';
 if(/cannot connect to the docker daemon|docker daemon is not running|error during connect|dockerdesktoplinuxengine.{0,40}(not found|cannot find)/.test(text))return 'DAEMON_UNAVAILABLE';
 if(/no such (container|image|network|volume)|not found|enoent/.test(text))return 'NOT_FOUND';
 if(/unknown flag|invalid argument|requires.*arguments/.test(text))return 'INVALID_ARGUMENT';
 return 'OTHER';
}

function stats(v){
 object(v,['bytes','sha256','complete'],'TRACE_STATS_SCHEMA');
 check(integer(v.bytes)&&typeof v.sha256==='string'&&HEX.test(v.sha256)&&typeof v.complete==='boolean','TRACE_STATS');
 check(v.bytes!==0||v.sha256===digest(Buffer.alloc(0)),'TRACE_EMPTY_HASH');
 return Object.freeze({...v});
}

export function buildFailure(ctx,call,facts){
 object(ctx,['runId','packageSha256','sourceFingerprint','proposalSha256','preparedPlanSha256','engine','stage','endpoint'],'TRACE_CONTEXT_SCHEMA');
 check(ctx.runId===RUN&&ctx.sourceFingerprint===SOURCE&&ctx.proposalSha256===PLAN&&ctx.endpoint===ENDPOINT&&STAGES.has(ctx.stage),'TRACE_CONTEXT_BINDING');
 check(['packageSha256','preparedPlanSha256'].every(k=>typeof ctx[k]==='string'&&HEX.test(ctx[k])),'TRACE_CONTEXT_HASH');
 object(call,['callNo','safeArgv','startedUtc','durationMs','timeoutMs'],'TRACE_CALL_SCHEMA');
 check(integer(call.callNo)&&call.callNo>=1&&integer(call.durationMs)&&integer(call.timeoutMs),'TRACE_CALL');
 check(typeof call.startedUtc==='string'&&/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d{3}Z$/.test(call.startedUtc)&&Number.isFinite(Date.parse(call.startedUtc))&&new Date(call.startedUtc).toISOString()===call.startedUtc,'TRACE_TIME');
 object(ctx.engine,['expectedId','observedId','observedAtCallNo'],'TRACE_ENGINE_SCHEMA');
 const e=ctx.engine;
 check(e.expectedId===ENGINE_ID&&(e.observedId===null&&e.observedAtCallNo===null||e.observedId===ENGINE_ID&&integer(e.observedAtCallNo)&&e.observedAtCallNo>=1&&e.observedAtCallNo<=call.callNo),'TRACE_ENGINE_BINDING');
 object(facts,['dispatched','exitCode','errorCode','signal','stdout','stderr','stderrSummary'],'TRACE_FACTS_SCHEMA');
 check(typeof facts.dispatched==='boolean'&&(facts.exitCode===null||Number.isSafeInteger(facts.exitCode))&&(facts.signal===null||SIGNALS.has(facts.signal))&&SUMMARIES.has(facts.stderrSummary),'TRACE_FACTS');
 check(facts.errorCode===null||typeof facts.errorCode==='string','TRACE_ERROR');
 const errorCode=facts.errorCode===null?null:ERRORS.has(facts.errorCode)?facts.errorCode:'OTHER';
 const stdout=stats(facts.stdout),stderr=stats(facts.stderr);
 check(!['ETIMEDOUT','ENOBUFS'].includes(errorCode)||!stdout.complete&&!stderr.complete,'TRACE_PARTIAL_REQUIRED');
 check(facts.exitCode!==0||errorCode!==null||facts.signal!==null||!stdout.complete||!stderr.complete,'TRACE_NOT_FAILURE');
 const payload={scope:'BOUND29-DOCKER-FAILURE',runId:ctx.runId,packageSha256:ctx.packageSha256,sourceFingerprint:ctx.sourceFingerprint,proposalSha256:ctx.proposalSha256,preparedPlanSha256:ctx.preparedPlanSha256,
  engine:Object.freeze({...e}),stage:ctx.stage,callNo:call.callNo,endpoint:ctx.endpoint,safeArgv:safe(call.safeArgv),startedUtc:call.startedUtc,durationMs:call.durationMs,timeoutMs:call.timeoutMs,
  dispatched:facts.dispatched,exitCode:facts.exitCode,errorCode,signal:facts.signal,stdout,stderr,stderrSummary:facts.stderrSummary,rawContentsOmitted:true};
 check(Buffer.byteLength(JSON.stringify({payload,signature:'0'.repeat(64)}),'utf8')<=8192,'TRACE_RECEIPT_CAP');
 return Object.freeze(payload);
}
