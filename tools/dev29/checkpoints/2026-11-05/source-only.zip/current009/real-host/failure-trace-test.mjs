import test from 'node:test';
import assert from 'node:assert/strict';
import {projectArgv,outputStats,stderrSummary,buildFailure,ENDPOINT} from './failure-trace.mjs';
import * as S from './spec.mjs';
const H='a'.repeat(64),I='b'.repeat(64),P='c'.repeat(64);
const bindings=()=>({names:[S.DB,S.NET,...['preflight','main','unit','matrix','init','capacity','suite','original-before','original-after'].map(n=>S.PREFIX+'-'+n)],images:[S.PGIMAGE,S.PYIMAGE],originalVolume:S.ORIGINAL,profileSha256:null});
const project=(args,profile=null)=>projectArgv(args,{...bindings(),profileSha256:profile});
const context=()=>({runId:S.RUN,packageSha256:H,sourceFingerprint:S.SOURCE,proposalSha256:S.PLAN,preparedPlanSha256:P,engine:{expectedId:S.ENGINE_ID,observedId:null,observedAtCallNo:null},stage:'PREFLIGHT',endpoint:ENDPOINT});
const call=()=>({callNo:1,safeArgv:project(['info','--format','{{json .}}']),startedUtc:'2026-11-04T00:00:00.000Z',durationMs:10,timeoutMs:1000});
const facts=()=>({dispatched:true,exitCode:1,errorCode:null,signal:null,stdout:outputStats(Buffer.alloc(0),true),stderr:outputStats(Buffer.from('SECRET_CANARY /private/path Env=TOKEN'),true),stderrSummary:'OTHER'});
const clone=x=>structuredClone(x);

test('all 15 operations project only closed safe metadata',()=>{
 const rows=[
  [['info','--format','{{json .}}'],'INFO'],[['ps','-aq'],'CONTAINER_LIST'],[['ps','-aq','--no-trunc','--filter','label=bound29.run='+S.RUN],'CONTAINER_LIST'],
  [['inspect',I],'CONTAINER_INSPECT'],[['image','inspect',S.PGIMAGE],'IMAGE_INSPECT'],[['volume','inspect',S.ORIGINAL],'VOLUME_INSPECT'],
  [['network','ls','-q','--no-trunc','--filter','label=bound29.run='+S.RUN],'NETWORK_LIST'],[['network','inspect',S.NET],'NETWORK_INSPECT'],
  [['network','ls','-q','--no-trunc','--filter','id='+I],'NETWORK_LIST'],
  [['create','--name',S.DB,'--env','PRIVATE_SECRET=canary','--mount','type=bind,source=/private/token,target=/secret,readonly','--entrypoint','/bin/sh',S.PGIMAGE,'/tools/x'],'CONTAINER_CREATE',P],
  [['start','--attach',I],'START_ATTACH'],[['start','--attach','--interactive',I],'START_ATTACH'],[['stop','--time','15',I],'STOP'],[['kill','--signal','KILL',I],'KILL'],[['rm',I],'REMOVE'],
  [['network','create','--internal','--driver','bridge','--label','bound29.run='+S.RUN,'--label','nestakada.scope=trust-test',S.NET],'NETWORK_CREATE',P],
  [['network','rm',I],'NETWORK_REMOVE']];
 for(const [args,op,p]of rows){const v=project(args,p??null);assert.equal(v.operation,op);assert.deepEqual(Object.keys(v).sort(),['operation','profileSha256','target','targetKind']);assert.ok(Object.isFrozen(v));assert.doesNotMatch(JSON.stringify(v),/PRIVATE_SECRET|canary|private|\/tools|--env|--mount/);}
});

test('actual pure builders project without inspecting their raw binds/env',()=>{
 assert.equal(project(S.dbArgs(),P).operation,'CONTAINER_CREATE');
 assert.equal(project(S.networkArgs(),P).operation,'NETWORK_CREATE');
 for(const kind of ['preflight','main','unit','matrix','init','capacity','suite'])assert.equal(project(S.helperArgs(kind),P).operation,'CONTAINER_CREATE');
 for(const phase of ['before','after'])assert.equal(project(S.originalArgs(phase),P).operation,'CONTAINER_CREATE');
});

test('unknown operations options old run names and wrong pinned bindings reject',()=>{
 for(const args of [['exec',I,'env'],['inspect','nestakada-bound29-1e23c654-db'],['info'],['image','inspect','sha256:'+'d'.repeat(64)],['volume','inspect','other'],['ps','-aq','--filter','name=secret'],['network','ls','-q'],['start',I],['stop','--time','60',I],['rm','-f',I],['create','--name',S.DB,'--evil','SECRET','--entrypoint','/bin/sh',S.PGIMAGE]])assert.throws(()=>project(args,P));
 assert.throws(()=>project(['create','--name',S.DB,'--entrypoint','/bin/sh',S.PGIMAGE]));
 assert.throws(()=>project(['network','create','--internal','--driver','bridge','--label','bound29.run=old',S.NET],P));
 assert.throws(()=>project(['create','--name',S.DB,'--label','bound29.run=old','--entrypoint','/bin/sh',S.PGIMAGE],P));
 for(const filter of ['label=bound29.run=1e23c654-5baf-4b5e-a7b4-6235b1289c0a','id=short','id='+'z'.repeat(64),'id='+I+';secret','name='+S.NET])assert.throws(()=>project(['network','ls','-q','--no-trunc','--filter',filter]));
 for(const modify of [b=>b.names.push('old-db'),b=>b.images.push('other'),b=>b.originalVolume='other',b=>b.unknown='secret',b=>b.profileSha256='secret']){const b=bindings();modify(b);assert.throws(()=>projectArgv(['inspect',I],b));}
});

test('byte counts hashes and partial flag describe only actual received bytes',()=>{
 const bytes=Buffer.from([0,255,13,10]);const before=Buffer.from(bytes);const a=outputStats(bytes,false);
 assert.equal(a.bytes,4);assert.equal(a.complete,false);assert.match(a.sha256,/^[0-9a-f]{64}$/);assert.deepEqual(bytes,before);
 assert.notEqual(a.sha256,outputStats(Buffer.concat([bytes,Buffer.from('remaining')]),true).sha256);
 assert.equal(outputStats(Buffer.alloc(0),true).sha256,'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855');
 assert.throws(()=>outputStats('raw',true));assert.throws(()=>outputStats(bytes,1));
});

test('stderr summaries never copy secret-like contents',()=>{
 const samples=[['','EMPTY'],['error during connect: TOKEN /private','DAEMON_UNAVAILABLE'],['ETIMEDOUT SECRET','TIMEOUT'],['EACCES /private/token','PERMISSION'],['No such container SECRET','NOT_FOUND'],['unknown flag: --token','INVALID_ARGUMENT'],['ENOBUFS /secret','OUTPUT_LIMIT'],['SECRET_CANARY=abcdef URL=https://private','OTHER']];
 for(const [s,expected]of samples){assert.equal(stderrSummary(s),expected);assert.equal(stderrSummary(Buffer.from(s)),expected);}
 assert.throws(()=>stderrSummary({message:'secret'}));
});

test('exact closed payload no raw data and bounded envelope',()=>{
 const p=buildFailure(context(),call(),facts());
 assert.equal(Object.keys(p).length,22);assert.equal(p.rawContentsOmitted,true);assert.equal(p.engine.observedId,null);assert.equal(p.engine.observedAtCallNo,null);
 assert.ok(Buffer.byteLength(JSON.stringify({payload:p,signature:'0'.repeat(64)}))<=8192);
 assert.doesNotMatch(JSON.stringify(p),/SECRET_CANARY|private\/path|Env=TOKEN/);
 assert.ok(Object.isFrozen(p));assert.ok(Object.isFrozen(p.engine));
 const copy=clone(p);assert.deepEqual(copy.stdout,facts().stdout);
});

test('cross run source proposal endpoint stage and malformed hash cannot bind',()=>{
 for(const [k,v]of [['runId','1e23c654-5baf-4b5e-a7b4-6235b1289c0a'],['sourceFingerprint','0'.repeat(64)],['proposalSha256','0'.repeat(64)],['endpoint','tcp://private'],['stage','RETRY'],['packageSha256','oversized'.repeat(2048)],['preparedPlanSha256','bad']]){const c=context();c[k]=v;assert.throws(()=>buildFailure(c,call(),facts()));}
 for(const root of ['ctx','call','facts']){const c=context(),k=call(),f=facts();({ctx:c,call:k,facts:f})[root].unknown='SECRET';assert.throws(()=>buildFailure(c,k,f));}
});

test('engine is observed only when explicit matching fresh call metadata exists',()=>{
 const c=context(),k=call();k.callNo=7;c.engine.observedId=S.ENGINE_ID;c.engine.observedAtCallNo=5;
 assert.equal(buildFailure(c,k,facts()).engine.observedAtCallNo,5);
 for(const patch of [{expectedId:'other'},{observedId:'other'},{observedAtCallNo:8},{observedId:null},{observedAtCallNo:null},{unknown:'raw'}]){const v=context();v.engine={...c.engine,...patch};assert.throws(()=>buildFailure(v,k,facts()));}
});

test('timeouts and output limits must mark both stream hashes incomplete',()=>{
 for(const errorCode of ['ETIMEDOUT','ENOBUFS']){const f=facts();f.errorCode=errorCode;assert.throws(()=>buildFailure(context(),call(),f));f.stdout=outputStats(Buffer.from('part'),false);f.stderr=outputStats(Buffer.from('partial secret'),false);assert.equal(buildFailure(context(),call(),f).stdout.complete,false);}
 const f=facts();f.errorCode='UNKNOWN_WITH_SECRET';assert.equal(buildFailure(context(),call(),f).errorCode,'OTHER');
});

test('unknown nested fields signals summary and pseudo-success fail closed',()=>{
 for(const mutate of [f=>f.stdout.raw='secret',f=>f.stderr.sha256='raw',f=>f.signal='SECRET_SIGNAL',f=>f.stderrSummary='secret text',f=>f.exitCode=0,f=>f.stdout.bytes=-1,f=>f.stderr.bytes=0]){const f=clone(facts());mutate(f);assert.throws(()=>buildFailure(context(),call(),f));}
 for(const mutate of [k=>k.callNo=0,k=>k.durationMs=NaN,k=>k.timeoutMs=-1,k=>k.startedUtc='yesterday',k=>k.safeArgv.target='OLD',k=>k.safeArgv.profileSha256=P,k=>k.safeArgv={...k.safeArgv,raw:['env']}]){const k=clone(call());mutate(k);assert.throws(()=>buildFailure(context(),k,facts()));}
});
