"""Read-only local runtime/cgroup/source preflight, no DB secrets/connections."""
import hashlib
import json
import os
from pathlib import Path
import sys

def main():
    import django
    import psycopg
    assert django.get_version() == '5.2.18' and psycopg.__version__ == '3.3.6'
    assert sys.version_info[:3] == (3,14,10)
    facts = {}
    for key, file in [('memory','memory.max'),('swap','memory.swap.max'),('pids','pids.max')]:
        facts[key] = int(Path('/sys/fs/cgroup',file).read_text().strip())
    assert facts == {'memory':268435456,'swap':0,'pids':64}
    quota, period = map(int, Path('/sys/fs/cgroup/cpu.max').read_text().split())
    assert quota * 1000000000 // period == 500000000 and quota * 1000000000 % period == 0
    mem = dict(line.split(':',1) for line in Path('/proc/meminfo').read_text().splitlines())
    available = int(mem['MemAvailable'].split()[0])*1024
    assert available >= 2147483648
    assert os.access('/usr/bin/timeout', os.X_OK)
    root = Path('/trust')
    rows=[]
    for p in sorted(root.rglob('*.py')):
        assert p.is_file() and not p.is_symlink()
        rows.append({'path':p.relative_to(root).as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
    assert len(rows) == 31
    raw=json.dumps(rows,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
    source=hashlib.sha256(raw).hexdigest()
    assert source == '1d25e6fc62f675d63de1226889e19eea3ac17df22f11b40a9f1a04450ea9940e'
    print(json.dumps({'status':'PASS','scope':'BOUND29-RUNTIME-PREFLIGHT','sourceFingerprint':source,
                      'cgroup':facts,'nanoCpus':500000000,'vmMemAvailable':available,
                      'python':'3.14.10','django':django.get_version(),'psycopg':psycopg.__version__,
                      'sqlExecuted':False,'secretRead':False}))
if __name__=='__main__':
    try: main()
    except BaseException:
        print(json.dumps({'status':'FAIL','scope':'BOUND29-RUNTIME-PREFLIGHT','code':'RUNTIME_PREFLIGHT_FAILED'}))
        raise SystemExit(1) from None
