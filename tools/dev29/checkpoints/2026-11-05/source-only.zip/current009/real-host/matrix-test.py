import copy
import datetime
import importlib.util
import json
from pathlib import Path
import unittest

spec=importlib.util.spec_from_file_location('bound_matrix',Path(__file__).with_name('matrix.py'))
M=importlib.util.module_from_spec(spec); spec.loader.exec_module(M)
A=M.auditor()

def argument():
    return dict(scope='BOUND29-HBA-MATRIX',runId=A.RUN,sourceFingerprint='a'*64,packageSha256='b'*64,admissionSha256='c'*64,
        expiresUtc=(datetime.datetime.now(datetime.timezone.utc)+datetime.timedelta(minutes=5)).isoformat().replace('+00:00','Z'),
        expected=dict(systemIdentifier='1234567890123456789',mainMarker='BOUND29-MAIN:'+A.RUN,unitMarker='BOUND29-UNIT:'+A.RUN,mainOid=101,unitOid=102))

class Failure(Exception):
    def __init__(self,state='28000',primary='pg_hba.conf rejects connection for host synthetic'):
        self.sqlstate=state; self.diag=type('Diag',(),{'message_primary':primary})()

class Cursor:
    def __init__(self,row): self.row=row
    def fetchone(self): return self.row

class Raw:
    def __init__(self,io,role,db): self.io,self.role,self.db=io,role,db
    def execute(self,sql):
        self.io.queries.append(sql)
        if sql=='SHOW transaction_read_only': return Cursor(('on',))
        prefix='main' if self.db==A.MAIN else 'unit'; e=argument()['expected']
        row=(self.db,self.role,self.role,e[prefix+'Oid'],'postgres',e[prefix+'Marker'],True,e['systemIdentifier'])
        if self.io.bad_identity: row=(*row[:6],False,row[7])
        return Cursor(row)
    def rollback(self): self.io.rollbacks+=1
    def close(self): self.io.closes+=1

class IO:
    def __init__(self):
        self.calls=[]; self.reads=[]; self.queries=[]; self.closes=0; self.rollbacks=0
        self.state='28000'; self.primary='pg_hba.conf rejects connection for host synthetic'
        self.bad_identity=False; self.allow_negative=False; self.deny_positive=False
    def source(self): return 'a'*64
    def password(self,role): self.reads.append(role); return 'fake-secret'
    def connect(self,role,db,tls,pwd):
        self.calls.append((role,db,tls))
        if ((role,db,tls) in M.POSITIVES and not self.deny_positive) or self.allow_negative: return Raw(self,role,db)
        raise Failure(self.state,self.primary)

class Tests(unittest.TestCase):
    def reject(self,arg,io,code):
        with self.assertRaises(A.Rejected) as c: M.execute(arg,io)
        self.assertEqual(c.exception.code,code)
    def test_exact_24_two_positives(self):
        io=IO(); result=M.execute(argument(),io)
        self.assertEqual(io.calls,list(M.ATTEMPTS)); self.assertEqual(len(set(io.calls)),24)
        self.assertEqual(result['proof']['positive'],2); self.assertEqual(result['proof']['explicitHbaReject'],22)
        self.assertEqual((io.rollbacks,io.closes),(2,2)); self.assertEqual(len(io.queries),4)
        self.assertTrue(set(io.queries)<={A.IDENTITY,'SHOW transaction_read_only'})
        self.assertNotIn('fake-secret',json.dumps(result))
    def test_invalid_arg_and_source_before_secrets(self):
        for key,value in [('scope','old'),('runId','old'),('expiresUtc','2000-01-01T00:00:00Z')]:
            arg=argument(); arg[key]=value; io=IO(); self.reject(arg,io,'ARG_SCOPE' if key!='expiresUtc' else 'ARG_EXPIRY'); self.assertEqual(io.reads,[])
        io=IO(); io.source=lambda:'bad'; self.reject(argument(),io,'SOURCE_FINGERPRINT'); self.assertEqual(io.reads,[])
        arg=argument(); arg['expected']['unitOid']=None; io=IO(); self.reject(arg,io,'ARG_OID'); self.assertEqual(io.calls,[])
    def test_wrong_auth_or_unknown_db_not_hba_pass(self):
        for state in ('28P01','3D000','08001',None):
            io=IO(); io.state=state; self.reject(argument(),io,'HBA_REJECTION_REQUIRED'); self.assertEqual(len(io.calls),2)
        io=IO(); io.primary='no pg_hba.conf entry'; self.reject(argument(),io,'HBA_REJECTION_REQUIRED')
    def test_unexpected_success_closes_without_identity(self):
        io=IO(); io.allow_negative=True; self.reject(argument(),io,'UNEXPECTED_CONNECTION'); self.assertEqual(io.closes,2); self.assertEqual(len(io.queries),2)
    def test_positive_rejection_not_allowed(self):
        io=IO(); io.deny_positive=True; self.reject(argument(),io,'HBA_REJECTION_REQUIRED'); self.assertEqual(len(io.calls),1)
    def test_positive_wrong_tls_identity_cleanup(self):
        io=IO(); io.bad_identity=True; self.reject(argument(),io,'TARGET_IDENTITY'); self.assertEqual(io.closes,1)
    def test_expiry_source_rechecked_between_attempts(self):
        io=IO(); values=iter(['a'*64,'a'*64,'bad']); io.source=lambda:next(values)
        self.reject(argument(),io,'SOURCE_DRIFT'); self.assertEqual(len(io.calls),1)
    def test_driver_timeout_sanitized(self):
        io=IO(); io.connect=lambda *args:(_ for _ in ()).throw(TimeoutError('SECRET_CANARY'))
        self.reject(argument(),io,'HBA_REJECTION_REQUIRED')

if __name__=='__main__':
    result=unittest.TextTestRunner().run(unittest.defaultTestLoader.loadTestsFromTestCase(Tests))
    print(json.dumps({'status':'PASS' if result.wasSuccessful() else 'FAIL','tests':result.testsRun,'actualConnections':0,'actualSQL':0,'actualSecretReads':0,'runtimeQualified':False}))
    raise SystemExit(not result.wasSuccessful())
