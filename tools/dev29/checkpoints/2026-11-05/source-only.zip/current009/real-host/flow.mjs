import {DBBINDS} from './spec.mjs';
// Common state machine for real adapters and injected-IO gates. No Docker IO here.
import {RUN,SOURCE,ENGINE_ID,hex,ensure,sha,stable} from './spec.mjs';
const same=(a,b,code)=>ensure(stable(a)===stable(b),code);
const passed=(v,scope)=>ensure(v?.status==='PASS'&&(!scope||v.scope===scope),'HOST_EVIDENCE');
export function expectedFromMain(v,sys){passed(v,'BOUND29-READONLY-AUDIT');ensure(v.mode==='MAIN'&&v.proof.targetFacts[7]===sys,'HOST_MAIN_ID');const rows=v.proof.catalogue;const m=rows.find(r=>r[0]==='estakada_trust'),u=rows.find(r=>r[0]==='test_estakada_trust');ensure(rows.length===2&&m&&u&&m[2]==='postgres'&&u[2]==='postgres'&&m[3]==='BOUND29-MAIN:'+RUN&&u[3]==='BOUND29-UNIT:'+RUN,'HOST_CATALOGUE');return {systemIdentifier:sys,mainMarker:m[3],unitMarker:u[3],mainOid:m[1],unitOid:u[1]};}
export function unitSnapshot(v){passed(v,'BOUND29-READONLY-AUDIT');ensure(v.mode==='UNIT','HOST_UNIT_MODE');return {targetFacts:v.proof.targetFacts,catalogue:v.proof.catalogue,tables:v.proof.tables,schemaFingerprint:v.proof.schemaFingerprint,migrations:v.proof.migrations,sequences:v.proof.sequences,migrationSequence:v.proof.migrationSequence};}
export function mainSnapshot(v){passed(v,'BOUND29-READONLY-AUDIT');return {targetFacts:v.proof.targetFacts,catalogue:v.proof.catalogue,roles:v.proof.roles,hba:v.proof.hba,current_settings:v.proof.current_settings,mainLogicalSha:v.proof.mainLogicalSha};}
export async function collectWitness(io,expected,admission){const out={};for(const mode of ['UNIT','MAIN']){try{out[mode]={status:'PASS',value:await io.audit(mode,expected,admission)};}catch(e){out[mode]={status:'UNPROVEN',code:/^[A-Z][A-Z0-9_]{0,79}$/.test(e?.message||'')?e.message:'AUDIT_FAILED'};}}return out;}
function witnessValues(w){ensure(w.UNIT.status==='PASS'&&w.MAIN.status==='PASS','HOST_WITNESS_UNPROVEN');return {unit:w.UNIT.value,main:w.MAIN.value};}
export async function realFlow(io){
 const r={scope:'BOUND29-real-partial-evidence',runId:RUN,status:'FAIL',phase:'PREFLIGHT',code:null,originalPreserved:false,cleanupProved:false,phases:{},witnesses:{},fullP29A:false};let original=null,db=null,network=null,expected=null,pendingWitness=null;
 try{
  await io.verify();await io.preflight();
  original=await io.original('before');await io.budget(original);r.originalBefore=original;
  ensure(typeof io.qualifyKey==='function','KEYPG_QUALIFIER_REQUIRED');validateFlowQualification(await io.qualifyKey());
  const init=await io.admit('INIT',null);r.phase='INIT';
  network=await io.createNetwork(init);db=await io.createDb(init,network);
  const start=await io.startFacts(db,network,init);await io.review('START',start);
  const ready=await io.startDb(db,network,init);ensure(/^[0-9]{10,20}$/.test(ready.systemIdentifier),'HOST_SYSTEM_ID');
  let main=await io.audit('MAIN',{systemIdentifier:ready.systemIdentifier,mainMarker:'BOUND29-MAIN:'+RUN,unitMarker:'BOUND29-UNIT:'+RUN,mainOid:null,unitOid:null},init);
  expected=expectedFromMain(main,ready.systemIdentifier);
  const matrix=await io.matrix(expected,init);passed(matrix,'BOUND29-HBA-MATRIX');
  const migrated=await io.worker('INIT',expected,null,init);passed(migrated,'BOUND29-UNIT-INITIALIZED');
  let unit=await io.audit('UNIT',expected,init);const baseline=unitSnapshot(unit);r.phases.INIT={worker:migrated,baseline,main:mainSnapshot(main),matrix,auditEvidence:{unit:unit.hostEvidence,main:main.hostEvidence}};
  await io.persistPhase('INIT',r.phases.INIT);await io.review('INIT',r.phases.INIT);
  r.phase='C';await io.payloadReview('C',expected,baseline);const c=await io.admit('C',r.phases.INIT);
  pendingWitness={kind:'C',admission:c,baseline};const cap=await io.worker('C',expected,baseline,c);passed(cap,'BOUND29-real-capacity-rollback');
  ensure(cap.real1000CapacityProved===true&&cap.countMocked===false&&cap.bulkSeed===false&&cap.rollbackVerified===true&&cap.nativeLeaseProved===false,'HOST_CAPACITY_PROOF');
  pendingWitness=null;r.witnesses.C=await collectWitness(io,expected,c);({unit,main}=witnessValues(r.witnesses.C));
  same(unitSnapshot(unit),baseline,'HOST_C_ROLLBACK');same(mainSnapshot(main),r.phases.INIT.main,'HOST_C_MAIN');
  r.phases.C={worker:cap,unit,main};await io.persistPhase('C',r.phases.C);await io.review('C',r.phases.C);
  r.phase='T';await io.payloadReview('T',expected,baseline);const t=await io.admit('T',r.phases.C);
  pendingWitness={kind:'T',admission:t,baseline};const suite=await io.worker('T',expected,baseline,t);passed(suite,'BOUND29-standard-Django-suite');ensure(suite.actual139Passed===true&&suite.counts.testsRun===139&&suite.counts.failures===0&&suite.counts.errors===0&&suite.counts.skipped===0&&suite.counts.expectedFailures===0&&suite.counts.unexpectedSuccesses===0,'HOST_SUITE_OUTCOME');
  pendingWitness=null;r.witnesses.T=await collectWitness(io,expected,t);({unit,main}=witnessValues(r.witnesses.T));
  same(mainSnapshot(main),r.phases.INIT.main,'HOST_T_MAIN');const after=unitSnapshot(unit);same(after.schemaFingerprint,baseline.schemaFingerprint,'HOST_T_SCHEMA');same(after.migrations,baseline.migrations,'HOST_T_MIGRATIONS');ensure(after.tables.django_migrations.count===3&&Object.entries(after.tables).every(([k,v])=>k==='django_migrations'||v.count===0),'HOST_T_EMPTY');
  r.phases.T={worker:suite,unit,main,newBaseline:after};await io.persistPhase('T',r.phases.T);await io.review('T',r.phases.T);
  r.status='PASS';r.phase='COMPLETED';
 }catch(e){r.code=/^[A-Z][A-Z0-9_]{0,79}$/.test(e?.message||'')?e.message:'HOST_FAILED';
  if(pendingWitness){const p=pendingWitness;pendingWitness=null;const witnesses=await collectWitness(io,expected,p.admission);r.witnesses[p.kind]=witnesses;try{const {unit,main}=witnessValues(witnesses);same(mainSnapshot(main),r.phases.INIT.main,'HOST_FAILURE_MAIN');if(p.kind==='C')same(unitSnapshot(unit),p.baseline,'HOST_FAILURE_ROLLBACK');else{const after=unitSnapshot(unit);same(after.schemaFingerprint,p.baseline.schemaFingerprint,'HOST_FAILURE_SCHEMA');same(after.migrations,p.baseline.migrations,'HOST_FAILURE_MIGRATIONS');ensure(after.tables.django_migrations.count===3&&Object.entries(after.tables).every(([k,v])=>k==='django_migrations'||v.count===0),'HOST_FAILURE_EMPTY');}r.failureWitness={status:'PASS',kind:p.kind,unit,main};}catch{r.failureWitness={status:'UNPROVEN',kind:p.kind};}}
 }
 finally{
  try{await io.cleanup(db,network);r.cleanupProved=true;}catch{r.cleanupProved=false;r.status='FAIL';r.code='HOST_CLEANUP_UNPROVEN';}
  if(original){try{const after=await io.original('after');same(after,original,'HOST_ORIGINAL_CHANGED');await io.budget(after);r.originalAfter=after;r.originalPreserved=true;}catch{r.status='FAIL';r.code='HOST_ORIGINAL_UNPROVEN';}}
  try{r.terminalInventory=await io.finalInventory();ensure(r.terminalInventory?.empty===true&&r.terminalInventory.engineId===ENGINE_ID&&hex(r.terminalInventory.receiptSha256),'HOST_TERMINAL_EVIDENCE');}catch{r.cleanupProved=false;r.status='FAIL';r.code='HOST_TERMINAL_UNPROVEN';}
 }
 if(!r.cleanupProved||!r.originalPreserved)r.status='FAIL';return r;
}

export function validateFlowQualification(q){const c=q?.qualificationCore;ensure(q?.schema==='KEYPG-QUALIFIED/v1'&&q.originVerifiedSincePrepare===true&&q.stageMatchesOriginCommitment===true&&q.integrityMethod==='PRIVATE_PREPARE_HMAC_SHA256'&&c?.schema==='KEYPG-QUAL-CORE/v1'&&c.runId===RUN&&c.sourceFingerprint===SOURCE&&hex(c.packageSha256)&&hex(c.preparedPlanSha256)&&hex(c.writerEvidenceSha256)&&hex(c.readerEvidenceSha256)&&c.equality===true&&c.credentialReadability===true,'KEYPG_FLOW_QUALIFICATION');ensure(c.profiles?.writer==='10001:999'&&c.profiles.reader==='999:999'&&c.profiles.mode===416&&Array.isArray(c.profiles.readerBinds)&&c.profiles.readerBinds.length===8,'KEYPG_FLOW_PROFILE');same(c.profiles.readerBinds.map(x=>x[0]).sort(),DBBINDS.map(x=>x.source).sort(),'KEYPG_FLOW_SAME_BINDS');return q;}
export function bindQualifiedFlowIO(base,qualifier){ensure(typeof qualifier==='function','KEYPG_QUALIFIER_REQUIRED');let called=false,bound=false,terminal=false;const io={...base,qualifyKey:async()=>{ensure(!called,'KEYPG_QUALIFIER_ONCE');called=true;const q=validateFlowQualification(await qualifier());bound=true;return q;}};for(const name of ['admit','createNetwork','createDb','startFacts','startDb','worker','audit','matrix','payloadReview','review']){const action=base[name];if(typeof action==='function')io[name]=async(...args)=>{ensure(bound&&!terminal,'KEYPG_NOT_BOUND');return await action(...args);};}const stop=base.cleanup;if(typeof stop==='function')io.cleanup=async(...args)=>{terminal=true;return await stop(...args);};return io;}
