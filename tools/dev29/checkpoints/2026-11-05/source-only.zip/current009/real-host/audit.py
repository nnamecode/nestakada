"""Closed, read-only new-cluster auditor. Import performs no IO."""
import datetime
import hashlib
import importlib.util
import json
import re
import signal
import sys

RUN = '066dd89b-2727-4d6d-a16a-b17bdccd9f92'
MAIN, UNIT = 'estakada_trust', 'test_estakada_trust'
TABLES = ('journal_head', 'journal_credential', 'journal_operation', 'journal_routepolicy',
          'journal_requesttombstone', 'journal_recoveryreceipt', 'journal_admissionpolicy', 'django_migrations')
MIGRATIONS = ['0001_initial', '0002_local_test_recovery', '0003_admission_policy']

class Rejected(Exception):
    def __init__(self, code):
        self.code = code
        super().__init__(code)

def require(ok, code):
    if not ok:
        raise Rejected(code)

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode()

def sha(value):
    return hashlib.sha256(canonical(value)).hexdigest()

def validate_arg(arg, now=None):
    require(type(arg) is dict and set(arg) == {'scope','runId','sourceFingerprint','expiresUtc','mode','expected','packageSha256','admissionSha256'}, 'ARG_SCHEMA')
    require(arg['scope'] == 'BOUND29-READONLY-AUDIT' and arg['runId'] == RUN and arg['mode'] in ('MAIN','UNIT'), 'ARG_SCOPE')
    require(all(type(arg[k]) is str and re.fullmatch('[0-9a-f]{64}', arg[k]) for k in ('sourceFingerprint','packageSha256','admissionSha256')), 'ARG_HASH')
    try:
        require(type(arg['expiresUtc']) is str and arg['expiresUtc'].endswith('Z'), 'ARG_EXPIRY')
        expiry = datetime.datetime.fromisoformat(arg['expiresUtc'].replace('Z','+00:00'))
        remaining = (expiry - (now or datetime.datetime.now(datetime.timezone.utc))).total_seconds()
        require(0 < remaining <= 900, 'ARG_EXPIRY')
    except (ValueError, TypeError, OverflowError):
        raise Rejected('ARG_EXPIRY')
    e = arg['expected']
    require(type(e) is dict and set(e) == {'systemIdentifier','mainMarker','unitMarker','mainOid','unitOid'}, 'ARG_EXPECTED')
    require(type(e['systemIdentifier']) is str and re.fullmatch('[0-9]{10,20}', e['systemIdentifier']), 'ARG_SYSTEM_ID')
    require(e['mainMarker'] == 'BOUND29-MAIN:'+RUN and e['unitMarker'] == 'BOUND29-UNIT:'+RUN, 'ARG_MARKER')
    for k in ('mainOid','unitOid'):
        require(type(e[k]) is int and e[k] > 0 or arg['mode']=='MAIN' and e[k] is None, 'ARG_OID')
    require((e['mainOid'] is None) == (e['unitOid'] is None), 'ARG_OID_PAIR')
    return arg

IDENTITY = """SELECT current_database(),current_user,session_user,d.oid,pg_get_userbyid(d.datdba),
shobj_description(d.oid,'pg_database'),(SELECT ssl FROM pg_stat_ssl WHERE pid=pg_backend_pid()),
(SELECT system_identifier::text FROM pg_catalog.pg_control_system()) FROM pg_database d WHERE d.datname=current_database()"""
CATALOGUE = "SELECT datname,oid,pg_get_userbyid(datdba),shobj_description(oid,'pg_database'),datacl::text FROM pg_database WHERE datname IN ('estakada_trust','test_estakada_trust') ORDER BY datname"
CLIENTS = "SELECT datname,usename,backend_type,state,count(*) FROM pg_stat_activity WHERE pid<>pg_backend_pid() AND backend_type='client backend' GROUP BY datname,usename,backend_type,state ORDER BY datname,usename,state"
SCHEMA = "SELECT c.relname,pg_get_userbyid(c.relowner) FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='trust' AND c.relkind IN ('r','p') ORDER BY c.relname"
NAMESPACE = "SELECT pg_get_userbyid(nspowner) FROM pg_namespace WHERE nspname='trust'"
MAIN_OBJECTS = "SELECT (SELECT count(*) FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='trust'),(SELECT count(*) FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace WHERE n.nspname='trust'),(SELECT count(*) FROM pg_type t JOIN pg_namespace n ON n.oid=t.typnamespace WHERE n.nspname='trust')"
ROLES = "SELECT rolname,rolsuper,rolcreatedb,rolcreaterole,rolcanlogin,rolreplication,rolbypassrls FROM pg_roles WHERE rolname IN ('postgres','trust_migrator') ORDER BY rolname"
HBA = "SELECT rule_number,type,database,user_name,address,netmask,auth_method,error FROM pg_hba_file_rules ORDER BY rule_number"
SETTINGS = "SELECT name,setting,unit FROM pg_settings WHERE name IN ('max_connections','shared_buffers','max_wal_size','min_wal_size','ssl','fsync','full_page_writes','synchronous_commit','data_directory','hba_file','ssl_key_file','ssl_cert_file','unix_socket_directories') ORDER BY name"
SEQUENCES = "SELECT schemaname,sequencename,sequenceowner,start_value,min_value,max_value,increment_by,cycle,cache_size,last_value FROM pg_sequences WHERE schemaname='trust' ORDER BY sequencename"
MIGRATION_SEQUENCE = 'SELECT last_value,is_called FROM trust.django_migrations_id_seq'
ROWS = {t: 'SELECT row_to_json(t)::text FROM trust."'+t+'" t ORDER BY row_to_json(t)::text' for t in TABLES}
ALLOWED = frozenset([IDENTITY,CATALOGUE,CLIENTS,SCHEMA,NAMESPACE,MAIN_OBJECTS,ROLES,HBA,SETTINGS,SEQUENCES,MIGRATION_SEQUENCE,'SHOW transaction_read_only','SHOW search_path',*ROWS.values()])
_SHARED = None

def validate_hba(rows):
    expected = [('local',['all'],['all'],None,None,'reject')]
    for kind,db,role,auth in [('hostnossl','all','all','reject'),
                              ('hostssl',UNIT,'trust_migrator','scram-sha-256'),
                              ('hostssl',MAIN,'postgres','scram-sha-256'),
                              ('hostssl','all','all','reject')]:
        for address,mask in [('0.0.0.0','0.0.0.0'),('::','::')]:
            expected.append((kind,[db],[role],address,mask,auth))
    require(len(rows)==len(expected) and all(len(r)==8 and r[0]==i+1 and tuple(r[1:7])==expected[i] and r[7] is None for i,r in enumerate(rows)), 'HBA_RULES')

class ClosedConnection:
    def __init__(self, raw):
        self.raw = raw
    def execute(self, query, params=None):
        require(query in ALLOWED and params is None and ';' not in query, 'QUERY_ALLOWLIST')
        return self.raw.execute(query)
    def stream(self, query):
        require(query in ROWS.values() and ';' not in query, 'QUERY_ALLOWLIST')
        # Named server cursor bounds client buffering; query remains literal.
        return self.raw.cursor(name='bound_audit_rows')

def shared():
    global _SHARED
    if _SHARED is not None:
        return _SHARED
    spec = importlib.util.spec_from_file_location('bound_audit_unit', '/tools/unit_init.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    _SHARED = module
    return module

class ProductionIO:
    def __init__(self):
        self.u = shared()
    def source(self):
        return self.u.source_state()
    def connect(self, mode):
        import psycopg
        raw = psycopg.connect(host='trust-db',port=5432,dbname=MAIN if mode=='MAIN' else UNIT,
            user='postgres' if mode=='MAIN' else 'trust_migrator',password=self.u.password_bytes(),
            sslmode='verify-full',sslrootcert='/run/secrets/database-ca',connect_timeout=3,
            autocommit=False,options='-c default_transaction_read_only=on -c statement_timeout=5000 -c lock_timeout=1000 -c idle_in_transaction_session_timeout=3000 -c search_path=trust,pg_catalog')
        self.u.register_driver(raw)
        raw.isolation_level = psycopg.IsolationLevel.REPEATABLE_READ
        return raw
    def fingerprint(self, raw):
        # Exact reviewed manual catalog algorithm; no Django setup/import.
        return self.u.schema_fingerprint(raw)

def audit(arg, io=None):
    validate_arg(arg)
    io = io or ProductionIO()
    require(io.source() == arg['sourceFingerprint'], 'SOURCE_FINGERPRINT')
    raw = io.connect(arg['mode'])
    try:
        c = ClosedConnection(raw)
        mode, e = arg['mode'], arg['expected']
        name, role = (MAIN,'postgres') if mode=='MAIN' else (UNIT,'trust_migrator')
        ident = c.execute(IDENTITY).fetchone()
        expected_oid = e['mainOid'] if mode=='MAIN' else e['unitOid']
        require(ident is not None and len(ident)==8 and ident[0:3] == (name,role,role) and type(ident[3]) is int and ident[3]>0 and ident[4]=='postgres' and ident[5]==e['mainMarker' if mode=='MAIN' else 'unitMarker'] and ident[6] is True and ident[7]==e['systemIdentifier'] and (expected_oid is None or ident[3]==expected_oid), 'TARGET_IDENTITY')
        require(c.execute('SHOW transaction_read_only').fetchone() == ('on',), 'READONLY_REQUIRED')
        require(c.execute('SHOW search_path').fetchone() == ('trust, pg_catalog',), 'SEARCH_PATH')
        clients = c.execute(CLIENTS).fetchall()
        require(not clients, 'FOREIGN_CLIENTS')
        catalogue = c.execute(CATALOGUE).fetchall()
        require(len(catalogue)==2 and {r[0] for r in catalogue}=={MAIN,UNIT}, 'DATABASE_CATALOGUE')
        for row in catalogue:
            prefix = 'main' if row[0]==MAIN else 'unit'
            require(row[2]=='postgres' and row[3]==e[prefix+'Marker'] and (e[prefix+'Oid'] is None or row[1]==e[prefix+'Oid']), 'DATABASE_CATALOGUE')
        owners = c.execute(NAMESPACE).fetchall()
        tables = c.execute(SCHEMA).fetchall()
        proof = {'targetFacts':list(ident),'catalogue':catalogue,'currentClients':clients}
        if mode=='MAIN':
            objects = c.execute(MAIN_OBJECTS).fetchone()
            require(owners==[('postgres',)] and not tables and objects==(0,0,0), 'MAIN_NOT_EMPTY')
            roles = c.execute(ROLES).fetchall()
            require(len(roles)==2 and roles[0]==('postgres',True,True,True,True,True,True) and roles[1]==('trust_migrator',False,False,False,True,False,False), 'ROLE_CAPABILITIES')
            hba = c.execute(HBA).fetchall()
            validate_hba(hba)
            # Only projected, non-secret settings are returned.
            settings = c.execute(SETTINGS).fetchall()
            sm = {r[0]:r[1] for r in settings}
            require(sm.get('max_connections')=='16' and sm.get('shared_buffers')=='8192' and sm.get('max_wal_size')=='128' and sm.get('min_wal_size')=='32' and all(sm.get(k)=='on' for k in ('ssl','fsync','full_page_writes','synchronous_commit')), 'SERVER_SETTINGS')
            require(all(sm.get(k)==v for k,v in {'data_directory':'/var/lib/postgresql/18/docker','hba_file':'/config/runtime.hba','ssl_key_file':'/var/run/postgresql/server.key','ssl_cert_file':'/run/secrets/database-ca','unix_socket_directories':'/var/run/postgresql'}.items()),'SERVER_PATHS')
            proof.update(roles=roles,hba=hba,current_settings=settings,mainLogicalSha=sha({'namespace':owners,'tables':tables,'objects':objects}))
        else:
            require(owners==[('trust_migrator',)] and {r[0] for r in tables}==set(TABLES) and all(r[1]=='trust_migrator' for r in tables), 'UNIT_SCHEMA')
            roles = c.execute(ROLES).fetchall()
            require([r for r in roles if r[0]=='trust_migrator']==[('trust_migrator',False,False,False,True,False,False)],'ROLE_CAPABILITIES')
            rows = {}
            migrations = []
            for table in TABLES:
                count, digest = 0, hashlib.sha256()
                with c.stream(ROWS[table]) as cursor:
                    cursor.itersize = 16
                    cursor.execute(ROWS[table])
                    for row in cursor:
                        require(len(row)==1 and type(row[0]) is str and len(row[0].encode())<=1048576, 'ROW_FRAME')
                        encoded = row[0].encode()
                        digest.update(len(encoded).to_bytes(8,'big')); digest.update(encoded)
                        count += 1
                        require(count<=1000, 'ROW_LIMIT')
                        if table=='django_migrations':
                            record = json.loads(row[0]); migrations.append((record['app'],record['name']))
                require(table=='django_migrations' or count==0, 'UNIT_NOT_EMPTY')
                rows[table] = {'count':count,'sha256':digest.hexdigest()}
            require(sorted(migrations)==[('journal',x) for x in MIGRATIONS], 'MIGRATIONS')
            migration_sequence = c.execute(MIGRATION_SEQUENCE).fetchall()
            require(len(migration_sequence)==1 and len(migration_sequence[0])==2 and
                    type(migration_sequence[0][0]) is int and migration_sequence[0][0]>0 and
                    type(migration_sequence[0][1]) is bool, 'MIGRATION_SEQUENCE')
            proof.update(tables=rows,schemaFingerprint=io.fingerprint(raw),migrations=MIGRATIONS,
                         sequences=c.execute(SEQUENCES).fetchall(),migrationSequence=list(migration_sequence[0]))
        require(io.source()==arg['sourceFingerprint'], 'SOURCE_DRIFT')
        validate_arg(arg)
        return {'status':'PASS','scope':arg['scope'],'runId':RUN,'mode':mode,'sourceFingerprint':arg['sourceFingerprint'],'proof':proof}
    finally:
        try:
            raw.rollback()
        finally:
            raw.close()

def execute(arg, io=None):
    try:
        return audit(arg,io)
    except Rejected:
        raise
    except BaseException:
        raise Rejected('AUDIT_FAILED') from None

def parse_arg(raw):
    require(len(raw)<=16384, 'ARG_SIZE')
    def pairs(items):
        result = {}
        for k,v in items:
            require(k not in result, 'ARG_DUPLICATE'); result[k]=v
        return result
    try:
        return json.loads(raw,object_pairs_hook=pairs,parse_constant=lambda _: (_ for _ in ()).throw(Rejected('ARG_JSON')))
    except (ValueError,UnicodeError):
        raise Rejected('ARG_JSON') from None

def main():
    import os
    arg = parse_arg(sys.stdin.buffer.read(16385)); validate_arg(arg)
    u = shared()
    def expired(signum,frame):
        u.close_drivers(); os._exit(124)
    signal.signal(signal.SIGALRM,expired); signal.alarm(60)
    try:
        result = execute(arg)
    finally:
        signal.alarm(0); u.close_drivers()
    data = canonical(result)
    require(len(data)<=65536,'OUTPUT_LIMIT')
    print(data.decode())

if __name__=='__main__':
    try:
        main()
    except BaseException as exc:
        print(json.dumps({'status':'FAIL','code':exc.code if isinstance(exc,Rejected) else 'AUDIT_FAILED'}))
        sys.exit(1)
