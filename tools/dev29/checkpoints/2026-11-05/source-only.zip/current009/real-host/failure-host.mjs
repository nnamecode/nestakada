// Inert host adapter logic; all process/storage/clock effects are explicit inputs.
import * as Trace from './failure-trace.mjs';
import {ensure,sha,stable} from './spec.mjs';
import {createHash} from 'node:crypto';

export function streamFailure(ctx,call,io){
 const context=structuredClone(ctx),base=structuredClone(call),began=io.startedMs;
 ensure(Number.isFinite(began)&&Number.isFinite(io.storageDeadline),'RESUME_STREAM_CLOCK');
 const hashes={stdout:createHash('sha256'),stderr:createHash('sha256')},bytes={stdout:0,stderr:0};let emitted=false;
 return {
  update(which,buffer){ensure(Object.hasOwn(hashes,which)&&Buffer.isBuffer(buffer),'RESUME_STREAM_INPUT');hashes[which].update(buffer);bytes[which]+=buffer.length;},
  fail({dispatched=true,exitCode=null,errorCode=null,signal=null,complete=false,stderrSummary='OTHER'}){
   if(emitted)return false;emitted=true;
   const meta=which=>({bytes:bytes[which],sha256:hashes[which].copy().digest('hex'),complete});
   return io.failure(context,{...base,durationMs:Math.round(io.now()-began)},{dispatched,exitCode,errorCode,signal,stdout:meta('stdout'),stderr:meta('stderr'),stderrSummary},io.storageDeadline);
  }
 };
}

export function archiveFailure(ctx,call,facts,io){
 if(io.disabled?.()){io.missing?.();return false;}
 try{
  const deadline=io.deadline();
  ensure(Number.isFinite(deadline)&&io.now()<deadline,'RESUME_TRACE_DEADLINE');
  const payload=Trace.buildFailure(ctx,call,facts),envelope=io.sign(payload);
  ensure(envelope&&Object.keys(envelope).sort().join()==='payload,signature'&&stable(envelope.payload)===stable(payload)&&/^[a-f0-9]{64}$/.test(envelope.signature),'RESUME_TRACE_ENVELOPE');
  ensure(Buffer.byteLength(stable(envelope))<=8192,'RESUME_TRACE_CAP');
  const name='docker-failure-'+call.callNo+'.json',hash=io.write(name,envelope);
  ensure(hash===sha(stable(envelope)),'RESUME_TRACE_WRITE_HASH');
  io.ledger(name,hash);
  ensure(io.now()<deadline,'RESUME_TRACE_DEADLINE');
  return true;
 }catch{io.unproven();return false;}
}

export function executeDockerCall(options,io){
 const {args,bindings,ctx,callNo,timeout:requested,deadline,onDispatch=null,optional=false}=options;
 const began=io.now(),startedUtc=io.utc();
 const safeArgv=Trace.projectArgv(args,bindings);
 ensure(Number.isFinite(requested)&&requested>0,'TRACE_TIMEOUT');
 const storageDeadline=Math.min(began+requested,deadline===null?Infinity:deadline);
 // Logging consumes the original call/work budget; cleanup's 30s are separate.
 const timeout=Math.floor(storageDeadline-io.now())-1000;
 const call=()=>({callNo,safeArgv,startedUtc,durationMs:Math.round(io.now()-began),timeoutMs:Math.max(0,timeout)});
 if(timeout<=0){
  io.failure(ctx,call(),{dispatched:false,exitCode:null,errorCode:'ETIMEDOUT',signal:null,stdout:Trace.outputStats(Buffer.alloc(0),false),stderr:Trace.outputStats(Buffer.alloc(0),false),stderrSummary:'TIMEOUT'},storageDeadline);
  throw Error('HOST_AUDIT_DEADLINE');
 }
 let r,dispatched=false;
 try{if(onDispatch)onDispatch();dispatched=true;r=io.invoke(args,timeout);}
 catch(e){r={status:null,signal:null,error:{code:e.code||'OTHER'},stdout:Buffer.alloc(0),stderr:Buffer.alloc(0)};}
 ensure((r.stdout===null||Buffer.isBuffer(r.stdout))&&(r.stderr===null||Buffer.isBuffer(r.stderr)),'TRACE_TRANSPORT_BUFFER');
 const out=Buffer.isBuffer(r.stdout)?r.stdout:Buffer.alloc(0),err=Buffer.isBuffer(r.stderr)?r.stderr:Buffer.alloc(0);
 if(r.error||r.status!==0||r.signal){
  const complete=!r.error&&r.status!==null&&!r.signal,errorCode=r.error?.code||null;
  io.failure(ctx,call(),{dispatched,exitCode:r.status??null,errorCode,signal:r.signal||null,stdout:Trace.outputStats(out,complete),stderr:Trace.outputStats(err,complete),stderrSummary:errorCode==='ETIMEDOUT'?'TIMEOUT':errorCode==='ENOBUFS'?'OUTPUT_LIMIT':Trace.stderrSummary(err)},storageDeadline);
 }
 if(!optional)ensure(!r.error&&r.status===0,'HOST_DOCKER');
 return {...r,stdout:out.toString('utf8'),stderr:err.toString('utf8'),bound29CallNo:callNo};
}

export function commitResult(value,io){
 const before=io.flags();
 const result={...value,diagnosticUnproven:before.diagnosticUnproven,evidenceIncomplete:before.evidenceIncomplete};
 if(before.diagnosticUnproven||before.evidenceIncomplete){result.status='FAIL';result.code='RESUME_DIAGNOSTIC_UNPROVEN';}
 if(before.evidenceIncomplete)result.cleanupProved=false;
 try{
  const receipt=io.write(result);
  ensure(receipt&&stable(io.flags())===stable(before),'RESUME_RESULT_UNPROVEN');
  return {result,persisted:true};
 }catch{
  return {result:{...result,status:'FAIL',code:'RESUME_RESULT_UNPROVEN',diagnosticUnproven:true,evidenceIncomplete:true},persisted:false};
 }
}
