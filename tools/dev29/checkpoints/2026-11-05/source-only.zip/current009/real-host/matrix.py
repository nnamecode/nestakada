"""Closed 24-attempt IPv4 new-cluster HBA matrix; import is inert."""
import importlib.util
import json
import os
from pathlib import Path
import re
import signal
import stat
import sys

_AUDIT = None

def auditor():
    global _AUDIT
    if _AUDIT is None:
        spec=importlib.util.spec_from_file_location('bound_matrix_audit',Path(__file__).resolve().with_name('audit.py'))
        _AUDIT=importlib.util.module_from_spec(spec); spec.loader.exec_module(_AUDIT)
    return _AUDIT

ROLES=('postgres','trust_migrator')
DATABASES=('estakada_trust','test_estakada_trust','postgres','archivecal7e145c49','archivecap32563','bound29_unknown')
TLS=('verify-full','disable')
ATTEMPTS=tuple((role,db,tls) for role in ROLES for db in DATABASES for tls in TLS)
POSITIVES=frozenset([('postgres','estakada_trust','verify-full'),('trust_migrator','test_estakada_trust','verify-full')])
PASSWORD_FILES={'postgres':'/run/secrets/bootstrap-password','trust_migrator':'/run/secrets/migrator-password'}

def validate_arg(arg,now=None):
    a=auditor()
    a.require(type(arg) is dict and set(arg)=={'scope','runId','sourceFingerprint','expiresUtc','expected','packageSha256','admissionSha256'},'ARG_SCHEMA')
    a.require(arg['scope']=='BOUND29-HBA-MATRIX','ARG_SCOPE')
    probe=dict(arg,scope='BOUND29-READONLY-AUDIT',mode='UNIT')
    a.validate_arg(probe,now)
    return arg

def password(role):
    a=auditor()
    a.require(role in PASSWORD_FILES,'ROLE_FIXED')
    path=Path(PASSWORD_FILES[role]); meta=path.lstat()
    a.require(stat.S_ISREG(meta.st_mode) and not path.is_symlink() and meta.st_size in (96,97),'PASSWORD_FILE')
    data=path.read_bytes()
    a.require(re.fullmatch(b'[0-9a-f]{96}\n?',data),'PASSWORD_FORMAT')
    return data.rstrip(b'\n').decode('ascii')

class ProductionIO:
    def __init__(self): self.u=auditor().shared()
    def source(self): return self.u.source_state()
    def password(self,role): return password(role)
    def connect(self,role,db,tls,pwd):
        import psycopg
        raw=psycopg.connect(host='trust-db',port=5432,dbname=db,user=role,password=pwd,
            sslmode=tls,sslrootcert='/run/secrets/database-ca',connect_timeout=3,autocommit=False,
            options='-c default_transaction_read_only=on -c statement_timeout=5000 -c lock_timeout=1000 -c idle_in_transaction_session_timeout=3000 -c search_path=trust,pg_catalog')
        self.u.register_driver(raw)
        return raw

def matrix(arg,io=None):
    a=auditor(); validate_arg(arg)
    io=io or ProductionIO()
    a.require(io.source()==arg['sourceFingerprint'],'SOURCE_FINGERPRINT')
    secrets={role:io.password(role) for role in ROLES}
    results=[]
    try:
        for role,db,tls in ATTEMPTS:
            validate_arg(arg)
            a.require(io.source()==arg['sourceFingerprint'],'SOURCE_DRIFT')
            positive=(role,db,tls) in POSITIVES
            try:
                raw=io.connect(role,db,tls,secrets[role])
            except Exception as exc:
                state=getattr(exc,'sqlstate',None)
                diag=getattr(exc,'diag',None)
                primary=getattr(diag,'message_primary','')
                a.require(not positive and state=='28000' and type(primary) is str and primary.startswith('pg_hba.conf rejects connection for host '),'HBA_REJECTION_REQUIRED')
                results.append({'role':role,'database':db,'tls':tls,'status':'REJECTED_28000'})
                continue
            try:
                a.require(positive,'UNEXPECTED_CONNECTION')
                c=a.ClosedConnection(raw)
                row=c.execute(a.IDENTITY).fetchone(); e=arg['expected']; prefix='main' if db==a.MAIN else 'unit'
                a.require(row==(db,role,role,e[prefix+'Oid'],'postgres',e[prefix+'Marker'],True,e['systemIdentifier']),'TARGET_IDENTITY')
                a.require(c.execute('SHOW transaction_read_only').fetchone()==('on',),'READONLY_REQUIRED')
                results.append({'role':role,'database':db,'tls':tls,'status':'READONLY_IDENTITY_PASS'})
            finally:
                try: raw.rollback()
                finally: raw.close()
        validate_arg(arg)
        a.require(io.source()==arg['sourceFingerprint'],'SOURCE_DRIFT')
        a.require(len(results)==24 and sum(r['status']=='READONLY_IDENTITY_PASS' for r in results)==2,'MATRIX_INCOMPLETE')
        return {'status':'PASS','scope':arg['scope'],'runId':a.RUN,'sourceFingerprint':arg['sourceFingerprint'],
                'proof':{'networkScope':'new-network-IPv4-only','positive':2,'explicitHbaReject':22,'attempts':results}}
    finally:
        secrets.clear()

def execute(arg,io=None):
    a=auditor()
    try: return matrix(arg,io)
    except a.Rejected: raise
    except BaseException: raise a.Rejected('MATRIX_FAILED') from None

def main():
    a=auditor(); arg=a.parse_arg(sys.stdin.buffer.read(16385)); validate_arg(arg)
    u=a.shared()
    def expired(signum,frame): u.close_drivers(); os._exit(124)
    signal.signal(signal.SIGALRM,expired); signal.alarm(60)
    try: result=execute(arg)
    finally: signal.alarm(0); u.close_drivers()
    data=a.canonical(result); a.require(len(data)<=16384,'OUTPUT_LIMIT'); print(data.decode())

if __name__=='__main__':
    try: main()
    except BaseException as exc:
        a=auditor(); print(json.dumps({'status':'FAIL','code':exc.code if isinstance(exc,a.Rejected) else 'MATRIX_FAILED'})); sys.exit(1)
