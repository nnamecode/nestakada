#!/bin/sh
# RO original-volume inspector; never calls entrypoint, postgres, psql or initdb.
set -eu
export LC_ALL=C TMPDIR=/tmp
root=/var/lib/postgresql
data=/var/lib/postgresql/18/docker
test "$(/usr/bin/id -u)" = 999
test "$(/usr/bin/id -g)" = 999
test ! -L "$root"
test ! -L "$root/18"
test ! -L "$data"
test -d "$data/base"
test -d "$data/pg_wal"
test ! -e "$data/postmaster.pid"
test "$(/usr/bin/cat "$data/PG_VERSION")" = 18
# No pipeline may conceal a failing source collector.
/usr/bin/find "$root" -xdev -printf '%p\t%y\t%m\t%U\t%G\t%s\t%b\n' > /tmp/inventory
count=$(/usr/bin/wc -l < /tmp/inventory)
test "$count" -le 12000
/usr/bin/sort /tmp/inventory > /tmp/manifest
# Reject all non-regular files and ambiguous paths before hashing any data.
while IFS="$(printf '\t')" read -r name kind mode uid gid size blocks; do
  case "$name" in "$root"|"$root"/*) :;; *) exit 1;; esac
  case "$name" in *[!A-Za-z0-9_./-]*) exit 1;; esac
  case "$kind" in f|d) :;; *) exit 1;; esac
done < /tmp/manifest
/usr/local/pgsql/bin/pg_controldata "$data" > /tmp/control
state=$(/usr/bin/sed -n 's/^Database cluster state: *//p' /tmp/control)
test "$state" = 'shut down'
system=$(/usr/bin/sed -n 's/^Database system identifier: *//p' /tmp/control)
/usr/bin/du -sk "$root" > /tmp/allocation
allocated=$(/usr/bin/cut -f1 /tmp/allocation)
printf 'BOUND29_RO_V1\nSYSTEM %s\nSTATE shut_down\nALLOC_KIB %s\nCOUNT %s\n' "$system" "$allocated" "$count"
while IFS="$(printf '\t')" read -r name kind mode uid gid size blocks; do
  case "$name" in "$root") name=.;; "$root"/*) name=${name#"$root"/};; *) exit 1;; esac
  if [ "$kind" = f ]; then
    hash=$(/usr/bin/sha256sum "$root/$name")
    hash=${hash%% *}
  else
    test "$kind" = d
    hash=-
  fi
  printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n' "$kind" "$mode" "$uid" "$gid" "$size" "$blocks" "$hash" "$name"
done < /tmp/manifest
printf 'END\n'
