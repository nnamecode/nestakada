import {RUN,ensure,closed,hex,stable} from './guards.mjs';
export const CASES=Object.freeze(['good','runtime-exit','bootstrap-sql-timeout','ignore-stop']);
export function frames(raw,{partial=false}={}){
 ensure(typeof raw==='string'&&Buffer.byteLength(raw)<=1048576&&!raw.includes('\r'),'BOUND_QA_OUTPUT');
 const lines=raw.split('\n');const tail=lines.pop();ensure(partial||tail==='','BOUND_QA_PARTIAL');
 ensure(lines.length<=16,'BOUND_QA_FRAMES');let nonce='',system='',mount='';
 return lines.map((line,i)=>{
  ensure(Buffer.byteLength(line)<4096,'BOUND_QA_FRAME_SIZE');let v;try{v=JSON.parse(line);}catch{throw Error('BOUND_QA_JSON');}
  closed(v,['runId','sequence','state','status','pid1','childPid','nonce','systemIdentifier','mountDigest','contentDigest','code']);
  ensure(v.runId===RUN&&v.sequence===i+1&&v.pid1===1&&Number.isSafeInteger(v.childPid)&&v.childPid>=0&&['NOT_STARTED','INITDB','BOOTSTRAP_SOCKET_ONLY','CLEAN_CHILD_STOP','RUNTIME_TLS','FINAL_CLEAN_STOP'].includes(v.state)&&['ENTERED','STOP_REQUESTED','READY','STOPPED','FAIL'].includes(v.status),'BOUND_QA_FRAME');
  ensure(v.nonce===''||/^[a-f0-9]{32}$/.test(v.nonce),'BOUND_QA_NONCE');
  ensure(v.systemIdentifier===''||/^[0-9]{10,20}$/.test(v.systemIdentifier),'BOUND_QA_SYSTEM');
  for(const k of ['mountDigest','contentDigest'])ensure(v[k]===''||hex(v[k]),'BOUND_QA_DIGEST');
  ensure(v.status==='FAIL'?/^[A-Z][A-Z0-9_]{0,79}$/.test(v.code):v.code==='','BOUND_QA_CODE');
  for(const [key,old]of [['nonce',nonce],['systemIdentifier',system],['mountDigest',mount]])if(old)ensure(v[key]===old,'BOUND_QA_CONTINUITY');
  nonce=v.nonce||nonce;system=v.systemIdentifier||system;mount=v.mountDigest||mount;
  return v;
 });
}
export function outcome(which,raw,exitCode,stderr){
 ensure(CASES.includes(which)&&stderr==='','BOUND_QA_CASE_OUTPUT');const rows=frames(raw);
 ensure(rows.length>0,'BOUND_QA_NO_FRAMES');
 if(which==='good'){
  const order=[['INITDB','ENTERED'],['BOOTSTRAP_SOCKET_ONLY','ENTERED'],['BOOTSTRAP_SOCKET_ONLY','STOP_REQUESTED'],['CLEAN_CHILD_STOP','ENTERED'],['RUNTIME_TLS','ENTERED'],['RUNTIME_TLS','READY'],['RUNTIME_TLS','STOP_REQUESTED'],['FINAL_CLEAN_STOP','STOPPED']];
  ensure(exitCode===0&&stable(rows.map(x=>[x.state,x.status]))===stable(order),'BOUND_QA_FINAL_SEQUENCE');
  const last=rows.at(-1);ensure(hex(last.contentDigest)&&hex(last.mountDigest)&&last.nonce!==''&&last.systemIdentifier!==''&&last.childPid===0,'BOUND_QA_FINAL_PROOF');
 }else{
  const code={'runtime-exit':'UNEXPECTED_RUNTIME_CHILD_EXIT','bootstrap-sql-timeout':'BOOTSTRAP_SQL_FAILED','ignore-stop':'FINAL_CHILD_STOP_UNPROVED'}[which];
  ensure(Number.isInteger(exitCode)&&exitCode!==0&&rows.some(v=>v.status==='FAIL'&&v.code===code)&&!rows.some(v=>v.status==='STOPPED'),'BOUND_QA_NEGATIVE');
 }
 return {case:which,status:'PASS',realSql:false,realPostgres:false,frames:rows.length,exitCode};
}
