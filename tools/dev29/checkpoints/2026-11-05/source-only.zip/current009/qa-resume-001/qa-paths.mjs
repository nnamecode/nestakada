// Read-only Windows path gates. No file creation, key reads or dispatch here.
import path from 'node:path';
import {canonical,ensure} from './guards.mjs';
const win=path.win32,ROOT='t:/nestakada';
const equal=(a,b)=>canonical(a)===canonical(b);
function absolute(value){
  ensure(typeof value==='string'&&/^[a-z]:[\\/]/i.test(value)&&!value.includes('\0'),'QA_PATH_ABSOLUTE');
  // Reject aliases the caller might later resolve differently (or as NTFS ADS).
  ensure(!value.slice(2).includes(':')&&!value.split(/[\\/]/).some(s=>s==='.'||s==='..'),'QA_PATH_ALIAS');
  return win.resolve(value);
}
function rootPath(root){const resolved=absolute(root);ensure(canonical(resolved)===ROOT,'QA_PROJECT_ROOT');return resolved;}
function inside(root,target){const resolved=absolute(target),relative=win.relative(root,resolved);
  ensure(relative===''||!win.isAbsolute(relative)&&relative!=='..'&&!relative.startsWith('..\\'),'QA_PATH_SCOPE');
  return {resolved,relative};
}
function actual(fs,file){const observed=fs.realpathSync(file);ensure(equal(observed,file),'QA_REALPATH_ALIAS');}
function directory(fs,dir){const stat=fs.lstatSync(dir);
  ensure(stat.isDirectory()&&!stat.isSymbolicLink(),'QA_DIRECTORY_LINK_OR_TYPE');actual(fs,dir);}
export function dirChain(fs,root,target){
  root=rootPath(root);const {resolved,relative}=inside(root,target);let current=root;directory(fs,current);
  for(const name of relative.split('\\').filter(Boolean)){current=win.join(current,name);directory(fs,current);}
  return resolved;
}
export function regularFile(fs,root,file){
  root=rootPath(root);const {resolved,relative}=inside(root,file);ensure(relative!=='','QA_FILE_IS_ROOT');
  dirChain(fs,root,win.dirname(resolved));const stat=fs.lstatSync(resolved);
  ensure(stat.isFile()&&!stat.isSymbolicLink()&&stat.nlink===1,'QA_FILE_LINK_OR_TYPE');actual(fs,resolved);
  return resolved;
}
function absentByLstat(fs,file){
  try{fs.lstatSync(file);return false;}catch(error){if(error?.code==='ENOENT')return true;throw error;}
}
export function inputsGate(fs,root,here,art,{consumed=false}={}){
  ensure(typeof consumed==='boolean','QA_CONSUMED_TYPE');root=rootPath(root);
  const safeHere=dirChain(fs,root,here),safeArt=dirChain(fs,root,art);
  ensure(equal(safeArt,win.join(safeHere,'qa-run')),'QA_ARTIFACT_DIRECTORY');
  const attempt=win.join(safeArt,'attempt.json');
  if(!consumed)ensure(absentByLstat(fs,attempt),'QA_ATTEMPT_EXISTS');
  const expected=['intent.json','owner.txt','approved-review.md',...(consumed?['attempt.json']:[])].sort();
  const entries=fs.readdirSync(safeArt);
  ensure(Array.isArray(entries)&&entries.every(n=>typeof n==='string')&&
    JSON.stringify([...entries].sort())===JSON.stringify(expected),'QA_INPUT_ENTRIES');
  const files=expected.map(name=>regularFile(fs,root,win.join(safeArt,name)));
  return {here:safeHere,art:safeArt,files};
}
