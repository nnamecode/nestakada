import os,stat,errno,json,hmac
r=dict(scope='KEY29-WRITER',version=1,uid=os.geteuid(),gid=os.getegid(),status='FAIL',error=None,created=False,bytesEqual=False,sourceSize=None,fileUid=None,fileGid=None,mode=None,size=None,nlink=None,regular=False)
src=out=fd=None
allowed={'EACCES','EPERM','ENOENT','ENOTDIR','ELOOP','EIO','ESTALE','EEXIST','ENOSPC'}
def fail(c):raise RuntimeError(c)
def ident(s):return (s.st_dev,s.st_ino,s.st_size,s.st_mode,s.st_uid,s.st_gid,s.st_nlink,s.st_mtime_ns,s.st_ctime_ns)
try:
 if r['uid']!=10001 or r['gid']!=999:fail('USER')
 l=os.lstat('/probe/source');src=os.open('/probe/source',os.O_RDONLY|os.O_NOFOLLOW);s=os.fstat(src)
 if not stat.S_ISREG(l.st_mode) or ident(l)!=ident(s) or s.st_nlink!=1 or s.st_uid!=10001 or s.st_gid!=10001 or stat.S_IMODE(s.st_mode)!=0o600:fail('SOURCE')
 if not 0<s.st_size<=8192:fail('SIZE')
 r['sourceSize']=s.st_size
 d=os.lstat('/probe/out');out=os.open('/probe/out',os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
 if not stat.S_ISDIR(d.st_mode) or (d.st_dev,d.st_ino)!=(os.fstat(out).st_dev,os.fstat(out).st_ino) or os.listdir(out):fail('DIRECTORY')
 fd=os.open('database-server-key',os.O_RDWR|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600,dir_fd=out);r['created']=True
 os.fchmod(fd,0o640);n=os.fstat(fd)
 if not stat.S_ISREG(n.st_mode) or n.st_uid!=10001 or n.st_gid!=999 or stat.S_IMODE(n.st_mode)!=0o640 or n.st_nlink!=1:fail('TARGET')
 data=os.read(src,8192)
 if len(data)!=s.st_size or ident(os.fstat(src))!=ident(s):fail('SOURCE_RACE')
 if os.write(fd,data)!=len(data):fail('WRITE')
 os.lseek(fd,0,os.SEEK_SET);back=os.read(fd,8192);f=os.fstat(fd);p=os.stat('database-server-key',dir_fd=out,follow_symlinks=False)
 if ident(f)!=ident(p) or f.st_size!=len(data) or f.st_nlink!=1 or f.st_uid!=10001 or f.st_gid!=999 or stat.S_IMODE(f.st_mode)!=0o640:fail('TARGET_RACE')
 if ident(os.fstat(src))!=ident(s):fail('SOURCE_RACE')
 if not hmac.compare_digest(data,back):fail('READBACK')
 r.update(status='PASS',bytesEqual=True,fileUid=f.st_uid,fileGid=f.st_gid,mode=stat.S_IMODE(f.st_mode),size=f.st_size,nlink=f.st_nlink,regular=True)
except OSError as e:r['error']=errno.errorcode.get(e.errno,'OTHER') if errno.errorcode.get(e.errno,'OTHER') in allowed else 'OTHER'
except RuntimeError as e:r['error']=str(e) if str(e) in {'USER','SOURCE','SIZE','DIRECTORY','TARGET','SOURCE_RACE','WRITE','TARGET_RACE','READBACK'} else 'OTHER'
except Exception:r['error']='OTHER'
finally:
 for handle in [fd,out,src]:
  if handle is not None:
   try:os.close(handle)
   except Exception:r.update(status='FAIL',error='CLOSE',bytesEqual=False)
print(json.dumps(r,sort_keys=True,separators=(',',':')))
