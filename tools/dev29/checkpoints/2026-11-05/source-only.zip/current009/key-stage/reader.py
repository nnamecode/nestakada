import os,stat,errno,json
p='/probe/key'
r=dict(scope='KEY29-READER',version=1,uid=os.geteuid(),gid=os.getegid(),fileUid=None,fileGid=None,mode=None,size=None,nlink=None,regular=False,symlink=False,readable=False,openReadOnly=False,openedIdentityMatches=None,errno=None)
fd=None
allowed={'EACCES','EPERM','ENOENT','ENOTDIR','ELOOP','EIO','ESTALE','EMFILE','ENFILE'}
def code(e):
 n=errno.errorcode.get(e.errno,'OTHER')
 return n if n in allowed else 'OTHER'
try:
 l=os.lstat(p);s=os.stat(p,follow_symlinks=False)
 r.update(fileUid=s.st_uid,fileGid=s.st_gid,mode=stat.S_IMODE(s.st_mode),size=s.st_size,nlink=s.st_nlink,regular=stat.S_ISREG(s.st_mode),symlink=stat.S_ISLNK(l.st_mode),readable=os.access(p,os.R_OK))
 if not r['regular'] or r['symlink'] or s.st_nlink!=1 or s.st_uid!=10001 or s.st_gid!=999 or stat.S_IMODE(s.st_mode)!=0o640 or (l.st_dev,l.st_ino,l.st_size)!=(s.st_dev,s.st_ino,s.st_size):
  r['errno']='ESTALE'
 else:
  fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW);r['openReadOnly']=True
  f=os.fstat(fd);r['openedIdentityMatches']=stat.S_ISREG(f.st_mode) and (f.st_dev,f.st_ino,f.st_size)==(s.st_dev,s.st_ino,s.st_size)
  if not r['openedIdentityMatches']:r['errno']='ESTALE'
except OSError as e:r['errno']=code(e)
except Exception:r['errno']='OTHER'
finally:
 if fd is not None:
  try:os.close(fd)
  except OSError as e:r['errno']=code(e);r['openedIdentityMatches']=False
print(json.dumps(r,sort_keys=True,separators=(',',':')))
