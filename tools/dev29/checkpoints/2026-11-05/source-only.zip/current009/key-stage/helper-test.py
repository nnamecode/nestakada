import unittest,types,stat,errno,json,builtins,contextlib,io,pathlib
WRITER=pathlib.Path(__file__).with_name('writer.py').read_text(encoding='utf-8')
READER=pathlib.Path(__file__).with_name('reader.py').read_text(encoding='utf-8')
DATA=b'DUMMY_TEST_DATA_NOT_A_KEY'*50
class WriterTests(unittest.TestCase):
 def run_case(self,case='success'):
  calls=[];state={'mode':0o600,'data':b'','srcstat':0}
  def meta(which):
   if which==1:
    state['srcstat']+=1;size=8193 if case=='oversize' else len(DATA);ino=12 if case=='source_identity' and state['srcstat']>1 else 11;mtime=9 if case=='source_race' and state['srcstat']>2 else 3
    return types.SimpleNamespace(st_mode=stat.S_IFREG|0o600,st_uid=10001,st_gid=10001,st_nlink=1,st_size=size,st_dev=1,st_ino=ino,st_mtime_ns=mtime,st_ctime_ns=4)
   if which==2:return types.SimpleNamespace(st_mode=stat.S_IFDIR|0o700,st_dev=1,st_ino=22)
   return types.SimpleNamespace(st_mode=stat.S_IFREG|state['mode'],st_uid=10001,st_gid=10001 if case=='group' else 999,st_nlink=1,st_size=len(state['data']),st_dev=1,st_ino=33,st_mtime_ns=3,st_ctime_ns=4)
  def lstat(p):return meta(1 if p=='/probe/source' else 2)
  def op(p,flags,mode=None,dir_fd=None):
   calls.append(('open',p,flags))
   if p=='/probe/source':self.assertEqual(flags,131072);return 1
   if p=='/probe/out':self.assertEqual(flags,131072|65536);return 2
   self.assertEqual(p,'database-server-key');self.assertEqual(dir_fd,2);self.assertEqual(flags,2|64|128|131072);self.assertEqual(mode,0o600)
   if case=='existing':raise FileExistsError(errno.EEXIST,'REDACTED')
   return 3
  def chmod(fd,mode):self.assertEqual(fd,3);self.assertEqual(mode,0o640);state['mode']=mode;calls.append(('fchmod',fd))
  def read(fd,n):
   self.assertEqual(n,8192);calls.append(('read',fd))
   return DATA if fd==1 else (b'corrupt' if case=='readback' else state['data'])
  def write(fd,data):
   self.assertEqual(fd,3);calls.append(('write',fd));state['data']=data[:len(data)//2] if case=='partial' else data;return len(state['data'])
  def named(p,dir_fd,follow_symlinks):
   self.assertFalse(follow_symlinks);self.assertEqual(dir_fd,2);v=meta(3)
   if case=='target_race':v.st_ino=44
   return v
  def close(fd):
   calls.append(('close',fd))
   if case=='close' and fd==3:raise OSError(errno.EIO,'REDACTED')
  os_mock=types.SimpleNamespace(geteuid=lambda:10001,getegid=lambda:999,lstat=lstat,open=op,fstat=meta,listdir=lambda fd:[],fchmod=chmod,read=read,write=write,lseek=lambda *a:0,stat=named,close=close,O_RDONLY=0,O_RDWR=2,O_CREAT=64,O_EXCL=128,O_NOFOLLOW=131072,O_DIRECTORY=65536,SEEK_SET=0)
  original=builtins.__import__
  def imp(name,*args,**kwargs):return os_mock if name=='os' else original(name,*args,**kwargs)
  out=io.StringIO()
  with contextlib.redirect_stdout(out):exec(compile(WRITER,'KEY29_MOCK','exec'),{'__builtins__':dict(vars(builtins),__import__=imp)})
  raw=out.getvalue();self.assertNotIn(DATA.decode(),raw);self.assertNotIn('REDACTED',raw);self.assertLessEqual(len(raw.encode()),4096);return json.loads(raw),calls,state
 def test_equal_copy_rootless(self):
  v,c,s=self.run_case();self.assertEqual(v['status'],'PASS');self.assertTrue(v['bytesEqual']);self.assertEqual(v['mode'],0o640);self.assertEqual(v['fileGid'],999);self.assertEqual([x[1] for x in c if x[0]=='close'],[3,2,1])
 def test_group_refusal_before_read(self):
  v,c,s=self.run_case('group');self.assertEqual(v['error'],'TARGET');self.assertFalse(any(x[0]=='read' for x in c))
 def test_oversize_no_read(self):
  v,c,s=self.run_case('oversize');self.assertEqual(v['error'],'SIZE');self.assertFalse(any(x[0]=='read' for x in c))
 def test_source_identity(self):self.assertEqual(self.run_case('source_identity')[0]['error'],'SOURCE')
 def test_source_race(self):self.assertEqual(self.run_case('source_race')[0]['error'],'SOURCE_RACE')
 def test_target_race(self):self.assertEqual(self.run_case('target_race')[0]['error'],'TARGET_RACE')
 def test_partial_write(self):
  v,c,s=self.run_case('partial');self.assertEqual(v['error'],'WRITE');self.assertTrue(v['created']);self.assertGreater(len(s['data']),0)
 def test_existing_never_overwrite(self):self.assertEqual(self.run_case('existing')[0]['error'],'EEXIST')
 def test_readback_mismatch(self):self.assertEqual(self.run_case('readback')[0]['error'],'READBACK')
 def test_close_failure(self):
  v,c,s=self.run_case('close');self.assertEqual(v['error'],'CLOSE');self.assertEqual(v['status'],'FAIL')
class ReaderTests(unittest.TestCase):
 def test_no_bytes_only_open_close(self):
  calls=[]
  def m():return types.SimpleNamespace(st_uid=10001,st_gid=999,st_mode=stat.S_IFREG|0o640,st_size=len(DATA),st_nlink=1,st_dev=1,st_ino=33)
  def op(p,flags):self.assertEqual(p,'/probe/key');self.assertEqual(flags,131072);calls.append('open');return 4
  os_mock=types.SimpleNamespace(geteuid=lambda:999,getegid=lambda:999,lstat=lambda p:m(),stat=lambda p,follow_symlinks:m(),access=lambda p,mode:True,open=op,fstat=lambda fd:m(),close=lambda fd:calls.append('close'),R_OK=4,O_RDONLY=0,O_NOFOLLOW=131072)
  original=builtins.__import__
  def imp(name,*a,**k):return os_mock if name=='os' else original(name,*a,**k)
  out=io.StringIO()
  with contextlib.redirect_stdout(out):exec(compile(READER,'KEY29_READER_MOCK','exec'),{'__builtins__':dict(vars(builtins),__import__=imp)})
  v=json.loads(out.getvalue());self.assertTrue(v['openedIdentityMatches']);self.assertTrue(v['readable']);self.assertEqual(calls,['open','close']);self.assertNotIn(DATA.decode(),out.getvalue())
if __name__=='__main__':unittest.main()
