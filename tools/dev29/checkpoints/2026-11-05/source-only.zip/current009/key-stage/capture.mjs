// Adapted from frozen NETQUAL capture: fixed4096 raw cap, 16KiB transient memory, kill grace inside deadline.
import {createHash} from 'node:crypto';import * as S from './spec.mjs';const {ensure}=S;const ERROR=new Set(['ENOENT','EACCES','EPERM','ETIMEDOUT','ENOBUFS','OTHER']);const err=e=>ERROR.has(e?.code)?e.code:'OTHER';const sig=s=>s==null?null:['SIGTERM','SIGKILL','SIGINT','SIGABRT','SIGSEGV','SIGPIPE','SIGALRM'].includes(s)?s:'OTHER';
export class RawBudget{
 constructor(limit=S.CAP*4){this.limit=limit;this.used=0;this.peak=0;}
 take(n){ensure(Number.isSafeInteger(n)&&n>=0&&this.used+n<=this.limit,'NQ_RAW_CAP');this.used+=n;this.peak=Math.max(this.peak,this.used);}
 give(n){ensure(Number.isSafeInteger(n)&&n>=0&&n<=this.used,'NQ_RAW_ACCOUNTING');this.used-=n;}
}
export function capture(makeChild,clock,deadline,{stream=false,canRelease=()=>false,memory=new RawBudget()}={}){
 const began=clock.now(),out=[],errorOut=[],hashes={stdout:createHash('sha256'),stderr:createHash('sha256')},bytes={stdout:0,stderr:0};
 let child=null,ended=false,released=false,readySeen=false,killSent=false,errorCode=null,code=null,signal=null,closed=false,abandoned=false,hard=null,grace=null,retained=0,lastStats=null,protocolText='';
 let resolveDone,resolveReady,rejectReady;const done=new Promise(r=>resolveDone=r),ready=new Promise((a,b)=>{resolveReady=a;rejectReady=b;});ready.catch(()=>{});
 const stats=complete=>({stdout:{bytes:bytes.stdout,sha256:hashes.stdout.copy().digest('hex'),complete},stderr:{bytes:bytes.stderr,sha256:hashes.stderr.copy().digest('hex'),complete}});
 const forget=()=>{if(retained){memory.give(retained);retained=0;}out.length=0;errorOut.length=0;};
 const join=chunks=>{if(!chunks.length)return Buffer.alloc(0);if(chunks.length===1)return chunks[0];const size=chunks.reduce((n,b)=>n+b.length,0);memory.take(size);let b;try{b=Buffer.concat(chunks,size);}catch(e){memory.give(size);throw e;}chunks.length=0;memory.give(size);return b;};
 const finish=()=>{
  if(ended)return;ended=true;clock.clearTimer(hard);clock.clearTimer(grace);let stdout,stderr;
  try{stdout=join(out);stderr=join(errorOut);}catch{errorCode=errorCode||'ENOBUFS';forget();stdout=Buffer.alloc(0);stderr=Buffer.alloc(0);}
  const complete=closed&&!errorCode&&!abandoned;lastStats=stats(complete);
  const r={dispatched:child!==null,code,errorCode,signal,complete,abandoned,durationMs:Math.round(clock.now()-began),stdout,stderr,stats:lastStats,
   release(){forget();r.stdout=Buffer.alloc(0);r.stderr=Buffer.alloc(0);},
   withText(which,fn){ensure(['stdout','stderr'].includes(which),'NQ_TEXT_STREAM');const b=r[which],temporary=b.length*2;memory.take(temporary);try{return fn(b.toString('utf8'));}finally{memory.give(temporary);}}
  };
  out.length=0;errorOut.length=0;if(!readySeen)rejectReady(Error('NQ_READY_MISSING'));resolveDone(r);
 };
 const dispose=()=>{if(ended)return;abandoned=true;for(const x of [child?.stdin,child?.stdout,child?.stderr])try{x?.on?.('error',()=>{});x?.destroy?.();}catch{}try{child?.unref?.();}catch{}finish();};
 const fault=error=>{if(ended)return;if(!errorCode)errorCode=error;rejectReady(Error('NQ_STREAM_FAILURE'));if(!killSent&&child){killSent=true;try{child.kill('SIGTERM');}catch{}}if(grace===null)grace=clock.setTimer(dispose,Math.max(0,Math.min(1000,deadline-clock.now())));};
 const data=(which,b)=>{
  if(ended||errorCode)return;if(!Buffer.isBuffer(b)){fault('OTHER');return;}bytes[which]+=b.length;hashes[which].update(b);if(bytes.stdout+bytes.stderr>S.CAP){fault('ENOBUFS');return;}
  try{memory.take(b.length);}catch{child.stdout?.pause?.();child.stderr?.pause?.();fault('ENOBUFS');return;}
  retained+=b.length;(which==='stdout'?out:errorOut).push(b);
  if(stream){
   const maximum=Buffer.byteLength(S.READY+S.DONE);if(bytes.stderr||bytes.stdout>maximum){fault('OTHER');return;}
   const expected=Buffer.from(S.READY+S.DONE),offset=bytes.stdout-b.length,allowed=released?expected.length:Buffer.byteLength(S.READY);if(offset+b.length>allowed){fault('OTHER');return;}for(let i=0;i<b.length;i++)if(b[i]!==expected[offset+i]){fault('OTHER');return;}if(bytes.stdout===Buffer.byteLength(S.READY)&&!readySeen){readySeen=true;resolveReady(true);}
  }
 };
 if(clock.now()>=deadline){errorCode='ETIMEDOUT';finish();return {ready:()=>ready,done:()=>done,release:()=>{throw Error('NQ_RELEASE');},interrupt:()=>{},dispose,stats:()=>lastStats,get ended(){return ended;}};}
 try{child=makeChild();}catch(e){errorCode=err(e);finish();return {ready:()=>ready,done:()=>done,release:()=>{throw Error('NQ_RELEASE');},interrupt:()=>{},dispose,stats:()=>lastStats,get ended(){return ended;}};}
 child.on('error',e=>fault(err(e)));child.on('exit',(c,s)=>{if(code===null){code=Number.isInteger(c)?c:null;signal=sig(s);}});
 child.stdout.on('data',b=>data('stdout',b));child.stderr.on('data',b=>data('stderr',b));for(const x of [child.stdin,child.stdout,child.stderr])x?.on?.('error',e=>fault(err(e)));
 child.on('close',()=>{if(ended)return;closed=true;finish();});hard=clock.setTimer(()=>fault('ETIMEDOUT'),Math.max(0,deadline-1000-clock.now()));
 return {ready:()=>ready,done:()=>done,stats:()=>lastStats||stats(false),interrupt:()=>fault('OTHER'),dispose,get ended(){return ended;},
  release(){ensure(stream&&!ended&&readySeen&&!released&&canRelease()&&clock.now()<deadline,'NQ_RELEASE');released=true;child.stdin.end(S.RELEASE);},get released(){return released;}
 };
}
