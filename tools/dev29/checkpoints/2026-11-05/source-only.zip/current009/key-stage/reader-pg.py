import os,stat,json,errno
paths=['/probe/key','/run/secrets/database-ca','/run/secrets/bootstrap-password','/run/secrets/migrator-password','/tools/bound-db-supervisor.sh','/config/bootstrap.hba','/config/runtime.hba','/config/bootstrap.sql']
rows=[]
for index,p in enumerate(paths):
 row={'id':index,'regular':False,'symlink':None,'readable':False,'openReadOnly':False,'openedIdentityMatches':False,'errno':None};fd=None
 try:
  a=os.lstat(p);row['regular']=stat.S_ISREG(a.st_mode);row['symlink']=stat.S_ISLNK(a.st_mode);row['readable']=os.access(p,os.R_OK)
  if not row['regular'] or row['symlink'] or a.st_nlink!=1:raise OSError(errno.EINVAL,'')
  if index==0 and (a.st_uid!=10001 or a.st_gid!=999 or stat.S_IMODE(a.st_mode)!=0o640 or not 0<a.st_size<=8192):raise OSError(errno.EINVAL,'')
  fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW);b=os.fstat(fd);c=os.lstat(p)
  identity=lambda s:(s.st_dev,s.st_ino,s.st_uid,s.st_gid,s.st_mode,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
  row['openReadOnly']=True;row['openedIdentityMatches']=identity(a)==identity(b)==identity(c)
 except OSError as e:row['errno']=errno.errorcode.get(e.errno,'OTHER') if e.errno in [errno.EACCES,errno.EPERM,errno.ENOENT,errno.ENOTDIR,errno.ELOOP,errno.EIO,errno.ESTALE] else 'OTHER'
 finally:
  if fd is not None:
   try:os.close(fd)
   except OSError:row['errno']='OTHER';row['openReadOnly']=False
 rows.append(row)
v={'scope':'KEYPG-READER','version':1,'uid':os.getuid(),'gid':os.getgid(),'files':rows}
print(json.dumps(v,separators=(',',':'),sort_keys=True))
